from pathlib import Path
import pandas as pd, numpy as np
import xml.etree.ElementTree as ET
import json,hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/11.图7_核心靶点通路定位')
R=ROOT/'原始数据';T=ROOT/'各子图数据表';A=ROOT/'处理记录'
def read(p,**kw):return pd.read_csv(p,encoding='utf-8-sig',float_precision='round_trip',**kw)
def save(df,name):df.to_csv(T/name,index=False,encoding='utf-8-sig')
inp=read(R/'输入_105基因及注释覆盖.csv',dtype={'ENTREZID':str})
core=read(T/'输入_六个核心靶点_Entrez核对.csv',dtype={'ENTREZID':str})
ann=read(T/'两条通路_基因注释.csv',dtype={'ENTREZID':str}).fillna('')
symbols=dict(zip(ann.ENTREZID,ann.SYMBOL));names=dict(zip(ann.ENTREZID,ann.GENENAME))
coreids=set(core.ENTREZID);input105=set(inp.ENTREZID);input49=set(inp.loc[inp.In_original49,'ENTREZID'])
assert len(coreids)==6 and coreids<=input49<=input105
allcore=[];allmembers=[];allsummary=[];panels=[];specs=[]
def syms(ids):return '/'.join(sorted(symbols.get(k,'hsa:'+k) for k in ids))
# Printed labels below were visually checked at the archived official 2x coordinates.
# Human KGML graphics names contain aliases and may differ from native map labels.
printed={'hsa04620':{'18':'p105','40':'IL-1β','45':'IL-6','48':'AKT','181':'NF-κB','184':'AP-1'},
         'hsa04668':{'47':'NF-κB','48':'NF-κB','63':'AP-1','126':'Akt','169':'NF-κB','172':'c-Jun','220':'CASP3','249':'Il1b','250':'Il6','261':'Jun'}}
def spec(name,title,df,notes,widths=None):
    obj=df.astype(object).where(pd.notna(df),None)
    specs.append(dict(name=name,title=title,fields=list(df.columns),rows=obj.values.tolist(),notes=notes,widths=widths or {}))

for panel,pid in [('A','hsa04620'),('B','hsa04668')]:
    tree=ET.parse(R/(pid+'.xml')).getroot();entries={x.get('id'):x for x in tree.findall('entry')}
    geneids={eid:{k.split(':')[1] for k in x.get('name','').split() if k.startswith('hsa:')} for eid,x in entries.items() if x.get('type')=='gene'}
    current=set(read(R/(pid+'_当前全部通路基因.tsv'),sep='\t',header=None,dtype=str)[1].str.replace('hsa:','',regex=False))
    rendered=set().union(*geneids.values())
    native=read(T/(pid+'_Pathview节点映射原始返回.csv'),dtype={'Entry_ID':str}).set_index('Entry_ID')
    nodes=[];loc=[];rels=[]
    for eid,x in entries.items():
        g=x.find('graphics');gs=geneids.get(eid,set());hits=gs&coreids
        row=dict(Entry_ID=eid,Type=x.get('type'),KEGG_name=x.get('name'),Map_label=g.get('name','') if g is not None else '',Printed_core_label=printed[pid].get(eid,''),
            All_Entrez='/'.join(sorted(gs,key=int)),All_symbols=syms(gs),Core_Entrez='/'.join(sorted(hits,key=int)),Core_symbols=syms(hits),
            Core_hit=bool(hits),Original49_symbols=syms(gs&input49),Expanded105_symbols=syms(gs&input105),
            X_1x=float(g.get('x',0)) if g is not None else None,Y_1x=float(g.get('y',0)) if g is not None else None,
            Width_1x=float(g.get('width',0)) if g is not None else None,Height_1x=float(g.get('height',0)) if g is not None else None,
            Render_color=native.loc[eid,'mol.col'] if eid in native.index else '',KGML_link=x.get('link',''))
        nodes.append(row)
    nodes=pd.DataFrame(nodes)
    for _,g in core.iterrows():
        hitnodes=nodes[nodes.Core_Entrez.str.split('/').map(lambda z:g.ENTREZID in z)]
        loc.append(dict(Panel=panel,Pathway_ID=pid,SYMBOL=g.Gene_symbol,EntrezID=g.ENTREZID,
            In_current_KEGG_pathway=g.ENTREZID in current,Shown_in_KGML=g.ENTREZID in rendered,
            Highlighted=not hitnodes.empty,Highlighted_node_count=len(hitnodes),
            Entry_IDs=' / '.join(hitnodes.Entry_ID),Printed_node_labels=' / '.join(hitnodes.Printed_core_label),Map_labels=' / '.join(hitnodes.Map_label),
            Meaning='Core target identity' if not hitnodes.empty else 'No node in this pathway map'))
    loc=pd.DataFrame(loc);allcore.append(loc)
    for i,x in enumerate(tree.findall('relation'),1):
        a=x.get('entry1');b=x.get('entry2')
        rels.append(dict(Relation_index=i,Source_entry=a,Target_entry=b,Type=x.get('type'),
            Subtype_names=' / '.join(s.get('name','') for s in x.findall('subtype')),
            Subtype_values=' / '.join(s.get('value','') for s in x.findall('subtype')),
            Source_label=nodes.set_index('Entry_ID').loc[a,'Map_label'],Target_label=nodes.set_index('Entry_ID').loc[b,'Map_label'],
            Source_symbols=syms(geneids.get(a,set())),Target_symbols=syms(geneids.get(b,set()))))
    edges=pd.DataFrame(rels)
    save(nodes,f'{panel}_{pid}_图中节点.csv');save(edges,f'{panel}_{pid}_KGML连线.csv');save(loc,f'{panel}_{pid}_六核心定位.csv')
    for k in sorted(current|rendered,key=int):
        allmembers.append(dict(Panel=panel,Pathway_ID=pid,EntrezID=k,SYMBOL=symbols.get(k,''),Gene_name=names.get(k,''),
            In_current_KEGG_pathway=k in current,Shown_in_KGML=k in rendered,Core_target=k in coreids,
            In_original49=k in input49,In_expanded105=k in input105,
            Entry_IDs=' / '.join(eid for eid,gs in geneids.items() if k in gs)))
    for gene_set,filename in [('Original49','输入_原49_KEGG全部富集.csv'),('Expanded105','输入_扩展105_KEGG全部富集.csv')]:
        source=read(R/filename);ranking=source[source['BH_significant']].sort_values(['pvalue','p.adjust','ID']).reset_index(drop=True)
        q=ranking[ranking.ID==pid].iloc[0]
        allsummary.append(dict(Panel=panel,Pathway_ID=pid,Description=q.Description,Gene_set=gene_set,Rank_by_P=int(ranking.index[ranking.ID==pid][0])+1,
            GeneRatio=q.GeneRatio,Count=int(q.Count),BgRatio=q.BgRatio,pvalue=q.pvalue,p_adjust_BH=q['p.adjust'],
            Gene_symbols=q.Gene_symbols,Core_genes_in_map=syms(coreids&rendered),Core_count_in_map=int(loc.Highlighted.sum()),
            Highlighted_nodes=int(nodes.Core_hit.sum()),Current_KEGG_genes=len(current),KGML_genes=len(rendered),KGML_relations=len(edges)))
    panels.append(dict(Panel=panel,Pathway_ID=pid,Description=tree.get('title'),Core_symbols=sorted(loc.loc[loc.Highlighted,'SYMBOL']),
        Missing_core=sorted(loc.loc[~loc.Highlighted,'SYMBOL']),Core_count=int(loc.Highlighted.sum()),Highlighted_nodes=int(nodes.Core_hit.sum())))
    spec(panel+'_核心定位',panel+' | 六个核心靶点的通路定位',loc,['来源：图3六算法交集；KEGG人类KGML，2026-10-19。','红色为核心身份；图内核心标签另经官方2倍图逐项目视核对。','KGML名称含别名，可与图内简写不同；非映射项保留。'])
    spec(panel+'_图中节点',panel+' | 图中全部KGML节点及坐标',nodes,['来源：KEGG hsa KGML；坐标为官方1倍原始坐标。','实际2倍图绘制坐标=原始坐标×2；连线与节点身份不变。','复合框中只要含至少一个核心基因即标红，其余同框成员不视为核心。'])
    spec(panel+'_通路连线',panel+' | KEGG KGML原始连线',edges,['来源：KEGG hsa KGML，保存原始关系方向及类型。','KGML关系表不等于官方图片中的每一条装饰性连线。','图片使用完整KEGG底图，不用关系表重新布局。'])

summary=pd.DataFrame(allsummary);locations=pd.concat(allcore,ignore_index=True);members=pd.DataFrame(allmembers)
save(summary,'两通路_49与105富集及定位汇总.csv');save(locations,'两通路_六核心定位总表.csv');save(members,'两通路_基因成员与输入集合归属.csv')
spec('结果概览','图7 | 核心靶点通路定位与既有富集结果',summary,[
    'A为Toll样受体通路，B为TNF通路；按参考论文图7选择。','富集数值复用图4/6归档结果，图7没有重新进行统计检验。','输入：六个核心靶点；原49和扩展105的富集仅作为通路选择依据。'])
specs.insert(0,specs.pop())
spec('全部通路基因','两条通路全部人类基因与本项目集合归属',members,[
    '来源：KEGG link/hsa接口与hsa KGML；符号来自org.Hs.eg.db。','一行一个通路-基因，重复出现在图中时列出全部Entry_ID。','显式列明是否核心、属于原49、属于扩展105和是否在图中。'])
params=pd.DataFrame([
    ('疾病项目','Acute kidney injury'),('参考论文','DOI 10.1186/s40643-026-01083-8，图7'),
    ('核心基因','AKT1/CASP3/IL1B/IL6/JUN/NFKB1'),('核心来源','图3六算法前10交集'),('物种','Homo sapiens (hsa)'),
    ('A通路','hsa04620 Toll-like receptor signaling pathway'),('B通路','hsa04668 TNF signaling pathway'),
    ('通路选择','参考论文相同两条；在本项目105基因富集中分别排名3和2，均BH显著'),
    ('渲染','R pathview 1.52.0；KEGG native；node.sum=max'),('基因值','6个核心基因均为身份标记1，不是表达量或logFC'),
    ('颜色','#FF0000=包含核心靶点的基因节点；其余节点白色'),('复合节点','整框标红仅表示框内至少一个核心基因；不把同框其他成员定义为核心'),
    ('图例','分类图例，不使用连续表达色条'),('坐标','hsa KGML坐标×2，匹配KEGG官方reference map image2x'),
    ('数据时间','通路图/KGML/当前成员：2026-10-19；富集GSON快照：2026-10-18'),
    ('富集阈值','BH校正P<0.05且FoldEnrichment>1，352项完整KEGG检验'),
    ('统计解释','富集和节点定位不能单独证明急性肾损伤中的因果调控或激活/抑制'),
    ('位图来源','通路底图是官方PNG；PDF/SVG中的底图仍为位图，非完整矢量图'),
    ('KEGG-A','https://www.kegg.jp/pathway/hsa04620'),('KEGG-B','https://www.kegg.jp/pathway/hsa04668'),
    ('KEGG API','https://www.kegg.jp/kegg/rest/keggapi.html'),('pathview','https://bioconductor.org/packages/pathview/'),
    ('pathview文献','Luo W, Brouwer C. Bioinformatics (2013) 29:1830–1831. doi:10.1093/bioinformatics/btt285'),
],columns=['Parameter','Value'])
spec('方法与来源','图7 | 参数、来源和解释',params,['保留官方KEGG布局和原始图内符号。','AKT/AP-1/NF-kappaB等集合节点的基因成员详见节点表。','原始输入、下载来源及SHA256保存在原始数据和处理记录。'])
(A/'workbook_payload.json').write_text(json.dumps(dict(sheets=specs),ensure_ascii=False,allow_nan=False,indent=2),encoding='utf-8')
(A/'panel_metadata.json').write_text(json.dumps(panels,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=[dict(File=str(p.relative_to(ROOT)).replace('\\','/'),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(R.iterdir()) if p.is_file() and not p.name.endswith('.provenance.json')]
(A/'原始输入与注释_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(panels,ensure_ascii=False,indent=2));print('Workbook sheets',len(specs))
