options(stringsAsFactors=FALSE)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(pathview);library(org.Hs.eg.db);library(AnnotationDbi);library(jsonlite)})
arg<-grep('^--file=',commandArgs(),value=TRUE)
sd<-if(length(arg))dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))else''
root<-if(basename(sd)=='处理记录')dirname(sd)else'./Computational/11.图7_核心靶点通路定位'
raw<-file.path(root,'原始数据');audit<-file.path(root,'处理记录');tables<-file.path(root,'各子图数据表')
cache<-file.path(audit,'KEGG双倍坐标缓存');native<-file.path(audit,'Pathview原生图')
write_csv<-function(x,p){con<-file(p,'wb');writeBin(charToRaw('\xef\xbb\xbf'),con);writeBin(charToRaw(enc2utf8(paste(capture.output(write.csv(x,row.names=FALSE,na='')),collapse='\n'))),con);close(con)}
core<-read.csv(file.path(raw,'输入_图3六个共同核心靶点.csv'),fileEncoding='UTF-8-BOM',check.names=FALSE)
input<-read.csv(file.path(raw,'输入_105基因及注释覆盖.csv'),fileEncoding='UTF-8-BOM',colClasses='character',check.names=FALSE)
core$ENTREZID<-input$ENTREZID[match(core$Gene_symbol,input$SYMBOL)]
stopifnot(nrow(core)==6,!anyNA(core$ENTREZID),!anyDuplicated(core$ENTREZID))
core$Mapping_flag<-1L
write_csv(core,file.path(tables,'输入_六个核心靶点_Entrez核对.csv'))
ids<-unique(unlist(lapply(c('04620','04668'),function(pid){
  x<-XML::xmlParse(file.path(raw,paste0('hsa',pid,'.xml')))
  nodes<-XML::getNodeSet(x,'//entry[@type="gene"]')
  sub('^hsa:','',unlist(strsplit(vapply(nodes,function(n)XML::xmlGetAttr(n,'name'),''),' ')))
})))
approved<-unique(AnnotationDbi::select(org.Hs.eg.db,keys=ids,keytype='ENTREZID',columns=c('SYMBOL','GENENAME')))
write_csv(approved,file.path(tables,'两条通路_基因注释.csv'))
write_csv(data.frame(Package=c('pathview','KEGGgraph','org.Hs.eg.db','AnnotationDbi','png'),Version=vapply(c('pathview','KEGGgraph','org.Hs.eg.db','AnnotationDbi','png'),function(p)as.character(packageVersion(p)),'')),file.path(audit,'R软件版本.csv'))
writeLines(capture.output(sessionInfo()),file.path(audit,'R_sessionInfo.txt'))
writeLines(capture.output(citation('pathview')),file.path(audit,'pathview引用.txt'))
gene.data<-setNames(core$Mapping_flag,core$ENTREZID)
setwd(native);result<-list()
for(pid in c('04620','04668')){
  message('Rendering hsa',pid,' with ',length(gene.data),' core identity flags')
  ans<-pathview(gene.data=gene.data,pathway.id=pid,species='hsa',gene.idtype='entrez',kegg.dir=cache,
    kegg.native=TRUE,map.null=TRUE,same.layer=TRUE,node.sum='max',plot.col.key=FALSE,
    low=list(gene='#FF0000',cpd='white'),mid=list(gene='#FF0000',cpd='white'),high=list(gene='#FF0000',cpd='white'),
    na.col='white',both.dirs=list(gene=FALSE,cpd=FALSE),limit=list(gene=1,cpd=1),
    out.suffix='core_identity',cex=.5,res=300,new.signature=FALSE)
  stopifnot(is.list(ans),!is.null(ans$plot.data.gene))
  df<-ans$plot.data.gene;df$Entry_ID<-rownames(df);df$Pathway_ID<-paste0('hsa',pid)
  write_csv(df,file.path(tables,paste0('hsa',pid,'_Pathview节点映射原始返回.csv')))
  result[[paste0('hsa',pid)]]<-ans
}
saveRDS(result,file.path(audit,'图7_pathview完整返回.rds'))
write_json(list(Core_symbols=core$Gene_symbol,Core_Entrez=core$ENTREZID,Mapping_flag=1,
  Flag_meaning='Core target identity only; not expression fold change',
  Renderer='R pathview 1.52.0',Native_KEGG=TRUE,Native_labels_preserved=TRUE,
  Node_aggregation='max',Highlight_color='#FF0000',Other_gene_nodes='white',
  Colorbar=FALSE,Coordinate_scale=2,Species='Homo sapiens (hsa)'),file.path(audit,'图7分析参数.json'),pretty=TRUE,auto_unbox=TRUE,digits=NA)
message('PATHVIEW FIGURE7 COMPLETE')
