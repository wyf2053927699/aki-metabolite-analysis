options(stringsAsFactors=FALSE)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(grid);library(png);library(jsonlite)})
arg<-grep('^--file=',commandArgs(),value=TRUE)
sd<-if(length(arg))dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))else''
root<-if(basename(sd)=='处理记录')dirname(sd)else'./Computational/11.图7_核心靶点通路定位'
audit<-file.path(root,'处理记录');out<-file.path(root,'图片');preview<-file.path(audit,'图片预览');pdfs<-file.path(audit,'单页PDF')
for(p in c(out,preview,pdfs))dir.create(p,showWarnings=FALSE,recursive=TRUE)
export<-'--export'%in%commandArgs(TRUE)
meta<-fromJSON(file.path(audit,'panel_metadata.json'),simplifyVector=FALSE)
images<-lapply(meta,function(m)readPNG(file.path(audit,'Pathview原生图',paste0(m$Pathway_ID,'.core_identity.png'))))
W<-14;imageW<-13.2
imageH<-vapply(images,function(im)imageW*dim(im)[1]/dim(im)[2],0.)
panelH<-imageH+.4+.52
layout<-list(
  list(name='图7_组合主图',indices=1:2,tag=TRUE,height=sum(panelH)+.32+.38),
  list(name='图7A_Toll样受体信号通路',indices=1,tag=FALSE,height=panelH[1]+.38),
  list(name='图7B_TNF信号通路',indices=2,tag=FALSE,height=panelH[2]+.38))

render<-function(spec){
  grid.newpage();pushViewport(viewport(xscale=c(0,W),yscale=c(0,spec$height)))
  rect<-function(x,y,w,h,col,border=NA)grid.rect(x=unit(x,'native'),y=unit(y,'native'),width=unit(w,'native'),height=unit(h,'native'),gp=gpar(fill=col,col=border))
  txt<-function(s,x,y,size=10,bold=FALSE,col='#202020',just='left')grid.text(s,x=unit(x,'native'),y=unit(y,'native'),just=just,gp=gpar(fontfamily='Arial',fontsize=size,fontface=if(bold)'bold'else'plain',col=col))
  top<-spec$height-.14
  for(i in spec$indices){
    m<-meta[[i]];h<-imageH[i]
    if(spec$tag)grid.text(m$Panel,x=unit(.08,'native'),y=unit(top-.13,'native'),just='left',gp=gpar(fontfamily='Times New Roman',fontsize=24))
    txt(paste0('Human pathway ',m$Pathway_ID,'  |  ',m$Core_count,' of 6 core targets mapped'),.52,top-.14,size=10)
    rect(11.95,top-.14,.13,.11,'#FF0000',border='black');txt('Core target node',12.08,top-.14,size=9)
    center<-top-.4-h/2
    grid.raster(images[[i]],x=unit(.45+imageW/2,'native'),y=unit(center,'native'),width=unit(imageW,'native'),height=unit(h,'native'),interpolate=TRUE)
    txt(paste0('Mapped core genes: ',paste(unlist(m$Core_symbols),collapse=', ')),.52,top-.4-h-.16,size=10,bold=TRUE)
    if(length(m$Missing_core))txt(paste0('No node in this map: ',paste(unlist(m$Missing_core),collapse=', ')),.52,top-.4-h-.34,size=9,col='#555555')
    top<-top-panelH[i]-.32
  }
  txt('Red marks nodes containing a core target; color does not encode expression.  |  KEGG maps rendered with R pathview',.52,.10,size=8.5,col='#505050')
  popViewport()
}
manifest<-list()
for(spec in layout){
  message('Rendering ',spec$name)
  ragg::agg_png(file.path(preview,paste0(spec$name,'_preview.png')),width=W,height=spec$height,units='in',res=120,background='white');render(spec);dev.off()
  if(export){
    ragg::agg_png(file.path(out,paste0(spec$name,'.png')),width=W,height=spec$height,units='in',res=600,background='white');render(spec);dev.off()
    svglite::svglite(file.path(out,paste0(spec$name,'.svg')),width=W,height=spec$height,bg='white');render(spec);dev.off()
    cairo_pdf(file.path(pdfs,paste0(spec$name,'.pdf')),width=W,height=spec$height,family='Arial',onefile=TRUE);render(spec);dev.off()
  }
  manifest[[spec$name]]<-list(Width_inches=W,Height_inches=spec$height,Export_DPI=600,Native_map_type='KEGG official 2x raster; headers and legends are vector in PDF/SVG')
}
write_json(manifest,file.path(audit,'图像尺寸与格式.json'),pretty=TRUE,auto_unbox=TRUE,digits=NA)
message('FIGURE7 COMPOSITION COMPLETE')
