from pathlib import Path
import urllib.request, json, hashlib, datetime, shutil, time
import xml.etree.ElementTree as ET
from PIL import Image

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/11.图7_核心靶点通路定位')
RAW=ROOT/'原始数据'; AUDIT=ROOT/'处理记录'
for name in ['原始数据','各子图数据表','图片','处理记录','处理记录/Pathview原生图','处理记录/图片预览','处理记录/KEGG双倍坐标缓存']:
    (ROOT/name).mkdir(parents=True,exist_ok=True)
BASE=Path('./Computational')
copies={
    BASE/'7.图3_PPI与核心靶点分析/各子图数据表/C_共同核心靶点.csv':'输入_图3六个共同核心靶点.csv',
    BASE/'10.图6_扩展基因富集与比较/各子图数据表/输入105基因_注释覆盖核对.csv':'输入_105基因及注释覆盖.csv',
    BASE/'10.图6_扩展基因富集与比较/各子图数据表/扩展105_KEGG_全部富集检验.csv':'输入_扩展105_KEGG全部富集.csv',
    BASE/'10.图6_扩展基因富集与比较/各子图数据表/原49_KEGG_全部富集检验.csv':'输入_原49_KEGG全部富集.csv',
    BASE/'10.图6_扩展基因富集与比较/原始数据/KEGG_gsid2gene.tsv':'输入_20261018_KEGG_gsid2gene.tsv',
}
for source,name in copies.items():
    if not (RAW/name).exists():shutil.copy2(source,RAW/name)

def fetch(url,name,kind):
    dest=RAW/name
    if dest.exists():return
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scientific-pathway-reproduction/1.0'}),timeout=60) as resp:data=resp.read()
            if kind=='xml':ET.fromstring(data)
            if kind=='png':assert data.startswith(b'\x89PNG\r\n\x1a\n')
            assert len(data)>100
            dest.write_bytes(data)
            (RAW/(name+'.provenance.json')).write_text(json.dumps(dict(URL=url,Retrieved_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),SHA256=hashlib.sha256(data).hexdigest(),Bytes=len(data)),ensure_ascii=False,indent=2),encoding='utf-8')
            print(name,len(data),flush=True);time.sleep(.4);return
        except Exception:
            if attempt==2:raise
            time.sleep(2)

for pid in ['04620','04668']:
    fetch(f'https://rest.kegg.jp/get/hsa{pid}/kgml',f'hsa{pid}.xml','xml')
    fetch(f'https://rest.kegg.jp/get/hsa{pid}/image',f'hsa{pid}.png','png')
    fetch(f'https://rest.kegg.jp/get/map{pid}/image2x',f'map{pid}_官方双倍图.png','png')
    fetch(f'https://rest.kegg.jp/link/hsa/hsa{pid}',f'hsa{pid}_当前全部通路基因.tsv','text')
    base=Image.open(RAW/f'hsa{pid}.png');double=Image.open(RAW/f'map{pid}_官方双倍图.png')
    # Official reference and organism maps may differ by one border pixel.
    assert abs(double.width-base.width*2)<=1 and abs(double.height-base.height*2)<=1,(pid,base.size,double.size)
    tree=ET.parse(RAW/f'hsa{pid}.xml')
    for g in tree.getroot().iter('graphics'):
        for key in ['x','y','width','height']:
            if key in g.attrib:g.set(key,str(int(float(g.get(key))*2)))
        if g.get('coords'):
            g.set('coords',','.join(str(int(float(v)*2)) for v in g.get('coords').split(',')))
    cache=AUDIT/'KEGG双倍坐标缓存'
    tree.write(cache/f'hsa{pid}.xml',encoding='utf-8',xml_declaration=True)
    shutil.copy2(RAW/f'map{pid}_官方双倍图.png',cache/f'hsa{pid}.png')
    print('Official 1x/2x sizes',pid,base.size,double.size,flush=True)
(AUDIT/'底图与坐标说明.json').write_text(json.dumps(dict(KGML_species='hsa',Image_source='KEGG official reference map, image2x',Coordinate_scale=2,Explanation='Human KGML coordinates are multiplied by 2 to match official doubled reference-map PNG. Node identities, pathway topology and labels are preserved.'),ensure_ascii=False,indent=2),encoding='utf-8')
