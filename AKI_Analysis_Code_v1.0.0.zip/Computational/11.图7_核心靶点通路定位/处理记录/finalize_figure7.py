from pathlib import Path
import json,subprocess,hashlib
from pypdf import PdfReader,PdfWriter
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/11.图7_核心靶点通路定位')
A=ROOT/'处理记录';Q=A/'PDF预览';Q.mkdir(exist_ok=True)
layout=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
w=PdfWriter()
for name in layout:w.append(str(A/'单页PDF'/(name+'.pdf')),outline_item=name)
w.add_metadata({'/Title':'Figure 7: core target localization in human Toll-like receptor and TNF signaling pathways','/Author':'R pathview; KEGG official maps'})
pdf=ROOT/'图7_主图与全部子图.pdf'
with pdf.open('wb') as f:w.write(f)
exe='./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
run=subprocess.run([exe,'-r','110','-png',str(pdf),str(Q/'图7')],capture_output=True,text=True)
(A/'PDF渲染日志.txt').write_text(run.stdout+run.stderr,encoding='utf-8');assert run.returncode==0
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',19)
def contact(files,dest,w=1350,h=570,cols=1):
    im=Image.new('RGB',(w*cols,h*((len(files)+cols-1)//cols)),'#E5E9EE');d=ImageDraw.Draw(im)
    for i,p in enumerate(files):
        x=i%cols*w;y=i//cols*h;tile=Image.open(p).convert('RGB');tile.thumbnail((w-24,h-46))
        d.text((x+12,y+9),p.stem,font=font,fill='#253B52');im.paste(tile,(x+(w-tile.width)//2,y+36))
    im.save(dest)
contact(sorted(Q.glob('图7-*.png')),A/'PDF全部页面_检查总览.png',w=900,h=1250,cols=3)
files=sorted(A.glob('Excel预览_*.png'))
for i in range(0,len(files),3):contact(files[i:i+3],A/f'Excel检查总览_{i//3+1}.png')
Image.open(A/'图片预览/图7_组合主图_preview.png').convert('L').save(A/'图片预览/图7_组合主图_灰度检查.png')
deliver=list((ROOT/'图片').glob('*'))+[pdf,ROOT/'图7_各子图定位与通路数据.xlsx']
(A/'交付文件_SHA256.json').write_text(json.dumps([dict(File=str(p.relative_to(ROOT)).replace('\\','/'),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(deliver)],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(pdf_pages=len(PdfReader(pdf).pages),rendered_pages=len(list(Q.glob('图7-*.png'))),png_svg_files=len(deliver)-2)))
