from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import hypergeom
from PIL import Image
from pypdf import PdfReader
import openpyxl,xml.etree.ElementTree as ET,json,math,hashlib,pdfplumber
Image.MAX_IMAGE_PIXELS=150_000_000  # Known, locally generated 600 dpi scientific outputs.

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/11.图7_核心靶点通路定位')
A=ROOT/'处理记录';R=ROOT/'原始数据';T=ROOT/'各子图数据表';checks=[]
def check(name,passed,detail=''):checks.append(dict(Check=name,Passed=bool(passed),Detail=str(detail)))
def read(p,**kw):return pd.read_csv(p,encoding='utf-8-sig',float_precision='round_trip',**kw)
def ids(s):return set(str(s).split('/')) if pd.notna(s) and s else set()
core=read(T/'输入_六个核心靶点_Entrez核对.csv',dtype={'ENTREZID':str})
input105=read(R/'输入_105基因及注释覆盖.csv',dtype={'ENTREZID':str})
symbol=dict(zip(input105.ENTREZID,input105.SYMBOL));cores=set(core.ENTREZID)
check('Exactly six input core targets',set(core.Gene_symbol)=={'AKT1','CASP3','IL1B','IL6','JUN','NFKB1'} and len(core)==6)
check('Core identity flag is one, not expression',core.Mapping_flag.eq(1).all())
check('Core Entrez agrees with archived input105',all(symbol[k]==s for k,s in zip(core.ENTREZID,core.Gene_symbol)))
summary=read(T/'两通路_49与105富集及定位汇总.csv')
archived=read(R/'输入_20261018_KEGG_gsid2gene.tsv',sep='\t',dtype=str)
versions=[]
for panel,pid,count,nboxes in [('A','hsa04620',5,6),('B','hsa04668',6,10)]:
    tree=ET.parse(R/(pid+'.xml')).getroot();scaled=ET.parse(A/'KEGG双倍坐标缓存'/(pid+'.xml')).getroot()
    entries={x.get('id'):x for x in tree.findall('entry')}
    nodes=read(T/f'{panel}_{pid}_图中节点.csv',dtype={'Entry_ID':str},keep_default_na=False)
    pv=read(T/(pid+'_Pathview节点映射原始返回.csv'),dtype={'Entry_ID':str},keep_default_na=False)
    loc=read(T/f'{panel}_{pid}_六核心定位.csv',dtype={'EntrezID':str},keep_default_na=False)
    links=read(T/f'{panel}_{pid}_KGML连线.csv',dtype={'Source_entry':str,'Target_entry':str},keep_default_na=False)
    pool=set(read(R/(pid+'_当前全部通路基因.tsv'),sep='\t',header=None,dtype=str)[1].str.replace('hsa:','',regex=False))
    genes={eid:set(x.get('name').replace('hsa:','').split()) for eid,x in entries.items() if x.get('type')=='gene'}
    rendered=set().union(*genes.values());old=set(archived.loc[archived.gsid==pid,'gene'])
    versions.append(dict(Pathway_ID=pid,Snapshot_genes=len(old),Current_genes=len(pool),Added='/'.join(sorted(pool-old)),Removed='/'.join(sorted(old-pool)),Same_members=pool==old))
    check(pid+' original entry count',len(nodes)==len(entries))
    check(pid+' all relations preserved',len(links)==len(tree.findall('relation')) and set(links.Source_entry)|set(links.Target_entry)<=set(entries))
    check(pid+' current genes agree with KGML',pool==rendered)
    check(pid+' core presence and node counts',loc.Highlighted.sum()==count and nodes.Core_hit.sum()==nboxes)
    check(pid+' full six-core presence audit',len(loc)==6 and set(loc.EntrezID)==cores and all(bool(row.Highlighted)==(row.EntrezID in rendered) for row in loc.itertuples()))
    check(pid+' pathview contains all gene entries',set(pv.Entry_ID)==set(genes))
    check(pid+' red boxes match exact core overlap',all((color.upper()=='#FF0000')==bool(genes[eid]&cores) for eid,color in zip(pv.Entry_ID,pv['mol.col'])))
    check(pid+' printed labels explicitly audited for core boxes',nodes.Printed_core_label.ne('').equals(nodes.Core_hit))
    data=pd.to_numeric(pv['mol.data'],errors='coerce')
    check(pid+' numeric flags restricted to mapped core boxes',np.array_equal(data.notna().values,pv.Entry_ID.map(lambda e:bool(genes[e]&cores)).values) and data.dropna().eq(1).all())
    scaling=True
    for original,twice in zip(tree.iter('graphics'),scaled.iter('graphics')):
        for key in ['x','y','width','height']:
            if key in original.attrib:scaling&=float(twice.get(key))==2*float(original.get(key))
    check(pid+' official coordinates scaled exactly by two',scaling)
    im=np.array(Image.open(A/'Pathview原生图'/(pid+'.core_identity.png')).convert('RGB'))
    red=(im[:,:,0]>240)&(im[:,:,1]<20)&(im[:,:,2]<20);expected=np.zeros(red.shape,dtype=bool)
    for row in pv.itertuples():
        x,y,w,h=map(int,[row.x,row.y,row.width,row.height]);crop=red[y-h//2+3:y+h//2-3,x-w//2+3:x+w//2-3]
        if genes[row.Entry_ID]&cores:expected[max(0,y-h//2-2):y+h//2+3,max(0,x-w//2-2):x+w//2+3]=True
        check(pid+' node '+row.Entry_ID+' raster color',crop.mean()>.40 if genes[row.Entry_ID]&cores else crop.mean()<.01)
    check(pid+' no extra red pixels outside core boxes',int((red&~expected).sum())==0)
    for gene_set,filename,ninput in [('Original49','输入_原49_KEGG全部富集.csv',49),('Expanded105','输入_扩展105_KEGG全部富集.csv',105)]:
        table=read(R/filename);q=table.set_index('ID').loc[pid];s=summary[(summary.Pathway_ID==pid)&(summary.Gene_set==gene_set)].iloc[0]
        valid=set(input105.ENTREZID if ninput==105 else input105.loc[input105.In_original49,'ENTREZID'])
        check(pid+' '+gene_set+' exact enrichment reuse',q.Count==s.Count and q.pvalue==s.pvalue and q['p.adjust']==s.p_adjust_BH)
        check(pid+' '+gene_set+' overlap genes independently reproduced',len(old&valid)==s.Count and set(symbol[k] for k in old&valid)==ids(s.Gene_symbols))
        n=int(s.GeneRatio.split('/')[1]);K,N=map(int,s.BgRatio.split('/'))
        check(pid+' '+gene_set+' independent hypergeometric P',math.isclose(float(hypergeom.sf(s.Count-1,N,K,n)),s.pvalue,rel_tol=1e-12))
        ps=table.pvalue.to_numpy();order=np.argsort(ps);adj=np.empty(len(ps));adj[order]=np.minimum.accumulate((ps[order]*len(ps)/np.arange(1,len(ps)+1))[::-1])[::-1].clip(max=1)
        check(pid+' '+gene_set+' BH from full352 tests',len(ps)==352 and math.isclose(adj[np.flatnonzero(table.ID==pid)[0]],s.p_adjust_BH,rel_tol=1e-12))
        check(pid+' '+gene_set+' significant in both sets',s.p_adjust_BH<.05 and bool(q.BH_significant))
pd.DataFrame(versions).to_csv(A/'KEGG版本间基因成员核对.csv',index=False,encoding='utf-8-sig')

payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf-8'));heads=json.loads((A/'Excel字段表头.json').read_text(encoding='utf-8'))
wf=openpyxl.load_workbook(ROOT/'图7_各子图定位与通路数据.xlsx',data_only=False);wv=openpyxl.load_workbook(ROOT/'图7_各子图定位与通路数据.xlsx',data_only=True)
check('Workbook has exactly9 populated requested sheets',wf.sheetnames==[s['name'] for s in payload['sheets']] and len(wf.sheetnames)==9)
for spec in payload['sheets']:
    ws=wf[spec['name']];vs=wv[spec['name']];ok=True
    for i,row in enumerate(spec['rows'],8):
        for j,value in enumerate(row,1):
            cell=vs.cell(i,j).value
            ok&=(cell in [None,''] if value in [None,''] and not isinstance(value,(int,float,bool)) else math.isclose(cell,value,rel_tol=1e-14,abs_tol=0) if isinstance(value,(int,float)) and not isinstance(value,bool) else cell==value)
    check(spec['name']+' all saved cell values',ok)
    check(spec['name']+' headers', [ws.cell(7,j).value for j in range(1,len(spec['fields'])+1)]==[heads.get(f,f) for f in spec['fields']])
    check(spec['name']+' row counter recalculated',vs['B6'].value==len(spec['rows']) and ws['B6'].data_type=='f')
    check(spec['name']+' native filter and frozen headers',len(ws.tables)==1 and ws.freeze_panes=='C8')
    check(spec['name']+' no Excel errors',all(c.data_type!='e' for row in ws for c in row))
manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
for name,spec in manifest.items():
    im=Image.open(ROOT/'图片'/(name+'.png'))
    check(name+' PNG dimensions',abs(im.width-spec['Width_inches']*600)<1.1 and abs(im.height-spec['Height_inches']*600)<1.1)
    check(name+' 600dpi export metadata',all(abs(d-600)<.1 for d in im.info['dpi']))
    svg=ET.parse(ROOT/'图片'/(name+'.svg')).getroot();ns={'s':'http://www.w3.org/2000/svg'}
    check(name+' SVG contains maps and editable legend',len(svg.findall('.//s:image',ns))==(2 if name=='图7_组合主图' else 1) and len(svg.findall('.//s:text',ns))>0)
pdf=PdfReader(ROOT/'图7_主图与全部子图.pdf');check('PDF3 pages',len(pdf.pages)==3)
with pdfplumber.open(ROOT/'图7_主图与全部子图.pdf') as doc:
    for i,page in enumerate(doc.pages,1):
        check('PDF page '+str(i)+' header text inside bounds',all(0<=c['x0']<c['x1']<=page.width+.1 and -.1<=c['top']<c['bottom']<=page.height+.1 for c in page.chars))
        check('PDF page '+str(i)+' contains expected map images',len(page.images)==(2 if i==1 else 1))
        check('PDF page '+str(i)+' mapped gene labels present',all(s in page.extract_text() for s in ['AKT1','IL1B','IL6','JUN','NFKB1']))
check('All3 PDF pages rendered',len(list((A/'PDF预览').glob('图7-*.png')))==3)
for item in json.loads((A/'原始输入与注释_SHA256.json').read_text(encoding='utf-8')):
    check('Archived source unchanged '+item['File'],hashlib.sha256((ROOT/item['File']).read_bytes()).hexdigest()==item['SHA256'])
failed=[x for x in checks if not x['Passed']]
result=dict(checks=len(checks),passed=len(checks)-len(failed),failed=failed,core_genes=6,A_mapped_core_genes=5,B_mapped_core_genes=6,A_red_nodes=6,B_red_nodes=10,pdf_pages=3,workbook_sheets=9)
pd.DataFrame(checks).to_csv(A/'完整复核结果.csv',index=False,encoding='utf-8-sig')
(A/'validation_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False));assert not failed
