options(stringsAsFactors=FALSE)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(ggplot2);library(patchwork);library(circlize);library(ggplotify);library(jsonlite)})
script_arg<-grep('^--file=',commandArgs(),value=TRUE)
script_dir<-if(length(script_arg))dirname(normalizePath(sub('^--file=','',script_arg[1]),winslash='/'))else''
root<-if(basename(script_dir)=='处理记录')dirname(script_dir)else'./Computational/8.图4_GO_KEGG与功能网络'
audit<-file.path(root,'处理记录');out<-file.path(root,'图片');qa<-file.path(audit,'图片预览');pdir<-file.path(audit,'单页PDF')
for(d in c(out,qa,pdir))dir.create(d,recursive=TRUE,showWarnings=FALSE)
export<-'--export' %in% commandArgs(TRUE)
obj<-readRDS(file.path(audit,'R对象','图4完整分析对象.rds'))
pal<-c(BP='#24A07C',CC='#D96623',MF='#6B73B1',KEGG='#FB766F')
np<-c('#E64B35','#4DBBD5','#00A087','#3C5488','#F39B7F','#8491B4','#91D1C2','#DC0000','#7E6148','#B09C85')
theme_ref<-function()theme_classic(base_size=11,base_family='Arial')+theme(
  plot.title=element_text(size=14,face='plain',margin=margin(b=7)),
  plot.subtitle=element_text(size=9,margin=margin(b=8)),
  axis.title=element_text(size=11),axis.text=element_text(size=9,color='#202020'),
  axis.line=element_line(linewidth=.4,color='#4E4E4E'),axis.ticks=element_line(linewidth=.3),
  legend.title=element_text(size=10),legend.text=element_text(size=9),legend.key.height=grid::unit(4,'mm'),
  strip.background=element_rect(fill='#D9D9D9',color=NA),strip.text=element_text(size=9),
  plot.margin=margin(10,12,9,12),plot.tag=element_text(size=20,face='plain',family='Times New Roman'),plot.tag.position=c(0,1))
go<-do.call(rbind,obj$selected[c('BP','CC','MF')]);go$Domain<-factor(go$Domain,levels=c('BP','CC','MF'))
go<-go[order(go$Domain,go$Minus_log10_FDR,go$ID),];go$key<-factor(go$ID,levels=go$ID)
golabels<-setNames(go$Description,go$ID)
A<-ggplot(go,aes(x=key,y=Minus_log10_FDR,fill=Domain))+geom_col(width=.83)+
  facet_grid(.~Domain,scales='free_x',space='free_x',switch='x')+
  scale_fill_manual(values=pal,guide='none')+scale_x_discrete(labels=golabels,expand=expansion(add=.55))+
  scale_y_continuous(limits=c(0,20),expand=expansion(mult=c(0,0)),breaks=seq(0,20,5))+
  labs(x=NULL,y=expression(-log[10]('BH adjusted P')),title='GO enrichment',subtitle='49 candidate genes | BP: 10 terms; CC: 4; MF: 10 | BH FDR < 0.05')+
  theme_ref()+theme(axis.text.x=element_text(angle=65,hjust=1,vjust=1,size=7.5,lineheight=.93),
    strip.placement='outside',strip.background=element_blank(),strip.text.x=element_text(size=11),panel.spacing.x=grid::unit(3,'mm'),plot.margin=margin(10,12,9,62))
k<-obj$selected$KEGG;k$key<-factor(k$ID,levels=rev(k$ID))
klab<-setNames(vapply(k$Description,function(s)paste(strwrap(s,35),collapse='\n'),''),k$ID)
B<-ggplot(k,aes(x=Minus_log10_P,y=key))+geom_col(fill=pal['KEGG'],width=.76)+geom_point(aes(size=Count),color='#282828')+
  facet_grid('KEGG'~.)+scale_y_discrete(labels=klab,expand=expansion(add=.65))+
  scale_x_continuous(expand=expansion(mult=c(0,.08)),breaks=scales::breaks_pretty(5))+
  scale_size_area(max_size=6,breaks=sort(unique(k$Count)))+
  labs(x=expression(-log[10]('P value')),y=NULL,size='Count',title='KEGG enrichment',subtitle='49 candidate genes | top 10 significant pathways | BH FDR < 0.05')+
  theme_ref()+theme(legend.position='right',axis.text.y=element_text(size=10,lineheight=.93))

draw_chord<-function(domain,compact=FALSE){
  z<-obj$selected[[domain]];e<-obj$links[[domain]];genes<-sort(unique(e$Gene_symbol));terms<-z$ID
  ng<-length(genes);nt<-length(terms);sectors<-c(genes,terms)
  degree<-c(as.numeric(table(factor(e$Gene_symbol,levels=genes))),as.numeric(table(factor(e$Term_ID,levels=terms))))
  color<-c(setNames(rep('#777777',ng),genes),setNames(np[seq_len(nt)],terms))
  par(mar=c(.8,.8,2.7,.8),family='sans',xpd=NA)
  circos.clear();circos.par(start.degree=270,gap.after=c(rep(.85,ng-1),10,rep(.85,nt-1),10),
    cell.padding=c(0,0,0,0),track.margin=c(.003,.003),points.overflow.warning=FALSE,
    canvas.xlim=c(-1.24,1.24),canvas.ylim=c(-1.24,1.24))
  circos.initialize(factors=factor(sectors,levels=sectors),xlim=cbind(0,degree),
    sector.width=c(rep(1/ng,ng),tail(degree,nt)/sum(tail(degree,nt))))
  circos.trackPlotRegion(ylim=c(0,1),track.height=.045,bg.border=NA,panel.fun=function(x,y){
    s<-CELL_META$sector.index
    circos.rect(CELL_META$xlim[1],0,CELL_META$xlim[2],1,col=color[s],border='white',lwd=.5)
    if(s %in% genes)circos.text(CELL_META$xcenter,1.8,s,facing='clockwise',niceFacing=TRUE,adj=c(0,.5),cex=if(compact).70 else .82)
  })
  offsets<-setNames(rep(0,length(sectors)),sectors)
  e<-e[order(e$Term_rank,e$Gene_symbol),]
  for(i in seq_len(nrow(e))){g<-e$Gene_symbol[i];t<-e$Term_ID[i]
    circos.link(g,c(offsets[g],offsets[g]+1),t,c(offsets[t],offsets[t]+1),rou=.947,
      col=adjustcolor(color[t],alpha.f=.60),border=NA)
    offsets[g]<-offsets[g]+1;offsets[t]<-offsets[t]+1
  }
  title(paste0('GO-',domain),line=.6,cex.main=if(compact)1.25 else 1.45,font.main=1)
  circos.clear()
}
chord_legend<-function(domain,compact=FALSE){
  terms<-obj$selected[[domain]]$ID;nt<-length(terms);nc<-if(compact)3 else 5
  z<-data.frame(ID=terms,x=(seq_len(nt)-1)%%nc,y=-floor((seq_len(nt)-1)/nc),Color=np[seq_len(nt)])
  ggplot(z,aes(x=x,y=y))+geom_point(aes(color=Color),shape=15,size=if(compact)1.5 else 2)+scale_color_identity()+
    geom_text(aes(x=x+.08,label=ID),hjust=0,size=(if(compact)7.0 else 9.0)/ggplot2::.pt,family='Arial')+
    coord_cartesian(xlim=c(-.08,nc-.15),ylim=c(min(z$y)-.5,.5),clip='off')+theme_void()+theme(plot.margin=margin(0,5,3,5))
}
build_chord<-function(domain,compact=FALSE){
  body<-as.ggplot(function()draw_chord(domain,compact))
  (body/chord_legend(domain,compact))+plot_layout(heights=c(if(compact)4 else 6.5,if(compact).75 else .7))
}
C<-lapply(c('BP','CC','MF'),function(domain)build_chord(domain));names(C)<-c('BP','CC','MF')
Cmain<-lapply(c('BP','CC','MF'),function(domain)build_chord(domain,TRUE));names(Cmain)<-c('BP','CC','MF')
nodes<-read.csv(file.path(root,'各子图数据表','D_网络节点及固定坐标.csv'),fileEncoding='UTF-8-BOM',check.names=FALSE)
edges<-read.csv(file.path(root,'各子图数据表','D_网络连线.csv'),fileEncoding='UTF-8-BOM',check.names=FALSE)
a<-match(edges$Source,nodes$Node_ID);b<-match(edges$Target,nodes$Node_ID)
segments<-data.frame(x=nodes$x[a],y=nodes$y[a],xend=nodes$x[b],yend=nodes$y[b])
circles<-do.call(rbind,lapply(seq_len(nrow(nodes)),function(i){angle<-seq(0,2*pi,length.out=81)
  data.frame(Node_ID=nodes$Node_ID[i],x=nodes$x[i]+nodes$Diameter[i]/2*cos(angle),
  y=nodes$y[i]+nodes$Diameter[i]/2*sin(angle),Fill=nodes$Fill[i])}))
D<-ggplot()+geom_segment(data=segments,aes(x=x,y=y,xend=xend,yend=yend),color='#818181',alpha=.40,linewidth=.18)+
  geom_polygon(data=circles,aes(x=x,y=y,group=Node_ID,fill=Fill),color='white',linewidth=.20)+scale_fill_identity()+
  geom_text(data=nodes,aes(x=x,y=y,label=Label,size=Font_pt/ggplot2::.pt),family='Arial',color='#1A1A1A')+
  scale_size_identity()+coord_fixed(xlim=c(0,16),ylim=c(0,8.6),expand=FALSE,clip='off')+
  labs(title='GO functions – candidate genes – KEGG pathways')+theme_void(base_family='Arial')+
  theme(plot.title=element_text(size=15,hjust=.5,margin=margin(b=8)),plot.margin=margin(8,7,7,7))
# Keep all panels vector-based. Base graphics are captured as grid grobs.
tag_theme<-theme(plot.tag=element_text(size=20,family='Times New Roman'),plot.tag.position=c(0,1))
main<-((wrap_elements(full=A)+labs(tag='A')+tag_theme)|(wrap_elements(full=B)+labs(tag='B')+tag_theme))/
  ((wrap_elements(full=Cmain$BP)+labs(tag='C')+tag_theme)|wrap_elements(full=Cmain$CC)|wrap_elements(full=Cmain$MF))/
  (D+labs(tag='D')+tag_theme)+plot_layout(heights=c(5.4,4.7,7.4))
plots<-list(
  '图4_组合主图'=list(p=main,w=14,h=17.5),
  '图4A_GO富集柱图'=list(p=A,w=9,h=6.3),
  '图4B_KEGG通路图'=list(p=B,w=8,h=6.3),
  '图4C_BP基因弦图'=list(p=C$BP,w=7.6,h=7.6),
  '图4C_CC基因弦图'=list(p=C$CC,w=7.6,h=7.6),
  '图4C_MF基因弦图'=list(p=C$MF,w=7.6,h=7.6),
  '图4D_功能靶点通路网络'=list(p=D,w=16,h=8.6))
manifest<-list()
for(nm in names(plots)){
  x<-plots[[nm]];message('Rendering ',nm)
  ggsave(file.path(qa,paste0(nm,'_preview.png')),x$p,width=x$w,height=x$h,dpi=120,device=ragg::agg_png,bg='white')
  if(export){
    ggsave(file.path(out,paste0(nm,'.png')),x$p,width=x$w,height=x$h,dpi=600,device=ragg::agg_png,bg='white')
    ggsave(file.path(out,paste0(nm,'.svg')),x$p,width=x$w,height=x$h,device=svglite::svglite,bg='white')
    ggsave(file.path(pdir,paste0(nm,'.pdf')),x$p,width=x$w,height=x$h,device=grDevices::cairo_pdf,family='Arial',bg='white')
  }
  saveRDS(x$p,file.path(audit,'R对象',paste0(nm,'_绘图对象.rds')))
  manifest[[nm]]<-list(width_inches=x$w,height_inches=x$h,dpi=600,formats=c('png','svg','pdf'),panel_letters=nm=='图4_组合主图')
}
write_json(manifest,file.path(audit,'图像尺寸与格式.json'),auto_unbox=TRUE,pretty=TRUE)
write_json(list(reference_DOI='10.1186/s40643-026-01083-8',bars=as.list(pal),chord_terms=as.list(np),
  network=as.list(setNames(c('#87CEEB','#F4A06F','#FFFF39','#35FF19','#9A96EF'),c('Gene','BP','CC','MF','KEGG'))),
  chord_gene_sectors='Equal angular widths; term sector widths proportional to binary annotation counts',
  link_interpretation='Binary gene-term annotation, not gene expression, effect size or causality'),file.path(audit,'配色与图形规则.json'),auto_unbox=TRUE,pretty=TRUE)
message('PLOTTING COMPLETE')
if(!is.null(warnings()))writeLines(capture.output(warnings()),file.path(audit,'R绘图警告.txt'))
