options(stringsAsFactors=FALSE,timeout=60)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(clusterProfiler);library(org.Hs.eg.db);library(GO.db);library(AnnotationDbi);library(jsonlite)})
script_arg<-grep('^--file=',commandArgs(),value=TRUE)
script_dir<-if(length(script_arg))dirname(normalizePath(sub('^--file=','',script_arg[1]),winslash='/'))else''
root<-if(basename(script_dir)=='处理记录')dirname(script_dir)else'./Computational/8.图4_GO_KEGG与功能网络'
raw<-file.path(root,'原始数据');audit<-file.path(root,'处理记录');tables<-file.path(root,'各子图数据表')
for(p in c(root,raw,audit,tables,file.path(audit,'R对象')))dir.create(p,recursive=TRUE,showWarnings=FALSE)
write_csv<-function(x,p){con<-file(p,'wb');writeBin(charToRaw('\xef\xbb\xbf'),con);writeBin(charToRaw(enc2utf8(paste(capture.output(write.csv(x,row.names=FALSE,na='')),collapse='\n'))),con);close(con)}
write_tsv<-function(x,p)write.table(x,p,sep='\t',quote=FALSE,row.names=FALSE,na='',fileEncoding='UTF-8')
local_input<-file.path(raw,'输入_49个交集靶点.csv')
source<-if(file.exists(local_input))local_input else'./Computational/5.gutMGene宿主基因交集_图2C/图2C_交集靶点_49个.csv'
input<-read.csv(source,fileEncoding='UTF-8-BOM',colClasses='character',check.names=FALSE)
genes<-sort(unique(trimws(input$Gene_symbol)));stopifnot(length(genes)==49,nrow(input)==49)
mapping<-AnnotationDbi::select(org.Hs.eg.db,keys=genes,keytype='SYMBOL',columns='ENTREZID')
mapping<-unique(mapping[,c('SYMBOL','ENTREZID')]);stopifnot(!anyNA(mapping$ENTREZID),!anyDuplicated(mapping$SYMBOL),!anyDuplicated(mapping$ENTREZID))
mapping<-mapping[match(genes,mapping$SYMBOL),];mapping$gutMGene_EntrezID<-input$gutMGene_Gene_IDs[match(mapping$SYMBOL,input$Gene_symbol)]
mapping$Agrees_with_gutMGene_ID<-mapping$ENTREZID==mapping$gutMGene_EntrezID
stopifnot(all(mapping$Agrees_with_gutMGene_ID))
write_csv(mapping,file.path(tables,'输入49基因_Entrez映射.csv'))
if(normalizePath(source,winslash='/')!=normalizePath(local_input,winslash='/',mustWork=FALSE))file.copy(source,local_input,overwrite=TRUE)
query<-as.character(mapping$ENTREZID);symbols<-setNames(mapping$SYMBOL,mapping$ENTREZID)

# Reuse the full official human KEGG annotation snapshot, not the previous
# 224-gene results or its measured-expression background.
prior<-if(file.exists(file.path(raw,'KEGG_hsa_ncbi_geneid_GSON.rds')))raw else'./local_workspace/CC_gutMGene_followup/data/raw/enrichment_224_clusterProfiler'
for(nm in c('KEGG_hsa_ncbi_geneid_GSON.rds','KEGG_GSON_provenance.json','KEGG_gsid2gene.tsv','KEGG_gsid2name.tsv'))
  if(normalizePath(prior,winslash='/')!=normalizePath(raw,winslash='/'))stopifnot(file.copy(file.path(prior,nm),file.path(raw,nm),overwrite=TRUE))
kg<-readRDS(file.path(raw,'KEGG_hsa_ncbi_geneid_GSON.rds'))
write_tsv(AnnotationDbi::metadata(org.Hs.eg.db),file.path(raw,'org.Hs.eg.db_metadata.tsv'))
write_tsv(AnnotationDbi::metadata(GO.db),file.path(raw,'GO.db_metadata.tsv'))
writeLines(capture.output(sessionInfo()),file.path(audit,'R_sessionInfo.txt'))
pkgs<-c('clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi','gson','ggplot2','circlize','ggplotify','gridGraphics','patchwork','ragg','svglite')
write_csv(data.frame(Package=pkgs,Version=vapply(pkgs,function(p)as.character(packageVersion(p)),'')),file.path(audit,'R软件版本.csv'))
writeLines(capture.output(citation('clusterProfiler')),file.path(audit,'clusterProfiler引用.txt'))
res<-list();top<-list();summaries<-list();links<-list();validations<-list();membership<-list()
for(domain in c('BP','CC','MF','KEGG')){
  message('Analyzing ',domain)
  if(domain=='KEGG')obj<-enrichKEGG(gene=query,organism=kg,keyType='ncbi-geneid',pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,use_internal_data=FALSE)
  else obj<-enrichGO(gene=query,OrgDb=org.Hs.eg.db,keyType='ENTREZID',ont=domain,pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,readable=FALSE)
  stopifnot(inherits(obj,'enrichResult'))
  saveRDS(obj,file.path(audit,'R对象',paste0(domain,'_enrichResult.rds')))
  df<-obj@result;df$Domain<-domain
  df$Gene_symbols<-vapply(strsplit(df$geneID,'/',fixed=TRUE),function(g)paste(sort(unique(na.omit(symbols[g]))),collapse='/'),'')
  df$BH_significant<-!is.na(df$p.adjust)&df$p.adjust<.05&df$FoldEnrichment>1
  df$GeneRatio_numeric<-vapply(strsplit(df$GeneRatio,'/',fixed=TRUE),function(x)as.numeric(x[1])/as.numeric(x[2]),0.)
  df$Minus_log10_P<--log10(pmax(df$pvalue,.Machine$double.xmin))
  df$Minus_log10_FDR<--log10(pmax(df$p.adjust,.Machine$double.xmin))
  write_csv(df,file.path(tables,paste0(domain,'_全部富集检验.csv')))
  write_csv(df[df$BH_significant,],file.path(tables,paste0(domain,'_BH显著富集结果.csv')))
  if(domain=='KEGG')z<-df[df$BH_significant,][order(df[df$BH_significant,]$pvalue,df[df$BH_significant,]$p.adjust,df[df$BH_significant,]$ID),]
  else z<-df[df$BH_significant,][order(df[df$BH_significant,]$p.adjust,df[df$BH_significant,]$pvalue,df[df$BH_significant,]$ID),]
  z<-head(z,10);z$Selected_rank<-seq_len(nrow(z));top[[domain]]<-z;res[[domain]]<-df
  # Archive only foreground memberships and the full effective background IDs.
  member<-do.call(rbind,lapply(names(obj@geneSets),function(id){g<-intersect(query,obj@geneSets[[id]]);if(!length(g))return(NULL);data.frame(Domain=domain,Term_ID=id,EntrezID=g,Gene_symbol=unname(symbols[g]))}))
  membership[[domain]]<-member
  write_csv(data.frame(EntrezID=obj@universe,In_query=obj@universe %in% query),file.path(raw,paste0(domain,'_有效背景基因.csv')))
  bg<-do.call(rbind,strsplit(df$BgRatio,'/'));gr<-do.call(rbind,strsplit(df$GeneRatio,'/'))
  p<-phyper(df$Count-1,as.numeric(bg[,1]),as.numeric(bg[,2])-as.numeric(bg[,1]),as.numeric(gr[,2]),lower.tail=FALSE)
  maxp<-max(abs(p-df$pvalue));maxbh<-max(abs(p.adjust(df$pvalue,'BH')-df$p.adjust))
  countok<-all(vapply(seq_len(nrow(df)),function(i)length(intersect(query,obj@geneSets[[df$ID[i]]]))==df$Count[i],TRUE))
  stopifnot(maxp<1e-10,maxbh<1e-10,countok)
  validations[[domain]]<-data.frame(Domain=domain,Max_P_difference=maxp,Max_BH_difference=maxbh,Count_membership_check=countok)
  summaries[[domain]]<-data.frame(Domain=domain,Input_unique_Entrez=length(query),Effective_foreground=length(intersect(query,obj@universe)),
      Effective_background=length(obj@universe),Tested_terms=nrow(df),Zero_hit_terms=sum(df$Count==0),BH_significant_terms=sum(df$BH_significant),
      Displayed_terms=nrow(z),Minimum_FDR=min(df$p.adjust))
}
go<-do.call(rbind,top[c('BP','CC','MF')]);rownames(go)<-NULL
write_csv(go,file.path(tables,'A_GO三类前10_绘图数据.csv'));write_csv(top$KEGG,file.path(tables,'B_KEGG前10_绘图数据.csv'))
for(domain in c('BP','CC','MF')){
  z<-top[[domain]];edge<-membership[[domain]][membership[[domain]]$Term_ID %in% z$ID,]
  edge$Term_description<-z$Description[match(edge$Term_ID,z$ID)];edge$Term_rank<-z$Selected_rank[match(edge$Term_ID,z$ID)];edge$Weight<-1L
  links[[domain]]<-edge;write_csv(edge,file.path(tables,paste0('C_',domain,'_术语基因连线.csv')))
  mat<-table(factor(edge$Gene_symbol,levels=sort(unique(edge$Gene_symbol))),factor(edge$Term_ID,levels=z$ID))
  matrix_out<-data.frame(Gene_symbol=rownames(mat),as.data.frame.matrix(mat),check.names=FALSE)
  write_csv(matrix_out,file.path(tables,paste0('C_',domain,'_二值关联矩阵.csv')))
}
klinks<-membership$KEGG[membership$KEGG$Term_ID %in% top$KEGG$ID,]
klinks$Term_description<-top$KEGG$Description[match(klinks$Term_ID,top$KEGG$ID)]
klinks$Term_rank<-top$KEGG$Selected_rank[match(klinks$Term_ID,top$KEGG$ID)];klinks$Weight<-1L
all_links<-rbind(do.call(rbind,links),klinks)
write_csv(all_links,file.path(tables,'D_全部术语基因注释.csv'))
write_csv(do.call(rbind,summaries),file.path(tables,'富集分析汇总.csv'))
write_csv(do.call(rbind,validations),file.path(audit,'R数值独立核对.csv'))
write_csv(do.call(rbind,membership),file.path(raw,'49输入基因_全部被检验术语注释.csv'))
protocol<-list(engine='clusterProfiler::enrichGO and enrichKEGG; unmodified functions',input_count=49,
    input_scope='All Figure2C candidate genes, not only the six Figure3 hubs and not the 46 connected STRING proteins',
    organism='Homo sapiens',GO_annotation='org.Hs.eg.db GOALL, ancestor-propagated annotations; BP/CC/MF separately',
    KEGG_annotation='Official human KEGG GSON snapshot retrieved 2026-10-18, archived locally',
    background='All human genes annotated in the respective database/ontology; package default universe, not the 49 input genes or the earlier RNA expression background',
    pAdjustMethod='BH',pvalueCutoff=1,qvalueCutoff=1,minGSSize=10,maxGSSize=500,
    significance='BH adjusted P < 0.05 and FoldEnrichment > 1; no extra Storey qvalue screen',
    GO_top_selection='At most ten significant terms per ontology; ascending BH adjusted P, then nominal P, then term ID',
    KEGG_top_selection='At most ten BH-significant pathways, ordered by nominal P, then adjusted P, then pathway ID',
    A_y_axis='-log10(BH adjusted P)',B_x_axis='-log10(nominal P)',
    reference_difference='Reference uses DAVID; this run uses the R package requested earlier. Annotation release, default term-size limits and statistical engine may change terms and P values.',
    reference_DOI='10.1186/s40643-026-01083-8',reference_figure='4A-D',summary=do.call(rbind,summaries))
write_json(protocol,file.path(audit,'analysis_protocol.json'),auto_unbox=TRUE,pretty=TRUE)
saveRDS(list(input=input,mapping=mapping,results=res,selected=top,links=links,all_links=all_links,summary=summaries,protocol=protocol),file.path(audit,'R对象','图4完整分析对象.rds'))
message('ENRICHMENT COMPLETE');print(do.call(rbind,summaries),row.names=FALSE)
