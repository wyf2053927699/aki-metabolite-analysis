from pathlib import Path
import pandas as pd
import numpy as np
from scipy.stats import hypergeom
import json, math, re, xml.etree.ElementTree as ET
from PIL import Image
from pypdf import PdfReader
import openpyxl

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/8.图4_GO_KEGG与功能网络')
A=ROOT/'处理记录';T=ROOT/'各子图数据表';checks=[]
def check(name,ok,detail=''):
    checks.append({'Check':name,'Passed':bool(ok),'Detail':str(detail)})
def read(n):return pd.read_csv(T/n,encoding='utf-8-sig',keep_default_na=False)
def members(s):return set(s.split('/')) if s else set()
mapping=read('输入49基因_Entrez映射.csv');genes=set(mapping.SYMBOL)
check('49 unique input genes',len(genes)==49 and len(mapping)==49)
check('one-to-one Entrez mapping',mapping.ENTREZID.nunique()==49)
check('all mapped IDs agree with gutMGene',mapping.Agrees_with_gutMGene_ID.all())
check('VDR VEGFA ST6GAL1 retained',{'VDR','VEGFA','ST6GAL1'}<=genes)
summary=read('富集分析汇总.csv').set_index('Domain')
go=read('A_GO三类前10_绘图数据.csv');kegg=read('B_KEGG前10_绘图数据.csv')
selected=pd.concat([go,kegg],ignore_index=True)
allmembership=pd.read_csv(ROOT/'原始数据'/'49输入基因_全部被检验术语注释.csv',encoding='utf-8-sig')
for domain in ['BP','CC','MF','KEGG']:
    full=read(domain+'_全部富集检验.csv');sig=read(domain+'_BH显著富集结果.csv')
    bg=full.BgRatio.str.split('/',expand=True).astype(int);fg=full.GeneRatio.str.split('/',expand=True).astype(int)
    computed=hypergeom.sf(full.Count.to_numpy()-1,bg[1].to_numpy(),bg[0].to_numpy(),fg[1].to_numpy())
    relative=np.abs(computed-full.pvalue.to_numpy())/np.maximum(computed,np.finfo(float).tiny)
    check(domain+' independent hypergeometric P',np.max(relative)<1e-8,'max relative difference='+str(relative.max()))
    order=np.argsort(full.pvalue.to_numpy());p=full.pvalue.to_numpy()[order];m=len(p)
    bh_sorted=np.minimum.accumulate((p*m/np.arange(1,m+1))[::-1])[::-1];bh=np.empty(m);bh[order]=np.minimum(bh_sorted,1)
    check(domain+' independent BH adjustment',np.allclose(full['p.adjust'],bh,rtol=1e-12,atol=0))
    expected=full[(full['p.adjust']<.05)&(full.FoldEnrichment>1)]
    check(domain+' significant set matches',set(expected.ID)==set(sig.ID))
    z=selected[selected.Domain==domain]
    sort=['pvalue','p.adjust','ID'] if domain=='KEGG' else ['p.adjust','pvalue','ID']
    check(domain+' top selection',list(expected.sort_values(sort).head(10).ID)==list(z.ID))
    check(domain+' summary counts',len(full)==summary.loc[domain,'Tested_terms'] and len(sig)==summary.loc[domain,'BH_significant_terms'] and len(z)==summary.loc[domain,'Displayed_terms'])
    check(domain+' term size 10 to 500',bg[0].between(10,500).all())
    bgids=pd.read_csv(ROOT/'原始数据'/(domain+'_有效背景基因.csv'),encoding='utf-8-sig')
    check(domain+' archived background count',len(bgids)==summary.loc[domain,'Effective_background'])
    for _,r in z.iterrows():
        observed=set(allmembership.loc[(allmembership.Domain==domain)&(allmembership.Term_ID==r.ID),'Gene_symbol'])
        check(r.ID+' selected gene count',len(members(r.Gene_symbols))==r.Count and members(r.Gene_symbols)==observed)
check('CC only 4 significant terms, not padded',(go.Domain=='CC').sum()==4)
check('A uses adjusted P score',np.allclose(go.Minus_log10_FDR,-np.log10(go['p.adjust']),rtol=1e-12))
check('B uses nominal P score',np.allclose(kegg.Minus_log10_P,-np.log10(kegg.pvalue),rtol=1e-12))
for domain in ['BP','CC','MF']:
    e=read('C_'+domain+'_术语基因连线.csv');mat=read('C_'+domain+'_二值关联矩阵.csv').set_index('Gene_symbol')
    actual={(r.Term_ID,r.Gene_symbol) for _,r in e.iterrows()}
    expected={(r.ID,g) for _,r in go[go.Domain==domain].iterrows() for g in members(r.Gene_symbols)}
    check('C '+domain+' edge membership',actual==expected and len(e)==len(actual))
    frommat={(term,g) for g,row in mat.iterrows() for term,v in row.items() if v==1}
    check('C '+domain+' binary matrix',frommat==actual and np.isin(mat.values,[0,1]).all())
nodes=read('D_网络节点及固定坐标.csv');edges=read('D_网络连线.csv')
check('D has all 49 input gene nodes',set(nodes.loc[nodes.Node_type=='Gene','Label'])==genes)
check('D has all displayed term nodes',set(nodes.loc[nodes.Node_type=='Term','Node_ID'])==set(selected.ID))
check('D exact node count',len(nodes)==49+len(selected)+4 and nodes.Node_ID.nunique()==len(nodes))
check('D no duplicate edges',len(edges)==len(edges.drop_duplicates(['Source','Target'])))
check('D no absent endpoints',(set(edges.Source)|set(edges.Target))<=set(nodes.Node_ID))
actual={(r.Source,r.Target) for _,r in edges[edges.Edge_type=='gene_annotation'].iterrows()}
expected={(r.ID,'gene:'+g) for _,r in selected.iterrows() for g in members(r.Gene_symbols)}
check('D gene-term edges match enrichment',actual==expected)
check('D annotation edge count',len(actual)==int(selected.Count.sum()))
check('D class-term edges',len(edges[edges.Edge_type=='category_membership'])==len(selected))
check('D circular nodes within drawing area',((nodes.x-nodes.Diameter/2>0)&(nodes.x+nodes.Diameter/2<16)&(nodes.y-nodes.Diameter/2>0)&(nodes.y+nodes.Diameter/2<8.6)).all())
for i,r in nodes.iterrows():
    count=sum((edges.Source==r.Node_ID)&(edges.Edge_type=='gene_annotation'))+sum((edges.Target==r.Node_ID)&(edges.Edge_type=='gene_annotation'))
    if r.Node_type!='Category':check('D degree '+r.Node_ID,count==r.Annotation_degree)
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
graph=ET.parse(ROOT/'可编辑网络'/'图4D_功能靶点通路网络.graphml')
check('GraphML node/edge roundtrip',len(graph.findall('.//g:node',ns))==len(nodes) and len(graph.findall('.//g:edge',ns))==len(edges))

# Read-only roundtrip validation of every exported worksheet cell.
payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf-8'))
wb=openpyxl.load_workbook(ROOT/'图4_全部子图数据与参数.xlsx',data_only=False)
cached=openpyxl.load_workbook(ROOT/'图4_全部子图数据与参数.xlsx',data_only=True)
check('Workbook exact sheet list',wb.sheetnames==[s['name'] for s in payload['sheets']])
formula_count=0
for s in payload['sheets']:
    sheet=wb[s['name']];data=cached[s['name']];mismatches=[]
    for i,row in enumerate(s['rows'],8):
        for j,expected in enumerate(row,1):
            value=data.cell(i,j).value
            if expected=='':ok=value in ('',None)
            elif isinstance(expected,bool):ok=value==expected
            elif isinstance(expected,(float,int)):
                ok=isinstance(value,(float,int)) and not isinstance(value,bool) and math.isclose(value,expected,rel_tol=1e-12,abs_tol=1e-300)
            else:ok=str(value)==str(expected)
            if not ok:mismatches.append((i,j,expected,value))
            formula_count+=sheet.cell(i,j).data_type=='f'
    check('Excel '+s['name']+' data roundtrip',not mismatches,str(mismatches[:3]))
    check('Excel '+s['name']+' record counter',data['B6'].value==len(s['rows']))
    check('Excel '+s['name']+' freeze panes',sheet.freeze_panes=='B8')
    check('Excel '+s['name']+' native filter table',len(sheet.tables)==1)
    errors=[c.coordinate for row in data for c in row if c.data_type=='e']
    check('Excel '+s['name']+' no formula errors',not errors,str(errors[:5]))
check('34 score formulas present',formula_count==34,formula_count)
for name in ['A_GO柱图','B_KEGG通路']:
    data=cached[name]
    cols=[i+1 for i,v in enumerate(payload['sheets'][1 if name=='A_GO柱图' else 2]['fields']) if v in ['pvalue','p.adjust']]
    check('Excel '+name+' tiny P values remain positive',all(data.cell(i,j).value>0 for i in range(8,data.max_row+1) for j in cols))

manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
check('Seven graphic variants',len(manifest)==7)
for name,spec in manifest.items():
    p=ROOT/'图片'/(name+'.png');im=Image.open(p)
    check(name+' PNG 600dpi dimensions',im.size==(round(spec['width_inches']*600),round(spec['height_inches']*600)),im.size)
    check(name+' PNG dpi metadata',all(abs(x-600)<.1 for x in im.info.get('dpi',(0,0))),im.info.get('dpi'))
    svg=ET.parse(ROOT/'图片'/(name+'.svg'))
    text=''.join(svg.getroot().itertext())
    check(name+' SVG no raster images',len(svg.findall('.//{http://www.w3.org/2000/svg}image'))==0)
    if name=='图4_组合主图' or name=='图4D_功能靶点通路网络':check(name+' SVG has all49 gene labels',all(g in text for g in genes))
pdf=PdfReader(ROOT/'图4_主图与全部子图.pdf')
check('PDF 7 pages',len(pdf.pages)==7)
embedded=[]
for i,page in enumerate(pdf.pages,1):
    check('PDF page '+str(i)+' vector graphics',len(page.images)==0)
    check('PDF page '+str(i)+' text present',len(page.extract_text())>80)
    fonts=page['/Resources'].get('/Font',{})
    for font in fonts.values():
        f=font.get_object();children=f.get('/DescendantFonts',[f])
        for child in children:
            fontobj=child.get_object();desc=fontobj.get('/FontDescriptor')
            if desc:
                desc=desc.get_object();embedded.append(any(k in desc for k in ['/FontFile','/FontFile2','/FontFile3']))
check('PDF all fonts embedded',bool(embedded) and all(embedded),len(embedded))
check('All PDF pages rendered',len(list((A/'PDF预览').glob('图4-*.png')))==7)
pd.DataFrame(checks).to_csv(A/'完整复核结果.csv',index=False,encoding='utf-8-sig')
report={'checks':len(checks),'passed':sum(c['Passed'] for c in checks),'failed':[c for c in checks if not c['Passed']],
 'nodes':len(nodes),'edges':len(edges),'gene_annotation_edges':len(actual),'score_formulas':formula_count,'pdf_pages':len(pdf.pages),
 'all_significant_counts':summary.BH_significant_terms.to_dict()}
(A/'validation_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
assert not report['failed']
