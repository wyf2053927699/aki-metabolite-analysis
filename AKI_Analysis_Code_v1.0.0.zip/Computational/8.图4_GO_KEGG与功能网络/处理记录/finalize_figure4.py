from pathlib import Path
import json, shutil, subprocess
from pypdf import PdfReader, PdfWriter
from PIL import Image, ImageOps, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/8.图4_GO_KEGG与功能网络')
A=ROOT/'处理记录'; Q=A/'PDF预览';Q.mkdir(exist_ok=True)
manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
writer=PdfWriter()
for name in manifest:
    source=A/'单页PDF'/(name+'.pdf')
    assert len(PdfReader(source).pages)==1
    writer.append(str(source),outline_item=name)
writer.add_metadata({'/Title':'Figure 4 - GO and KEGG enrichment of 49 AKI candidate genes','/Author':'Research analysis','/Subject':'clusterProfiler GO/KEGG enrichment, chord diagrams and annotation network'})
output=ROOT/'图4_主图与全部子图.pdf'
with output.open('wb') as f: writer.write(f)
exe=Path('./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
proc=subprocess.run([str(exe),'-r','100','-png',str(output),str(Q/'图4')],capture_output=True,text=True)
(A/'PDF渲染日志.txt').write_text(proc.stdout+proc.stderr,encoding='utf-8')
assert proc.returncode==0
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
def contact(files,dest,cols=2,width=880):
    tileh=620
    canvas=Image.new('RGB',(cols*width,((len(files)+cols-1)//cols)*tileh),'#E4E7EB')
    d=ImageDraw.Draw(canvas)
    for i,f in enumerate(files):
        im=Image.open(f).convert('RGB');im.thumbnail((width-28,tileh-48))
        x=(i%cols)*width;y=(i//cols)*tileh
        d.text((x+14,y+8),f.stem,font=font,fill='#263648')
        canvas.paste(im,(x+(width-im.width)//2,y+38))
    canvas.save(dest)
contact(sorted(Q.glob('图4-*.png')),A/'PDF全部页面_检查总览.png',2,880)
excel=sorted(A.glob('Excel预览_*.png'))
for i in range(0,len(excel),4):contact(excel[i:i+4],A/f'Excel检查总览_{i//4+1}.png',1,1400)
im=Image.open(A/'图片预览'/'图4_组合主图_preview.png').convert('L')
im.save(A/'图片预览'/'图4_组合主图_灰度检查.png')
print(json.dumps({'pdf':str(output),'pages':len(writer.pages),'rendered_pages':len(list(Q.glob('图4-*.png')))},ensure_ascii=False))
