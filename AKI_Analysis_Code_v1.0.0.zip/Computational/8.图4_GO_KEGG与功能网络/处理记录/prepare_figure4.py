from pathlib import Path
import pandas as pd
import numpy as np
import math, json, hashlib, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/8.图4_GO_KEGG与功能网络')
T=ROOT/'各子图数据表'; A=ROOT/'处理记录'
def read(name): return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False)
def write(df,name): df.to_csv(T/name,index=False,encoding='utf-8-sig')
go=read('A_GO三类前10_绘图数据.csv'); kegg=read('B_KEGG前10_绘图数据.csv')
terms=pd.concat([go,kegg],ignore_index=True)
links=read('D_全部术语基因注释.csv')
mapping=read('输入49基因_Entrez映射.csv')
summary=read('富集分析汇总.csv')
colors={'Gene':'#87CEEB','BP':'#F4A06F','CC':'#FFFF39','MF':'#35FF19','KEGG':'#9A96EF'}
centers={'BP':(2,6.5),'CC':(2,2.1),'MF':(14,6.5),'KEGG':(14,2.1)}
nodes=[];edges=[]
for i,r in mapping.iterrows():
    ring=0 if i<25 else 1; j=i if ring==0 else i-25; n=25 if ring==0 else 24
    angle=math.pi/2-2*math.pi*j/n; radius=3 if ring==0 else 2.4
    gene=r.SYMBOL; degree=int((links.Gene_symbol==gene).sum())
    nodes.append(dict(Node_ID='gene:'+gene,Label=gene,Node_type='Gene',Domain='Gene',EntrezID=str(r.ENTREZID),
        Description=gene,Annotation_degree=degree,x=8+radius*math.cos(angle),y=4.3+radius*math.sin(angle),
        Diameter=.57,Font_pt=8.1,Fill=colors['Gene'],Display_order=i+1))
for domain in centers:
    z=terms[terms.Domain==domain]; cx,cy=centers[domain]
    nodes.append(dict(Node_ID='category:'+domain,Label=domain,Node_type='Category',Domain=domain,EntrezID='',
        Description={'BP':'Biological process','CC':'Cellular component','MF':'Molecular function','KEGG':'KEGG pathway'}[domain],
        Annotation_degree=len(z),x=cx,y=cy,Diameter=.90,Font_pt=12,Fill=colors[domain],Display_order=len(nodes)+1))
    for j,(_,r) in enumerate(z.iterrows()):
        angle=math.pi/2-2*math.pi*j/len(z)
        nodes.append(dict(Node_ID=r.ID,Label=r.ID,Node_type='Term',Domain=domain,EntrezID='',Description=r.Description,
            Annotation_degree=int(r.Count),x=cx+1.3*math.cos(angle),y=cy+1.3*math.sin(angle),Diameter=.76,
            Font_pt=7.7,Fill=colors[domain],Display_order=len(nodes)+1))
        edges.append(dict(Source='category:'+domain,Target=r.ID,Edge_type='category_membership',Domain=domain,Weight=1))
for _,r in links.iterrows(): edges.append(dict(Source=r.Term_ID,Target='gene:'+r.Gene_symbol,Edge_type='gene_annotation',Domain=r.Domain,Weight=1))
nodes=pd.DataFrame(nodes); edges=pd.DataFrame(edges)
assert len(nodes.Node_ID)==len(set(nodes.Node_ID))
assert len(edges)==len(edges.drop_duplicates(['Source','Target']))
assert set(edges.Source)|set(edges.Target) <= set(nodes.Node_ID)
write(nodes,'D_网络节点及固定坐标.csv'); write(edges,'D_网络连线.csv')
terms['Network_color']=terms.Domain.map(colors)
write(terms,'D_术语ID与名称对照.csv')
audit=mapping.copy(); audit['Displayed_term_annotation_count']=audit.SYMBOL.map(links.Gene_symbol.value_counts()).fillna(0).astype(int)
audit['In_GO_BP']=True;audit['In_GO_CC']=True;audit['In_GO_MF']=True
kbg=pd.read_csv(ROOT/'原始数据'/'KEGG_有效背景基因.csv',encoding='utf-8-sig',dtype={'EntrezID':str})
audit['In_KEGG']=audit.ENTREZID.astype(str).isin(kbg.EntrezID)
write(audit,'输入49基因_覆盖与绘图注释核对.csv')
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
graphml=ET.Element('{'+ns+'}graphml')
for c in nodes.columns:
    if c=='Node_ID':continue
    dtype='double' if c in ['x','y','Diameter','Font_pt'] else 'int' if c in ['Annotation_degree','Display_order'] else 'string'
    ET.SubElement(graphml,'{'+ns+'}key',id='n_'+c,**{'for':'node','attr.name':c,'attr.type':dtype})
for c in ['Edge_type','Domain','Weight']: ET.SubElement(graphml,'{'+ns+'}key',id='e_'+c,**{'for':'edge','attr.name':c,'attr.type':'int' if c=='Weight' else 'string'})
graph=ET.SubElement(graphml,'{'+ns+'}graph',id='Figure4D',edgedefault='undirected')
for r in nodes.to_dict('records'):
    el=ET.SubElement(graph,'{'+ns+'}node',id=r['Node_ID'])
    for c,v in r.items():
        if c!='Node_ID':ET.SubElement(el,'{'+ns+'}data',key='n_'+c).text=str(v)
for i,r in enumerate(edges.to_dict('records')):
    el=ET.SubElement(graph,'{'+ns+'}edge',id='e'+str(i),source=r['Source'],target=r['Target'])
    for c in ['Edge_type','Domain','Weight']:ET.SubElement(el,'{'+ns+'}data',key='e_'+c).text=str(r[c])
gdir=ROOT/'可编辑网络';gdir.mkdir(exist_ok=True)
ET.ElementTree(graphml).write(gdir/'图4D_功能靶点通路网络.graphml',encoding='utf-8',xml_declaration=True)

# Workbook source payload; numerical analyses remain in the archived R objects.
labels={'Domain':'类别','ID':'术语/通路ID','Description':'完整名称','Selected_rank':'展示顺序','Count':'命中基因数',
 'pvalue':'原始P值','p.adjust':'BH校正P值','Minus_log10_P':'−log10(原始P)','Minus_log10_FDR':'−log10(BH校正P)',
 'Gene_symbols':'命中基因','GeneRatio':'基因比例','BgRatio':'背景比例','FoldEnrichment':'富集倍数','SYMBOL':'基因符号',
 'ENTREZID':'Entrez ID','Term_ID':'术语ID','Gene_symbol':'基因符号','Term_description':'术语名称','Term_rank':'术语排名',
 'Weight':'权重','Node_ID':'节点ID','Label':'显示标签','Node_type':'节点类型','EntrezID':'Entrez ID',
 'Annotation_degree':'注释连线数','x':'固定坐标x','y':'固定坐标y','Diameter':'节点直径','Font_pt':'字号(pt)',
 'Fill':'填充色','Display_order':'节点绘制顺序','Source':'起点','Target':'终点','Edge_type':'连线类型',
 'gutMGene_EntrezID':'gutMGene Entrez ID','Agrees_with_gutMGene_ID':'ID一致',
 'Displayed_term_annotation_count':'展示术语注释数','In_KEGG':'具有KEGG注释',
 'In_GO_BP':'具有BP注释','In_GO_CC':'具有CC注释','In_GO_MF':'具有MF注释',
 'Input_unique_Entrez':'输入基因数','Effective_foreground':'有效前景数','Effective_background':'有效背景数',
 'Tested_terms':'检验条目数','Zero_hit_terms':'零命中条目数','BH_significant_terms':'BH显著条目数','Displayed_terms':'绘图条目数','Minimum_FDR':'最小BH校正P'}
sheets=[]
def add(name,key,df,title,notes,widths=None):
    fields=list(df.columns)
    if widths is None: widths=[75 if x in ['Description','Term_description','Gene_symbols','Value'] else 34 if x in ['Source','Target','Node_ID','ENTREZID','EntrezID'] else 23 for x in fields]
    # pandas.to_json defaults to 10 decimal places and can round very small P
    # values to zero. Keep native float64 values and let JSON preserve precision.
    values=df.astype(object).where(pd.notna(df),None).values.tolist()
    sheets.append(dict(name=name,key=key,fields=fields,labels=[labels.get(x,x) for x in fields],widths=widths,title=title,notes=(notes+['']*3)[:3],rows=values))
add('结果概览','summary',summary,'图4｜49个候选基因的GO与KEGG富集',[
 '阈值：BH校正P < 0.05 且富集倍数 > 1；GO三类分别校正。',
 'CC仅4项显著，按真实结果展示；A、C、D使用同一批展示术语。',
 '背景为对应数据库中所有已注释人类基因；完整检验结果见同名CSV。'])
fields=['Domain','Selected_rank','ID','Description','Count','pvalue','p.adjust','GeneRatio','BgRatio','FoldEnrichment','Minus_log10_FDR','Gene_symbols']
add('A_GO柱图','A',go[fields],'图4A｜GO三类显著富集绘图数据',[
 'BP/CC/MF最多各10项；按BH校正P、原始P、ID排序。','柱高为 −log10(BH校正P)；颜色沿用参考文献。','来源：R clusterProfiler::enrichGO；人类org.Hs.eg.db。'])
fields=['Selected_rank','ID','Description','Count','pvalue','p.adjust','GeneRatio','BgRatio','FoldEnrichment','Minus_log10_P','Gene_symbols']
add('B_KEGG通路','B',kegg[fields],'图4B｜KEGG前10条显著通路',[
 '先要求BH校正P < 0.05，再按原始P、校正P、ID取前10项。','柱长为 −log10(原始P)，黑点面积表示命中基因数。','来源：clusterProfiler::enrichKEGG；官方人类KEGG快照2026-10-18。'])
for domain in ['BP','CC','MF']:
    z=read('C_'+domain+'_术语基因连线.csv')
    add('C_'+domain+'弦图','C_'+domain,z,'图4C｜'+domain+'术语与基因的二值关联',[
        '每行代表一个“术语—基因”注释，Weight=1。','术语与图4A保持一致；颜色只区分术语，不代表表达上/下调。','配套二值矩阵见 C_'+domain+'_二值关联矩阵.csv。'])
add('D_网络节点','D_nodes',nodes,'图4D｜节点、颜色与固定排版坐标',[
 '包含全部49个输入基因、展示术语及4个类别中心。','节点颜色：基因蓝；BP橙；CC黄；MF绿；KEGG紫。','术语显示ID，完整名称见“术语释义”；节点位置仅用于排版。'])
add('D_网络连线','D_edges',edges,'图4D｜功能注释与类别归属连线',[
 'gene_annotation：术语—基因注释；category_membership：类别—术语归属。','这些边表示数据库注释，不表示PPI、因果或实验验证。','可编辑GraphML文件保存在“可编辑网络”文件夹。'])
add('术语释义','terms',terms[['Domain','Selected_rank','ID','Description','Count','p.adjust','Gene_symbols']],
    '图4C/D｜术语ID、完整名称与命中基因',[
 '图4D使用短ID改善标签可读性；每个ID在本表均可查到名称。','同一个术语对应的基因与A/B/C绘图数据完全一致。','GO：10个BP、4个CC、10个MF；KEGG：10条通路。'])
add('输入49基因','input',audit,'图4｜全部输入基因与数据库覆盖',[
 '输入：图2C_交集靶点_49个.csv；与先前224基因转录组分析的范围不同。','VDR、VEGFA与ST6GAL1保留；STRING中的映射或连通性不影响本分析。','展示术语注释数为0的基因仍保留在图4D；此处逐一记录。'])
protocol=json.loads((A/'analysis_protocol.json').read_text(encoding='utf-8'))
params=pd.DataFrame([{'Parameter':k,'Value':str(v) if not isinstance(v,(list,dict)) else json.dumps(v,ensure_ascii=False)} for k,v in protocol.items() if k!='summary'])
versions=pd.read_csv(A/'R软件版本.csv',encoding='utf-8-sig')
params=pd.concat([params,pd.DataFrame([{'Parameter':'Package: '+r.Package,'Value':r.Version} for _,r in versions.iterrows()])],ignore_index=True)
add('分析参数','parameters',params,'图4｜方法、注释版本与复现参数',[
 '参考文献 DOI：10.1186/s40643-026-01083-8；图4A–D。','原文使用DAVID；本次按用户既往要求使用R clusterProfiler。','完整R代码、R对象、背景基因及注释来源均已归档。'],[34,125])
(A/'workbook_payload.json').write_text(json.dumps({'sheets':sheets,'summary':{'workbook':'图4_全部子图数据与参数.xlsx'}},ensure_ascii=False,allow_nan=False),encoding='utf-8')
manifest=[]
for f in sorted((ROOT/'原始数据').glob('*')):
    if f.is_file():manifest.append({'File':str(f.relative_to(ROOT)).replace('\\','/'),'Bytes':f.stat().st_size,'SHA256':hashlib.sha256(f.read_bytes()).hexdigest()})
pd.DataFrame(manifest).to_csv(A/'输入与注释文件_SHA256.csv',index=False,encoding='utf-8-sig')
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'annotation_edges':len(links),'gene_no_selected_annotation':audit.loc[audit.Displayed_term_annotation_count==0,'SYMBOL'].tolist(),'KEGG_unannotated':audit.loc[~audit.In_KEGG,'SYMBOL'].tolist(),'workbook_sheets':[(s['name'],len(s['rows'])) for s in sheets]},ensure_ascii=False))
