from pathlib import Path
import os,sys,json,math
W=Path('./local_user/.codex/tmp/aki_fig9_11_work');deps=Path(os.environ.get('AKI_CHEM_DEPS',str(W/'chem_deps')));sys.path.insert(0,str(deps));handles=[os.add_dll_directory(str(p)) for p in deps.glob('*.libs') if p.is_dir()];handles.append(os.add_dll_directory(str(deps/'rdkit')))
from rdkit import Chem
from meeko import PDBQTMolecule,RDKitMolCreate
import pandas as pd,numpy as np
from scipy.spatial import cKDTree
OUT=Path(os.environ.get('AKI_DOCKING_ROOT','./local_user/.codex/tmp/aki_docking_output'));T=OUT/'各子图数据表';rep=pd.read_csv(T/'图11CDEF_代表构象选择.csv',dtype={'CID':str});receptors=pd.read_csv(T/'受体结构_范围与搜索区域.csv',keep_default_na=False);qcs=[]
def atomtable(p,qt=False):
    rows=[]
    for l in p.read_text().splitlines():
        if not l.startswith(('ATOM  ','HETATM')):continue
        typ=l[77:].strip() if qt else l[76:78].strip()
        if typ in ['H','HD','D']:continue
        rows.append({'Atom':l[12:16].strip(),'Residue':l[17:20].strip(),'Chain':l[21],'Residue_number':l[22:26].strip(),'x':float(l[30:38]),'y':float(l[38:46]),'z':float(l[46:54]),'Atom_type':typ})
    return pd.DataFrame(rows)
recs={}
for _,r in receptors.iterrows():
    d=atomtable(OUT/'inputs/receptors'/f'{r.Gene}.pdbqt',True);d['Element']=d.Atom_type.map(lambda t:'C' if t=='A' else t[0]);recs[r.Gene]=d;d.to_csv(T/f'受体{r.Gene}_实际对接重原子坐标.csv',encoding='utf-8-sig',index=False)
    raw=atomtable(OUT/'inputs/receptors'/f'{r.Gene}_observed.pdb');match=[];used=[]
    for _,a in raw.iterrows():
        f=d[d.Chain.eq(a.Chain)&d.Residue_number.eq(a.Residue_number)&d.Element.eq(a.Atom_type[0])];dist,idx=cKDTree(f[['x','y','z']].to_numpy()).query(a[['x','y','z']].to_numpy(dtype=float));b=f.iloc[idx];used.append(int(b.name));match.append({'Gene':r.Gene,'Chain':a.Chain,'Residue_number':a.Residue_number,'Original_atom':a.Atom,'Final_atom':b.Atom,'Displacement_A':float(dist)})
    md=pd.DataFrame(match);md.to_csv(OUT/'处理记录'/f'{r.Gene}_观察原子坐标匹配.csv',encoding='utf-8-sig',index=False)
    non=md.Original_atom.ne('OXT');terminal=md[~non];check={'Gene':r.Gene,'Observed_heavy_atoms':len(raw),'Docking_heavy_atoms':len(d),'Observed_atoms_retained':len(set(used)),'Maximum_nonterminal_coordinate_difference_A':float(md.loc[non,'Displacement_A'].max()),'Maximum_terminal_OXT_standardization_A':float(terminal.Displacement_A.max()) if len(terminal) else 0.,'Template_atom_renamings':int(md.Original_atom.ne(md.Final_atom).sum()),'Nonterminal_observed_coordinates_preserved':len(set(used))==len(raw) and md.loc[non,'Displacement_A'].max()<=.002};qcs.append(check);print(check,flush=True);assert check['Nonterminal_observed_coordinates_preserved'],check
contacts=[];near=[]
for _,r in rep.iterrows():
    mol=RDKitMolCreate.from_pdbqt_mol(PDBQTMolecule.from_file(str(OUT/'outputs'/r.Pose_file),skip_typing=True))[0];xyz=mol.GetConformer(0).GetPositions();pro=recs[r.Gene];px=pro[['x','y','z']].to_numpy();tree=cKDTree(px);rows=[]
    for atom in mol.GetAtoms():
        if atom.GetSymbol()=='H':continue
        i=atom.GetIdx();dist,idx=tree.query(xyz[i]);p=pro.iloc[idx];rows.append({'Panel':r.Panel,'Gene':r.Gene,'CID':r.CID,'Metabolite':r.Metabolite,'Seed':int(r.Representative_seed),'Pose_mode':1,'Ligand_atom_index':i,'Element':atom.GetSymbol(),'Formal_charge':atom.GetFormalCharge(),'x':float(xyz[i,0]),'y':float(xyz[i,1]),'z':float(xyz[i,2]),'Closest_protein_atom':p.Atom,'Protein_residue':p.Residue,'Protein_chain':p.Chain,'Protein_residue_number':p.Residue_number,'Closest_distance_A':float(dist)})
    pd.DataFrame(rows).to_csv(T/f'图11{r.Panel}_代表配体原子坐标.csv',index=False,encoding='utf-8-sig')
    contact=pd.read_csv(T/f'图11{r.Panel}_极性原子接触距离.csv',keep_default_na=False);contacts.append(contact);near.append(pd.read_csv(T/f'图11{r.Panel}_邻近残基.csv'))
pd.concat(contacts,ignore_index=True).to_csv(T/'图11CDEF_全部极性距离接触.csv',encoding='utf-8-sig',index=False);pd.concat(near,ignore_index=True).to_csv(T/'图11CDEF_全部邻近残基.csv',encoding='utf-8-sig',index=False)
pd.DataFrame(qcs).to_csv(OUT/'处理记录/受体观察原子保留核对.csv',encoding='utf-8-sig',index=False)
notes=['来源：图10按度值选择前4个代谢物；公开人类PDB结构；实际AutoDock Vina 1.2.7计算。','热图：每组3个独立随机种子的最高排名构象得分的中位数；重复属于计算重复。','探索性结果；IL1B共晶配体最高排名构象RMSD=2.12Å，未通过本次2Å检查。']
def spec(name,file,title):
    d=pd.read_csv(T/file,keep_default_na=False)
    for f in d:
        if f in ['CID','Protein_residue_number','Residue_number','UniProt','Seed','Representative_seed']:d[f]=d[f].astype(str)
    widths=[min(68,max(17,len(f)+3,50 if f in ['Input_SMILES','Canonical_SMILES','Search_scope','Source_URL','Contact_definition'] else 24 if f in ['Metabolite','Label'] else 18)) for f in d]
    return {'name':name,'title':title,'fields':list(d),'rows':json.loads(d.to_json(orient='values',force_ascii=False,double_precision=15)),'widths':widths,'notes':notes}
ss=[spec('A_代谢物度值','图11A_代谢物度值与前四名.csv','图11A 代谢物网络度值及选择'),spec('B_24组得分汇总','图11B_24组得分汇总.csv','图11B 24组对接得分及计算重复统计'),spec('B_72次完整重复','图11B_72次独立对接得分.csv','每组3个随机种子的原始得分'),spec('受体结构及搜索区域','受体结构_范围与搜索区域.csv','人类实验结构、链、范围与搜索框'),spec('配体形式及制备','配体制备与电荷.csv','原始CID、SMILES、分子式及电荷'),spec('CDEF_构象选择','图11CDEF_代表构象选择.csv','每个代谢物选中位数得分最低的受体，再取中位数对应种子')]
for _,r in rep.iterrows():ss.append(spec(f'{r.Panel}_配体原子坐标',f'图11{r.Panel}_代表配体原子坐标.csv',f'图11{r.Panel} {r.Metabolite}–{r.Gene} 实际配体坐标'))
ss.extend([spec('CDEF_几何接触','图11CDEF_全部极性距离接触.csv','N/O/S原子距离≤3.5Å的全部几何接触'),spec('CDEF_邻近残基','图11CDEF_全部邻近残基.csv','展示的邻近残基及最近重原子距离'),spec('共晶重对接验证','共晶配体重对接验证.csv','各一次重对接：不叠合受体的对称校正重原子RMSD')])
(OUT/'处理记录/workbook_payload.json').write_text(json.dumps({'filename':'图11_各子图数据_对接得分与结构参数.xlsx','sheets':ss},ensure_ascii=False),encoding='utf8')
print('FIGURE11 TABLES',len(ss),'sheets; receptor atom checks passed')
