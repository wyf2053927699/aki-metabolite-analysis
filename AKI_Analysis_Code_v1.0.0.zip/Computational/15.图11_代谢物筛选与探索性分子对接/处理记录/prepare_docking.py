from pathlib import Path
import sys,json,shutil,subprocess,os,random
random.seed(20261019)
W=Path('./local_user/.codex/tmp/aki_fig9_11_work');sys.path.insert(0,str(W/'chem_deps'))
handles=[os.add_dll_directory(str(p)) for p in (W/'chem_deps').glob('*.libs') if p.is_dir()]
handles.append(os.add_dll_directory(str(W/'chem_deps/rdkit')))
import numpy as np,pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem,rdMolDescriptors
from meeko import MoleculePreparation,PDBQTWriterLegacy
from pdbfixer import PDBFixer
from openmm.app import PDBFile,ForceField,NoCutoff,HBonds
from openmm import unit
import openmm
plugin_dir=W/'chem_deps/OpenMM.libs/lib/plugins';handles.append(os.add_dll_directory(str(plugin_dir)))
openmm.Platform.loadPluginsFromDirectory(str(plugin_dir))
openmm.Platform.getPlatformByName('CPU').setPropertyDefaultValue('Threads','2')
B=Path('./local_user/.codex/tmp/aki_project');OUT=Path('./local_user/.codex/tmp/aki_docking_output')
for d in ['sources/receptors','sources/ligands','各子图数据表','处理记录','处理记录/软件','inputs/receptors','inputs/ligands','inputs/configs','对接结果','图片','处理记录/图片预览']:(OUT/d).mkdir(exist_ok=True,parents=True)
src=B/'14.图10_菌群靶点通路代谢物网络/各子图数据表/图11A_代谢物度值与前四名.csv';shutil.copy2(src,OUT/'各子图数据表/图11A_代谢物度值与前四名.csv')
met=pd.read_csv(src,keep_default_na=False,dtype={'CID':str});records=[]
for _,r in met[met.Selected_for_docking].iterrows():
    mol=Chem.AddHs(Chem.MolFromSmiles(r.SMILES));p=AllChem.ETKDGv3();p.randomSeed=20261019;assert AllChem.EmbedMolecule(mol,p)==0
    status=AllChem.MMFFOptimizeMolecule(mol,maxIters=2000);assert status==0
    mol.SetProp('_Name',r.Label);writer=Chem.SDWriter(str(OUT/'sources/ligands'/f'CID{r.CID}.sdf'));writer.write(mol);writer.close()
    setups=MoleculePreparation()(mol);qt,ok,msg=PDBQTWriterLegacy.write_string(setups[0]);assert ok,msg
    (OUT/'inputs/ligands'/f'CID{r.CID}.pdbqt').write_text(qt,encoding='ascii')
    records.append({'Metabolite':r.Label,'CID':r.CID,'Input_SMILES':r.SMILES,'Canonical_SMILES':Chem.MolToSmiles(Chem.RemoveHs(mol)),'Formula':rdMolDescriptors.CalcMolFormula(mol),'Formal_charge':Chem.GetFormalCharge(mol),'Net_partial_charge':sum(a.charge for a in setups[0].atoms),'Embedding_seed':20261019,'MMFF_status':status,'Heavy_atom_count':mol.GetNumHeavyAtoms()})
pd.DataFrame(records).to_csv(OUT/'各子图数据表/配体制备与电荷.csv',index=False,encoding='utf-8-sig')
specs=[('AKT1','3O96','A','IQO','Allosteric co-crystal inhibitor IQO site'),('CASP3','1PAU','AB','CHAIN:C','Peptide inhibitor chain C site; noncovalent exploratory docking'),('IL1B','6Y8I','A','OGE','Co-crystal fragment OGE site'),('IL6','1ALU','A',None,'Blind search of resolved monomer'),('JUN','1JUN','AB',None,'Blind search of leucine zipper homodimer, model 1'),('NFKB1','2O61','B',None,'Blind search of isolated p50 Rel homology chain B; DNA/partners removed')]
recs=[];fixlog=[]
for gene,pdb,chains,anchor,scope in specs:
    print('PREPARING',gene,pdb,flush=True);s=W/'docking'/(pdb+'.pdb');shutil.copy2(s,OUT/'sources/receptors'/s.name)
    for suffix in ['entry','entities']:shutil.copy2(W/'docking'/f'{pdb}_{suffix}.json',OUT/'sources/receptors'/f'{pdb}_{suffix}.json')
    entities=json.loads((W/'docking'/f'{pdb}_entities.json').read_text());chosen=[e for e in entities if set(e['rcsb_polymer_entity_container_identifiers'].get('auth_asym_ids',[]))&set(chains)]
    assert all(any(s['ncbi_taxonomy_id']==9606 for s in e.get('rcsb_entity_source_organism',[])) for e in chosen)
    lines=[];alllines=[]
    for l in s.read_text().splitlines():
        if l.startswith('ENDMDL'):break
        if l.startswith(('ATOM  ','HETATM')) and l[16] in [' ','A']:
            alllines.append(l)
            if l[21] in chains and (l.startswith('ATOM  ') or l[17:20].strip()=='ACE') and l[76:78].strip()!='H':lines.append(l[:16]+' '+l[17:])
    rec=OUT/'inputs/receptors'/f'{gene}_observed.pdb';rec.write_text('\n'.join(lines)+'\nEND\n',encoding='ascii')
    fixed=OUT/'inputs/receptors'/f'{gene}_prepared.pdb'
    if not fixed.exists() or '--force-reprepare' in sys.argv:
        fixer=PDBFixer(filename=str(rec));fixer.findMissingResidues();missingres=str(fixer.missingResidues);fixer.missingResidues={}
        fixer.findNonstandardResidues();assert not fixer.nonstandardResidues,str(fixer.nonstandardResidues)
        fixer.findMissingAtoms();missingatoms=[(r.chain.id,r.id,r.name,[a.name for a in ats]) for r,ats in fixer.missingAtoms.items()]
        fixer.addMissingAtoms(seed=20261019);fixer.addMissingHydrogens(7.4)
        # Relax only modelled atoms and hydrogens; keep every experimentally observed heavy atom fixed.
        observed={(l[21],l[22:26].strip(),l[12:16].strip()) for l in lines}
        system=ForceField('amber14-all.xml').createSystem(fixer.topology,nonbondedMethod=NoCutoff,constraints=None)
        for atom in fixer.topology.atoms():
            if (atom.residue.chain.id,atom.residue.id,atom.name) in observed:system.setParticleMass(atom.index,0)
        integ=openmm.VerletIntegrator(.001);ctx=openmm.Context(system,integ,openmm.Platform.getPlatformByName('CPU'));ctx.setPositions(fixer.positions)
        openmm.LocalEnergyMinimizer.minimize(ctx,10,1000);fixer.positions=ctx.getState(getPositions=True).getPositions();del ctx,integ
        with fixed.open('w') as f:PDBFile.writeFile(fixer.topology,fixer.positions,f,keepIds=True)
        fixlog.append({'Gene':gene,'Missing_residues_not_built':missingres,'Missing_heavy_atoms_rebuilt':str(missingatoms),'Hydrogen_pH':7.4})
    qt=OUT/'inputs/receptors'/f'{gene}.pdbqt'
    heavy=fixed.with_name(gene+'_heavy.pdb');hl=[l for l in fixed.read_text().splitlines() if not l.startswith(('ATOM  ','HETATM')) or l[76:78].strip() not in ['H','D']]
    # Standardize terminal OXT from the CA-C-O plane; log any change of pre-existing OXT in the atom audit.
    for idx,line in enumerate(hl):
        if line.startswith('ATOM') and line[12:16].strip()=='OXT':
            res=[l for l in hl if l.startswith('ATOM') and l[21:27]==line[21:27]];at={l[12:16].strip():np.array([float(l[30:38]),float(l[38:46]),float(l[46:54])]) for l in res}
            if all(k in at for k in ['CA','C','O']):
                u=at['CA']-at['C'];v=at['O']-at['C'];direction=-u/np.linalg.norm(u)-v/np.linalg.norm(v);p=at['C']+1.25*direction/np.linalg.norm(direction)
                hl[idx]=line[:30]+''.join(f'{x:8.3f}' for x in p)+line[54:]
    heavy.write_text('\n'.join(hl)+'\n',encoding='ascii')
    if True:
        run=subprocess.run([sys.executable,str(W/'chem_bootstrap.py'),'meeko.cli.mk_prepare_receptor','--read_pdb',str(heavy),'-o',str(qt.with_suffix('')),'-p'],capture_output=True,text=True,encoding='utf8',errors='replace')
        (OUT/'处理记录'/f'{gene}_Meeko制备日志.txt').write_text(run.stdout+'\n'+run.stderr,encoding='utf8');assert run.returncode==0,(gene,run.stdout,run.stderr)
    xyz=np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in lines if l.startswith('ATOM')]);anch=[]
    if anchor:
        anch=[l for l in alllines if (l[21]=='C' if anchor=='CHAIN:C' else l[17:20].strip()==anchor)]
        ax=np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in anch]);center=ax.mean(0);size=np.maximum(ax.max(0)-ax.min(0)+12,22);exhaust=32
        (OUT/'sources/receptors'/f'{gene}_site_anchor.pdb').write_text('\n'.join(anch)+'\nEND\n',encoding='ascii')
    else:center=(xyz.max(0)+xyz.min(0))/2;size=xyz.max(0)-xyz.min(0)+12;exhaust=64
    d={'Gene':gene,'PDB_ID':pdb,'Chains':chains,'Model':1,'Species':'Homo sapiens','UniProt':';'.join(sorted({x for e in chosen for x in e['rcsb_polymer_entity_container_identifiers'].get('uniprot_ids',[])})),'Method':json.loads((W/'docking'/f'{pdb}_entry.json').read_text())['exptl'][0]['method'],'Observed_residue_ranges':';'.join(f'{c}:{min(int(l[22:26]) for l in lines if l[21]==c and l.startswith("ATOM"))}-{max(int(l[22:26]) for l in lines if l[21]==c and l.startswith("ATOM"))}' for c in chains),'Mutation_count':max(e['entity_poly'].get('rcsb_mutation_count',0) for e in chosen),'Search_scope':scope,'Anchor':anchor or '',**{f'Center_{a}':round(float(v),4) for a,v in zip('xyz',center)},**{f'Size_{a}':round(float(v),4) for a,v in zip('xyz',size)},'Exhaustiveness':exhaust,'Source_URL':'https://www.rcsb.org/structure/'+pdb}
    recs.append(d)
    conf='\n'.join([f'center_{a} = {v:.4f}' for a,v in zip('xyz',center)]+[f'size_{a} = {v:.4f}' for a,v in zip('xyz',size)]+[f'exhaustiveness = {exhaust}','num_modes = 9','energy_range = 5','cpu = 2'])+'\n'
    (OUT/'inputs/configs'/f'{gene}_box.txt').write_text(conf,encoding='ascii')
pd.DataFrame(recs).to_csv(OUT/'各子图数据表/受体结构_范围与搜索区域.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(fixlog).to_csv(OUT/'处理记录/PDBFixer修复记录.csv',index=False,encoding='utf-8-sig')
shutil.copy2(W/'docking/vina_1.2.7_win.exe',OUT/'处理记录/软件/vina_1.2.7_win.exe')
print('PREPARATION COMPLETE',flush=True)
