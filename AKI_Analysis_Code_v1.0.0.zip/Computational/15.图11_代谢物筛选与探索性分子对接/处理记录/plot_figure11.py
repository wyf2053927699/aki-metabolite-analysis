from pathlib import Path
import sys,json,textwrap,os
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Rectangle,ConnectionPatch
from PIL import Image
OUT=Path(os.environ.get('AKI_DOCKING_ROOT','./local_user/.codex/tmp/aki_docking_output'));tables=OUT/'各子图数据表';views=OUT/'molecular_views';preview=OUT/'处理记录/图片预览'
plt.rcParams.update({'font.family':'Arial','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
met=pd.read_csv(tables/'图11A_代谢物度值与前四名.csv',dtype={'CID':str});scores=pd.read_csv(tables/'图11B_24组得分汇总.csv',dtype={'CID':str});rep=pd.read_csv(tables/'图11CDEF_代表构象选择.csv',dtype={'CID':str})
order=met[met.Selected_for_docking].Label.tolist();genes=['JUN','IL6','IL1B','AKT1','CASP3','NFKB1'];matrix=scores.pivot(index='Metabolite',columns='Gene',values='Median_score').loc[order,genes]
matrix.to_csv(tables/'图11B_热图中位数矩阵.csv',encoding='utf-8-sig')
vmin=np.floor(matrix.to_numpy().min()*2)/2;vmax=np.ceil(matrix.to_numpy().max()*2)/2
def save(fig,stem,pdf):
    fig.savefig(preview/(stem+'.png'),dpi=100);fig.savefig(OUT/'图片'/(stem+'.png'),dpi=600);fig.savefig(OUT/'图片'/(stem+'.svg'));pdf.savefig(fig);plt.close(fig)
def plotA(ax):
    d=met.sort_values(['Degree','CID'],ascending=[True,False]);pal=['#EF6E50','#60AFAF','#3B538C','#F7A07F','#8C92AF','#8BCBC1','#B39E83','#1E78A8'];y=d.Degree.to_numpy();ax.bar(range(len(d)),y,color=pal,width=.75,edgecolor='white',lw=.7)
    for i,(_,r) in enumerate(d.iterrows()):ax.text(i,r.Degree+.6,str(r.Degree)+(' *' if r.Selected_for_docking else ''),ha='center',fontsize=9,color='#4B4B4B')
    ax.set(xticks=range(len(d)),xticklabels=d.Label,ylim=(0,max(y)*1.16),ylabel='Network degree',xlabel='Metabolites');ax.tick_params(axis='x',rotation=40,labelsize=8.5)
    for t in ax.get_xticklabels():t.set_ha('right')
    ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True));ax.set_title('A   Metabolite prioritization',loc='left',fontweight='bold',pad=12);ax.text(.02,.96,'* Four metabolites selected before docking',transform=ax.transAxes,va='top',fontsize=8,color='#666666')
def plotB(ax):
    im=ax.imshow(matrix.to_numpy(),cmap='YlOrRd_r',vmin=vmin,vmax=vmax,aspect='auto')
    for i in range(4):
        for j in range(6):
            x=float(matrix.iloc[i,j]);ax.text(j,i,f'{x:.2f}',ha='center',va='center',fontsize=10,color='white' if (x-vmin)/(vmax-vmin)<.32 else '#3C3430')
    ax.set(xticks=range(6),xticklabels=genes,yticks=range(4),yticklabels=order);ax.tick_params(axis='both',length=0);ax.set_xticks(np.arange(-.5,6,1),minor=True);ax.set_yticks(np.arange(-.5,4,1),minor=True);ax.grid(which='minor',color='white',lw=.7);ax.tick_params(which='minor',bottom=False,left=False)
    ax.set_title('B   Docking score: median of three seeds',loc='left',fontweight='bold',pad=12)
    cb=ax.figure.colorbar(im,ax=ax,fraction=.035,pad=.04);cb.set_label('Vina score (kcal/mol)',fontsize=9);cb.ax.tick_params(labelsize=8)
def molpanel(fig,gs,r):
    sub=gs.subgridspec(1,2,width_ratios=[1,1.15],wspace=.03);a=fig.add_subplot(sub[0]);b=fig.add_subplot(sub[1]);stem=f'{r.Panel}_{r.Gene}_CID{r.CID}';v=json.loads((views/(stem+'_view.json')).read_text())
    for ax,mode in [(a,'whole'),(b,'site')]:
        ax.imshow(Image.open(views/v[mode]['image']));ax.set_axis_off()
    a.text(0,1.10,f'{r.Panel}   {r.Metabolite}–{r.Gene}',transform=a.transAxes,fontsize=12,fontweight='bold',va='bottom')
    a.text(0,1.035,f'Median score {r.Median_score:.3f} kcal/mol',transform=a.transAxes,fontsize=9,color='#545A63',va='bottom')
    lx,ly=v['whole']['ligand_xy'];cy=1-ly;a.add_patch(Rectangle((lx-.075,cy-.075),.15,.15,transform=a.transAxes,fill=False,lw=.9,ls=(0,(4,3)),color='#222222'))
    for sy,ty in [(cy-.075,.08),(cy+.075,.92)]:fig.add_artist(ConnectionPatch(xyA=(lx+.075,sy),coordsA=a.transAxes,xyB=(0,ty),coordsB=b.transAxes,arrowstyle='-',lw=.8,ls=(0,(4,3)),color='#333333'))
    for spine in b.spines.values():spine.set_visible(True);spine.set_linestyle((0,(4,3)));spine.set_linewidth(.8)
    b.set_axis_on();b.set_xticks([]);b.set_yticks([])
    labels=v['site']['labels'];left=sorted([d for d in labels if d['xy'][0]<.5],key=lambda d:d['xy'][1]);right=sorted([d for d in labels if d['xy'][0]>=.5],key=lambda d:d['xy'][1])
    for group,side in [(left,'left'),(right,'right')]:
        for d,y in zip(group,np.linspace(.88,.12,len(group))):
            x=.025 if side=='left' else .975;xy=d['xy'];b.annotate(d['label'],xy=(xy[0],1-xy[1]),xycoords=b.transAxes,xytext=(x,y),textcoords=b.transAxes,ha='left' if side=='left' else 'right',va='center',fontsize=7.1,bbox={'fc':'white','ec':'none','pad':1.0,'alpha':.9},arrowprops={'arrowstyle':'-','color':'#4C4C4C','lw':.5,'shrinkA':2,'shrinkB':1})
    a.text(.5,-.055,'Cutaway protein surface',transform=a.transAxes,ha='center',fontsize=8,color='#5A626B');b.text(.5,-.055,'Blue: Cα backbone · gold: ligand carbon',transform=b.transAxes,ha='center',fontsize=8,color='#5A626B')
with PdfPages(OUT/'图11_代谢物筛选_对接热图与构象.pdf') as pdf:
    fig=plt.figure(figsize=(17.7,14.8));g=fig.add_gridspec(3,2,left=.065,right=.97,bottom=.055,top=.94,hspace=.52,wspace=.42,height_ratios=[1,1.3,1.3]);plotA(fig.add_subplot(g[0,0]));plotB(fig.add_subplot(g[0,1]))
    for i,(_,r) in enumerate(rep.iterrows()):molpanel(fig,g[1+i//2,i%2],r)
    fig.suptitle('Metabolite prioritization and exploratory molecular docking',fontsize=16,fontweight='bold',x=.065,ha='left',y=.985)
    fig.text(.5,.015,'Rigid receptor · 3 seeds per pair · contact dashes indicate N/O/S distances ≤3.5 Å only · representative poses selected by the stated score rule',ha='center',fontsize=9,color='#596270');save(fig,'图11_主图_ABCDEF',pdf)
    for panel,func in [('A',plotA),('B',plotB)]:
        fig,ax=plt.subplots(figsize=(9,5.8));fig.subplots_adjust(left=.18 if panel=='B' else .1,right=.94,bottom=.30 if panel=='A' else .16,top=.86);func(ax);save(fig,'图11_'+panel,pdf)
    for _,r in rep.iterrows():
        fig=plt.figure(figsize=(12,6.5));g=fig.add_gridspec(1,1,left=.035,right=.97,bottom=.12,top=.80);molpanel(fig,g[0],r);save(fig,'图11_'+r.Panel,pdf)
print('FIGURE11 PLOTS COMPLETE')
