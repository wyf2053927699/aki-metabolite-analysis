from pathlib import Path
import os,sys,json
W=Path('./local_user/.codex/tmp/aki_fig9_11_work');deps=Path(os.environ.get('AKI_CHEM_DEPS',str(W/'chem_deps')));sys.path.insert(0,str(deps));handles=[os.add_dll_directory(str(p)) for p in deps.glob('*.libs') if p.is_dir()];handles.append(os.add_dll_directory(str(deps/'rdkit')))
import numpy as np,pandas as pd,pyvista as pv
from scipy.spatial import cKDTree
from rdkit import Chem
from meeko import PDBQTMolecule,RDKitMolCreate
OUT=Path(os.environ.get('AKI_DOCKING_ROOT','./local_user/.codex/tmp/aki_docking_output'));dest=OUT/'molecular_views';dest.mkdir(exist_ok=True);(OUT/'complexes').mkdir(exist_ok=True)
def atoms(path):
    rows=[]
    for l in path.read_text().splitlines():
        if l.startswith(('ATOM  ','HETATM')) and l[76:78].strip() not in ['H','D']:
            rows.append({'Atom':l[12:16].strip(),'Residue':l[17:20].strip(),'Chain':l[21],'Residue_number':l[22:26].strip(),'x':float(l[30:38]),'y':float(l[38:46]),'z':float(l[46:54]),'Element':l[76:78].strip(),'PDB_line':l})
    return pd.DataFrame(rows)
def surface(df,gene):
    file=dest/(gene+'_SAS.vtp')
    if file.exists():return pv.read(file)
    xyz=df[['x','y','z']].to_numpy();origin=xyz.min(0)-5;spacing=.8;dims=np.ceil((xyz.max(0)+5-origin)/spacing).astype(int)+1
    grid=pv.ImageData(dimensions=dims,spacing=(spacing,)*3,origin=origin);points=grid.points;field=np.full(len(points),999,dtype=np.float32)
    radii={'C':1.7,'N':1.55,'O':1.52,'S':1.8}
    for elem in df.Element.unique():
        arr=xyz[df.Element.eq(elem)];dist=cKDTree(arr).query(points,workers=2)[0];field=np.minimum(field,dist-(radii.get(elem,1.7)+1.4))
    grid['SAS_distance']=field;mesh=grid.contour([0],scalars='SAS_distance').smooth(n_iter=12,relaxation_factor=.04);mesh.save(file);return mesh
def bond(p,a,b,color,radius=.11):p.add_mesh(pv.Line(a,b).tube(radius=radius,n_sides=10),color=color,smooth_shading=True)
def draw_mol(p,mol,carbon='#E9B949',conf=0):
    xyz=mol.GetConformer(conf).GetPositions();colors={'C':carbon,'O':'#D62728','N':'#2F66B0','S':'#D6B644','H':'#EEEEEE'}
    for atom in mol.GetAtoms():
        if atom.GetSymbol()=='H':continue
        p.add_mesh(pv.Sphere(radius=.32,center=xyz[atom.GetIdx()],theta_resolution=16,phi_resolution=16),color=colors.get(atom.GetSymbol(),'#999999'),smooth_shading=True)
    for b in mol.GetBonds():
        a,c=b.GetBeginAtomIdx(),b.GetEndAtomIdx()
        if mol.GetAtomWithIdx(a).GetSymbol()=='H' or mol.GetAtomWithIdx(c).GetSymbol()=='H':continue
        mid=(xyz[a]+xyz[c])/2;bond(p,xyz[a],mid,colors.get(mol.GetAtomWithIdx(a).GetSymbol(),carbon),.13);bond(p,mid,xyz[c],colors.get(mol.GetAtomWithIdx(c).GetSymbol(),carbon),.13)
def project(p,coords):
    ren=p.renderer;ren.SetWorldPoint(*coords,1);ren.WorldToDisplay();v=ren.GetDisplayPoint();return [v[0]/p.window_size[0],1-v[1]/p.window_size[1]]
def write_complex(df,ligpdb,file):
    lines=[];serial=1;last=None
    for line in df.PDB_line:
        if last is not None and last[21]!=line[21]:
            lines.append(f'TER   {serial:5d}      {last[17:20]} {last[21]}{last[22:26]}');serial+=1
        lines.append(line[:6]+f'{serial:5d}'+line[11:]);serial+=1;last=line
    if last is not None:lines.append(f'TER   {serial:5d}      {last[17:20]} {last[21]}{last[22:26]}');serial+=1
    mapping={}
    for l in ligpdb.splitlines():
        if not l.startswith(('HETATM','ATOM  ')):continue
        mapping[int(l[6:11])]=serial;chars=list(l);chars[:6]=list('HETATM');chars[6:11]=list(f'{serial:5d}');chars[17:20]=list('LIG');chars[21]='Z';chars[22:26]=list('   1');lines.append(''.join(chars));serial+=1
    for l in ligpdb.splitlines():
        if l.startswith('CONECT'):
            ids=[int(l[i:i+5]) for i in range(6,len(l),5) if l[i:i+5].strip()];lines.append('CONECT'+''.join(f'{mapping[i]:5d}' for i in ids))
    file.write_text('\n'.join(lines)+'\nEND\n',encoding='ascii')
def run(row):
    gene=row.Gene;stem=f'{row.Panel}_{gene}_CID{row.CID}';df=atoms(OUT/'inputs/receptors'/f'{gene}_heavy.pdb');xyz=df[['x','y','z']].to_numpy();pm=PDBQTMolecule.from_file(str(OUT/'outputs'/row.Pose_file),skip_typing=True);mol=RDKitMolCreate.from_pdbqt_mol(pm)[0];assert mol is not None
    ligxyz=mol.GetConformer(0).GetPositions();heavy=[a.GetIdx() for a in mol.GetAtoms() if a.GetSymbol()!='H'];lig=ligxyz[heavy];lc=lig.mean(0);center=xyz.mean(0);direction=lc-center;direction/=np.linalg.norm(direction);up=np.array([0.,0.,1.]);up-=direction*np.dot(up,direction)
    if np.linalg.norm(up)<.1:up=np.array([0.,1.,0.]);up-=direction*np.dot(up,direction)
    up/=np.linalg.norm(up)
    wr=Chem.SDWriter(str(OUT/'complexes'/(stem+'_pose.sdf')));wr.write(mol,confId=0);wr.close();ligpdb=Chem.MolToPDBBlock(mol,confId=0)
    write_complex(df,ligpdb,OUT/'complexes'/(stem+'_complex.pdb'))
    dist=cKDTree(lig).query(xyz)[0];df['Distance_to_ligand']=dist
    rs=df.groupby(['Chain','Residue_number','Residue'],as_index=False).Distance_to_ligand.min().sort_values('Distance_to_ligand');near=rs[rs.Distance_to_ligand.le(4.0)].head(6)
    contacts=[]
    for ai in heavy:
        atom=mol.GetAtomWithIdx(ai)
        if atom.GetSymbol() not in ['N','O','S']:continue
        for idx in np.where((np.linalg.norm(xyz-ligxyz[ai],axis=1)<=3.5)&df.Element.isin(['N','O','S']).to_numpy())[0]:
            r=df.iloc[idx];contacts.append({'Panel':row.Panel,'Gene':gene,'CID':str(row.CID),'Ligand_atom_index':ai,'Ligand_element':atom.GetSymbol(),'Protein_chain':r.Chain,'Protein_residue':r.Residue,'Protein_residue_number':r.Residue_number,'Protein_atom':r.Atom,'Distance_A':float(np.linalg.norm(xyz[idx]-ligxyz[ai])),'Protein_index':int(idx),'Contact_definition':'N/O/S atom distance <=3.5 A; geometry only, no hydrogen-bond angle test'})
    cds=pd.DataFrame(contacts)
    if len(cds):display=cds.sort_values('Distance_A').drop_duplicates(['Protein_chain','Protein_residue_number']).head(4)
    else:display=cds
    views={}
    for mode in ['whole','site']:
        p=pv.Plotter(off_screen=True,window_size=(2000,1800),lighting='three lights');p.set_background('white');p.enable_parallel_projection()
        if mode=='whole':
            mesh=surface(df,gene);cc=mesh.cell_centers().points;mesh=mesh.extract_cells(np.linalg.norm(cc-lc,axis=1)>5.0).extract_surface(algorithm='dataset_surface')
            p.add_mesh(mesh,color='#B7BBC0',opacity=1,smooth_shading=True,specular=.15)
        else:
            # Continuous C-alpha backbone from actual coordinates; chain breaks are not joined.
            ca=df[df.Atom.eq('CA')]
            for chain,c in ca.groupby('Chain',sort=False):
                a=c[['x','y','z']].to_numpy();breaks=[0]+[i for i in range(1,len(a)) if np.linalg.norm(a[i]-a[i-1])>5]+[len(a)]
                for start,end in zip(breaks[:-1],breaks[1:]):
                    seg=a[start:end]
                    if len(seg)>=2:p.add_mesh(pv.Spline(seg,n_points=len(seg)*8).tube(radius=.17),color='#4E80AE',smooth_shading=True,opacity=.32)
            for _,r in near.iterrows():
                res=df[df.Chain.eq(r.Chain)&df.Residue_number.eq(r.Residue_number)];ax=res[['x','y','z']].to_numpy()
                for i,a in enumerate(ax):
                    p.add_mesh(pv.Sphere(radius=.20,center=a,theta_resolution=12,phi_resolution=12),color={'O':'#CC3D3D','N':'#285CA6','S':'#CAB445'}.get(res.iloc[i].Element,'#4E80AE'),smooth_shading=True)
                for i,j in cKDTree(ax).query_pairs(1.9):bond(p,ax[i],ax[j],'#4E80AE',.075)
            for _,c in display.iterrows():
                a=ligxyz[int(c.Ligand_atom_index)];b=xyz[int(c.Protein_index)]
                for t in np.arange(0,1,.16):bond(p,a+(b-a)*t,a+(b-a)*min(t+.08,1),'#24A6A2',.038)
        draw_mol(p,mol)
        focus=center if mode=='whole' else lc;radius=max(np.linalg.norm(xyz-center,axis=1))*1.06 if mode=='whole' else 9.2
        p.camera_position=[focus+direction*120,focus,up];p.camera.parallel_scale=radius
        p.render();p.show(auto_close=False,interactive=False)
        projections=[]
        if mode=='site':
            for _,r in near.iterrows():
                rr=df[df.Chain.eq(r.Chain)&df.Residue_number.eq(r.Residue_number)];idx=rr.Distance_to_ligand.astype(float).idxmin();a=df.loc[idx];point=np.array([a.x,a.y,a.z]);projections.append({'label':f'{r.Residue} {r.Chain}{r.Residue_number}','xy':project(p,point),'Distance_A':float(r.Distance_to_ligand)})
        file=dest/(stem+'_'+mode+'.png');p.screenshot(str(file));views[mode]={'image':file.name,'ligand_xy':project(p,lc),'labels':projections,'camera_position':[list(map(float,x)) for x in p.camera_position]};p.close()
    pd.DataFrame(contacts).drop(columns=['Protein_index'],errors='ignore').to_csv(OUT/'各子图数据表'/f'图11{row.Panel}_极性原子接触距离.csv',index=False,encoding='utf-8-sig');near.assign(Panel=row.Panel,Gene=gene,CID=str(row.CID)).to_csv(OUT/'各子图数据表'/f'图11{row.Panel}_邻近残基.csv',index=False,encoding='utf-8-sig')
    (dest/(stem+'_view.json')).write_text(json.dumps(views,indent=2),encoding='utf8');print('RENDERED',stem,flush=True)
if __name__=='__main__':
    if '--test' in sys.argv:
        class R:Panel='C';Gene='AKT1';CID='104775';Pose_file='AKT1_CID104775_seed20261019.pdbqt'
        run(R())
    else:
        df=pd.read_csv(OUT/'各子图数据表/图11CDEF_代表构象选择.csv',dtype={'CID':str})
        for _,r in df.iterrows():run(r)
