from pathlib import Path
import sys,runpy,os
deps=Path('./local_user/.codex/tmp/aki_fig9_11_work/chem_deps');sys.path.insert(0,str(deps))
handles=[os.add_dll_directory(str(p)) for p in deps.glob('*.libs') if p.is_dir()]
handles.append(os.add_dll_directory(str(deps/'rdkit')))
module=sys.argv.pop(1)
runpy.run_module(module,run_name='__main__')
