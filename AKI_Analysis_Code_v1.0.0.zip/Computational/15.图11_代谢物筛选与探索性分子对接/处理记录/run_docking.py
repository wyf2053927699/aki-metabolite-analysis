from pathlib import Path
import sys,subprocess,concurrent.futures,json,re,time,shutil,os
import pandas as pd,numpy as np
OUT=Path(os.environ.get('AKI_DOCKING_ROOT','./local_user/.codex/tmp/aki_docking_output'));inp=OUT/'inputs';runs=OUT/'outputs';runs.mkdir(exist_ok=True)
recs=pd.read_csv(OUT/'各子图数据表/受体结构_范围与搜索区域.csv',keep_default_na=False);lig=pd.read_csv(OUT/'各子图数据表/配体制备与电荷.csv',dtype={'CID':str})
vina=OUT/'处理记录/软件/vina_1.2.7_win.exe';seeds=[20261019,20261020,20261021];commands=[]
def job(gene,cid,seed):
    stem=f'{gene}_CID{cid}_seed{seed}';pose=runs/(stem+'.pdbqt');log=runs/(stem+'.log');meta=runs/(stem+'.json')
    args=[str(vina),'--receptor',f'receptors/{gene}.pdbqt','--ligand',f'ligands/CID{cid}.pdbqt','--config',f'configs/{gene}_box.txt','--seed',str(seed),'--out',f'../outputs/{stem}.pdbqt','--verbosity','1']
    if '--force' in sys.argv or not (pose.exists() and meta.exists() and json.loads(meta.read_text()).get('returncode')==0):
        start=time.time();run=subprocess.run(args,cwd=inp,capture_output=True,text=True,encoding='utf8',errors='replace');log.write_text(run.stdout+'\n'+run.stderr,encoding='utf8');meta.write_text(json.dumps({'args':args[1:],'cwd':'inputs','returncode':run.returncode,'elapsed_seconds':time.time()-start},indent=2),encoding='utf8');assert run.returncode==0,(stem,run.stdout[-2000:],run.stderr)
    scores=re.findall(r'REMARK VINA RESULT:\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)',pose.read_text())
    assert scores,stem
    d={'Gene':gene,'CID':cid,'Seed':seed,'Top_score':float(scores[0][0]),'Pose_count':len(scores),'Output_file':pose.name,'Run_log':log.name,'Elapsed_seconds':json.loads(meta.read_text())['elapsed_seconds']}
    allposes=[{'Gene':gene,'CID':cid,'Seed':seed,'Mode':i+1,'Docking_score':float(sc[0]),'RMSD_lower_bound':float(sc[1]),'RMSD_upper_bound':float(sc[2]),'Output_file':pose.name} for i,sc in enumerate(scores)]
    print('DONE',gene,cid,seed,d['Top_score'],flush=True);return d,allposes
jobs=[(r.Gene,l.CID,seed) for _,r in recs.iterrows() for _,l in lig.iterrows() for seed in seeds]
(OUT/'处理记录/全部对接任务.json').write_text(json.dumps(jobs,indent=2),encoding='utf8');rows=[];poses=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures=[pool.submit(job,*j) for j in jobs]
    for f in concurrent.futures.as_completed(futures):d,ps=f.result();rows.append(d);poses.extend(ps)
d=pd.DataFrame(rows).sort_values(['Gene','CID','Seed']);d=d.merge(lig[['CID','Metabolite']],on='CID',validate='many_to_one')
d.to_csv(OUT/'各子图数据表/图11B_72次独立对接得分.csv',index=False,encoding='utf-8-sig');pd.DataFrame(poses).to_csv(OUT/'各子图数据表/全部对接模式得分.csv',index=False,encoding='utf-8-sig')
agg=d.groupby(['Gene','CID','Metabolite'],as_index=False).agg(Median_score=('Top_score','median'),Mean_score=('Top_score','mean'),SD=('Top_score','std'),Min_score=('Top_score','min'),Max_score=('Top_score','max'),Replicates=('Top_score','size'))
agg.to_csv(OUT/'各子图数据表/图11B_24组得分汇总.csv',index=False,encoding='utf-8-sig')
selected=[]
for _,l in lig.iterrows():
    a=agg[agg.CID.eq(l.CID)].sort_values(['Median_score','Gene']).iloc[0];r=d[d.CID.eq(l.CID)&d.Gene.eq(a.Gene)].copy();r['Dist_median']=abs(r.Top_score-a.Median_score);r=r.sort_values(['Dist_median','Seed']).iloc[0]
    selected.append({'Panel':chr(67+len(selected)),'Metabolite':l.Metabolite,'CID':l.CID,'Gene':a.Gene,'Median_score':a.Median_score,'Representative_seed':int(r.Seed),'Pose_mode':1,'Representative_score':r.Top_score,'Pose_file':r.Output_file})
pd.DataFrame(selected).to_csv(OUT/'各子图数据表/图11CDEF_代表构象选择.csv',index=False,encoding='utf-8-sig')
assert len(d)==72 and len(agg)==24 and all(agg.Replicates.eq(3))
print('DOCKING COMPLETE',len(d),'runs',flush=True)
