from pathlib import Path
import urllib.request,json
W=Path(__file__).parent;D=W/'docking';D.mkdir(exist_ok=True)
class Response:
    def __init__(self,url):self.content=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Academic exploratory docking'}),timeout=90).read()
    def json(self):return json.loads(self.content)
    def raise_for_status(self):pass
class Session:
    def get(self,url,**kwargs):return Response(url)
s=Session()
release=s.get('https://api.github.com/repos/ccsb-scripps/AutoDock-Vina/releases/latest',timeout=60);release.raise_for_status();r=release.json();(D/'vina_release.json').write_text(json.dumps(r,indent=2),encoding='utf8')
for a in r['assets']:
    if a['name'].endswith('_win.exe') and not a['name'].startswith('vina_split'):
        v=s.get(a['browser_download_url'],timeout=90);v.raise_for_status();(D/a['name']).write_bytes(v.content);print('VINA',a['name'],len(v.content),flush=True)
for pdb in ['3O96','1PAU','6Y8I','1ALU','1JUN','1SVC','2O61']:
    if (D/(pdb+'_entities.json')).exists() and (D/(pdb+'.pdb')).exists():continue
    d=s.get('https://data.rcsb.org/rest/v1/core/entry/'+pdb,timeout=60);d.raise_for_status();j=d.json();(D/(pdb+'_entry.json')).write_text(json.dumps(j,indent=2),encoding='utf8')
    entities=[]
    for entity in j['rcsb_entry_container_identifiers']['polymer_entity_ids']:
        e=s.get('https://data.rcsb.org/rest/v1/core/polymer_entity/'+pdb+'/'+entity,timeout=60);e.raise_for_status();ej=e.json();entities.append(ej)
    (D/(pdb+'_entities.json')).write_text(json.dumps(entities,indent=2),encoding='utf8')
    p=s.get('https://files.rcsb.org/download/'+pdb+'.pdb',timeout=60);p.raise_for_status();(D/(pdb+'.pdb')).write_bytes(p.content)
    print(pdb,j['struct']['title'],[(x.get('rcsb_polymer_entity',{}).get('pdbx_description'),x.get('rcsb_polymer_entity_container_identifiers',{}).get('auth_asym_ids'),x.get('rcsb_entity_source_organism')) for x in entities],flush=True)
