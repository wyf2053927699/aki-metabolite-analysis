from pathlib import Path
import sys,json,math,re,hashlib,subprocess
import pandas as pd,numpy as np,openpyxl
from PIL import Image,ImageDraw
Image.MAX_IMAGE_PIXELS=250_000_000
from pypdf import PdfReader
B=Path('./Computational');R=B/'15.图11_代谢物筛选与探索性分子对接';T=R/'各子图数据表';A=R/'处理记录';checks=[]
sys.path.insert(0,'./local_user/.codex/skills/scipilot-figure-skill/scripts')
from profile_data import profile_data,render_report
def check(name,condition,detail=''):
    checks.append({'Check':name,'Pass':bool(condition),'Detail':str(detail)});assert condition,(name,detail)
run=pd.read_csv(T/'图11B_72次独立对接得分.csv',dtype={'CID':str});agg=pd.read_csv(T/'图11B_24组得分汇总.csv',dtype={'CID':str});rep=pd.read_csv(T/'图11CDEF_代表构象选择.csv',dtype={'CID':str});lig=pd.read_csv(T/'配体制备与电荷.csv',dtype={'CID':str})
(A/'数据剖析.txt').write_text(render_report(profile_data(agg[['Gene','Metabolite','Median_score','SD','Replicates']],group_cols=['Gene','Metabolite']))+'\n重复为3次算法随机种子，不是生物学样本；主图使用得分热图，不做生物学显著性检验。',encoding='utf8')
check('72 real runs',len(run)==72 and len(run[['Gene','CID','Seed']].drop_duplicates())==72)
check('Exactly 3 fixed seeds per pair',all(set(g.Seed)=={20261019,20261020,20261021} for _,g in run.groupby(['Gene','CID'])))
for _,r in run.iterrows():
    file=R/'outputs'/r.Output_file;raw=file.read_text();scores=re.findall(r'REMARK VINA RESULT:\s+(-?[\d.]+)',raw);meta=json.loads(file.with_suffix('.json').read_text());check(f'{r.Gene} CID{r.CID} seed{r.Seed}',meta['returncode']==0 and float(scores[0])==r.Top_score and len(scores)==r.Pose_count)
for _,r in agg.iterrows():
    g=run[run.Gene.eq(r.Gene)&run.CID.eq(r.CID)].Top_score;check(f'{r.Gene} CID{r.CID} aggregation',len(g)==3 and abs(g.median()-r.Median_score)<1e-12 and abs(g.std()-r.SD)<1e-12)
for _,r in rep.iterrows():
    best=agg[agg.CID.eq(r.CID)].sort_values(['Median_score','Gene']).iloc[0];check('Panel '+r.Panel+' receptor selection',r.Gene==best.Gene and r.Median_score==best.Median_score)
    atoms=pd.read_csv(T/f'图11{r.Panel}_代表配体原子坐标.csv');check('Panel '+r.Panel+' heavy atom count',len(atoms)==int(lig[lig.CID.eq(r.CID)].Heavy_atom_count.iloc[0]))
    check('Panel '+r.Panel+' contact table',all(pd.read_csv(T/f'图11{r.Panel}_极性原子接触距离.csv').Distance_A.le(3.5)))
    lines=(R/'complexes'/f'{r.Panel}_{r.Gene}_CID{r.CID}_complex.pdb').read_text().splitlines();records=[l for l in lines if l.startswith(('ATOM  ','HETATM'))];ids=[int(l[6:11]) for l in records];check('Panel '+r.Panel+' complex atom serials',len(ids)==len(set(ids)))
    ligand=[l for l in records if l[17:20]=='LIG' and l[21]=='Z' and l[76:78].strip()!='H'];check('Panel '+r.Panel+' complex ligand coordinates',len(ligand)==len(atoms) and np.allclose(np.array([[float(l[30:38]),float(l[38:46]),float(l[46:54])] for l in ligand]),atoms[['x','y','z']].to_numpy(),atol=.001))
q=pd.read_csv(T/'共晶配体重对接验证.csv');check('Native checks report actual threshold outcomes',len(q)==2 and bool(q[q.Gene.eq('AKT1')].Top_pose_within_2A.iloc[0]) and not bool(q[q.Gene.eq('IL1B')].Top_pose_within_2A.iloc[0]))
params=pd.read_csv(T/'受体结构_范围与搜索区域.csv');check('Six human structures no listed mutation',len(params)==6 and params.Species.eq('Homo sapiens').all() and params.Mutation_count.eq(0).all())
payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf8'));wb=openpyxl.load_workbook(R/payload['filename'],read_only=True,data_only=True)
for s in payload['sheets']:
    sheet=wb[s['name']];check(s['name']+' count',sheet['B6'].value==len(s['rows']))
    rows=list(sheet.iter_rows(min_row=8,max_row=7+len(s['rows']),max_col=len(s['fields']),values_only=True))
    for i,row in enumerate(s['rows']):
        for j,val in enumerate(row):
            got=rows[i][j]
            if val in [None,'']:ok=got in [None,'']
            elif isinstance(val,(int,float)) and not isinstance(val,bool):ok=isinstance(got,(int,float)) and math.isclose(val,got,rel_tol=1e-12,abs_tol=1e-280)
            else:ok=val==got
            if not ok:raise AssertionError((s['name'],i,j,val,got))
    check(s['name']+' exact values',True)
wb.close()
for file in (R/'图片').glob('*.png'):
    im=Image.open(file);check(file.name+' resolution',min(im.info.get('dpi',(0,0)))>=599,im.size)
check('Seven page PDF',len(PdfReader(R/'图11_代谢物筛选_对接热图与构象.pdf').pages)==7)
for f in json.loads((A/'文件SHA256清单.json').read_text(encoding='utf8')):
    p=R/f['file'];check('SHA256 '+f['file'],p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'])
preview=A/'PDF渲染';preview.mkdir(exist_ok=True)
subprocess.run(['./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe','-scale-to','1500','-png',str(R/'图11_代谢物筛选_对接热图与构象.pdf'),str(preview/'page')],check=True,capture_output=True)
files=list(A.glob('Excel预览_*.png'))
for start in range(0,len(files),5):
    canvas=Image.new('RGB',(1700,240*min(5,len(files)-start)), 'white');dr=ImageDraw.Draw(canvas)
    for i,file in enumerate(files[start:start+5]):
        im=Image.open(file);im.thumbnail((1680,215));canvas.paste(im,(10,i*240+22));dr.text((10,i*240+3),file.stem,fill='black')
    canvas.save(A/f'Excel总览_{start//5+1}.png')
for f in R.glob('*.inspect.ndjson'):f.replace(A/f.name)
pd.DataFrame(checks).to_csv(A/'图11_独立核对.csv',encoding='utf-8-sig',index=False)
print('FIGURE11 INDEPENDENT CHECKS PASSED',len(checks))
