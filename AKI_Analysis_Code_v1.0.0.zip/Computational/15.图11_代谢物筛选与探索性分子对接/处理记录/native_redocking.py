from pathlib import Path
import os,sys,urllib.request,json,subprocess,re
W=Path('./local_user/.codex/tmp/aki_fig9_11_work');deps=Path(os.environ.get('AKI_CHEM_DEPS',str(W/'chem_deps')));sys.path.insert(0,str(deps));handles=[os.add_dll_directory(str(p)) for p in deps.glob('*.libs') if p.is_dir()];handles.append(os.add_dll_directory(str(deps/'rdkit')))
from rdkit import Chem
from rdkit.Chem import AllChem,rdMolAlign
from meeko import MoleculePreparation,PDBQTWriterLegacy,PDBQTMolecule,RDKitMolCreate
import pandas as pd
OUT=Path(os.environ.get('AKI_DOCKING_ROOT','./local_user/.codex/tmp/aki_docking_output'));inp=OUT/'inputs';dest=OUT/'controls';dest.mkdir(exist_ok=True);vina=OUT/'处理记录/软件/vina_1.2.7_win.exe'
rows=[]
for gene,pdb,code in [('AKT1','3O96','IQO'),('IL1B','6Y8I','OGE')]:
    nativefile=dest/(gene+'_native.sdf');url=f'https://models.rcsb.org/v1/{pdb.lower()}/ligand?auth_asym_id=A&label_comp_id={code}&encoding=sdf'
    if not nativefile.exists():nativefile.write_bytes(urllib.request.urlopen(url,timeout=60).read())
    native=Chem.SDMolSupplier(str(nativefile),removeHs=False)[0];assert native is not None
    mol=Chem.AddHs(native,addCoords=True);qt,ok,msg=PDBQTWriterLegacy.write_string(MoleculePreparation()(mol)[0]);assert ok,msg
    (inp/'ligands'/f'{gene}_native.pdbqt').write_text(qt,encoding='ascii')
    # One native-ligand pose recovery check per site; metabolite scores use three seeds independently.
    for seed in [20261019]:
        pose=dest/f'{gene}_native_seed{seed}.pdbqt';log=pose.with_suffix('.log')
        if not pose.exists():
            args=[str(vina),'--receptor',f'receptors/{gene}.pdbqt','--ligand',f'ligands/{gene}_native.pdbqt','--config',f'configs/{gene}_box.txt','--seed',str(seed),'--out',f'../controls/{pose.name}','--verbosity','1']
            r=subprocess.run(args,cwd=inp,capture_output=True,text=True,encoding='utf8',errors='replace');log.write_text(r.stdout+'\n'+r.stderr,encoding='utf8');assert r.returncode==0,r.stderr
        scores=re.findall(r'REMARK VINA RESULT:\s+(-?[\d.]+)',pose.read_text());docked=RDKitMolCreate.from_pdbqt_mol(PDBQTMolecule.from_file(str(pose),skip_typing=True))[0];assert docked is not None
        probe=Chem.RemoveHs(docked);ref=Chem.RemoveHs(native);rmsds=[rdMolAlign.CalcRMS(probe,ref,prbId=k,refId=0) for k in range(probe.GetNumConformers())]
        rows.append({'Gene':gene,'PDB_ID':pdb,'Native_ligand':code,'Seed':seed,'Top_score':float(scores[0]),'Top_pose_RMSD_A':rmsds[0],'Minimum_RMSD_top9_A':min(rmsds),'Top_pose_within_2A':rmsds[0]<=2,'Source_URL':url})
        print('CONTROL',gene,seed,round(rmsds[0],3),flush=True)
pd.DataFrame(rows).to_csv(OUT/'各子图数据表/共晶配体重对接验证.csv',index=False,encoding='utf-8-sig')
