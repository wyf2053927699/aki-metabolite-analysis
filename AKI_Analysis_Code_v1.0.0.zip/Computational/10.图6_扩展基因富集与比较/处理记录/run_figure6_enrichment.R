options(stringsAsFactors=FALSE,timeout=60)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(clusterProfiler);library(org.Hs.eg.db);library(GO.db);library(AnnotationDbi);library(jsonlite)})
arg<-grep('^--file=',commandArgs(),value=TRUE)
script_dir<-if(length(arg))dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))else''
root<-if(basename(script_dir)=='处理记录')dirname(script_dir)else'./Computational/10.图6_扩展基因富集与比较'
raw<-file.path(root,'原始数据');audit<-file.path(root,'处理记录');tables<-file.path(root,'各子图数据表');objects<-file.path(audit,'R对象')
for(p in c(root,raw,audit,tables,objects))dir.create(p,recursive=TRUE,showWarnings=FALSE)
write_csv<-function(x,p){con<-file(p,'wb');writeBin(charToRaw('\xef\xbb\xbf'),con);writeBin(charToRaw(enc2utf8(paste(capture.output(write.csv(x,row.names=FALSE,na='')),collapse='\n'))),con);close(con)}
copy_once<-function(from,to){if(!file.exists(to))stopifnot(file.copy(from,to))}
fig4<-'./Computational/8.图4_GO_KEGG与功能网络'
copy_once('./Computational/9.图5_GeneMANIA功能关联扩展/各网络数据表/原49基因_加入预测结果后去重.csv',file.path(raw,'输入_105个扩展候选基因.csv'))
copy_once(file.path(fig4,'处理记录','R对象','图4完整分析对象.rds'),file.path(raw,'原49基因_图4完整分析对象.rds'))
copy_once(file.path(fig4,'处理记录','R软件版本.csv'),file.path(raw,'图4_R软件版本.csv'))
for(nm in c('KEGG_hsa_ncbi_geneid_GSON.rds','KEGG_GSON_provenance.json','KEGG_gsid2gene.tsv','KEGG_gsid2name.tsv','输入_49个交集靶点.csv'))
  copy_once(file.path(fig4,'原始数据',nm),file.path(raw,nm))
for(domain in c('BP','CC','MF','KEGG'))copy_once(file.path(fig4,'处理记录','R对象',paste0(domain,'_enrichResult.rds')),file.path(raw,paste0('原49_',domain,'_enrichResult.rds')))
input<-read.csv(file.path(raw,'输入_105个扩展候选基因.csv'),fileEncoding='UTF-8-BOM',colClasses='character',check.names=FALSE)
stopifnot(nrow(input)==105,length(unique(input$Gene_symbol))==105,length(unique(input$Entrez_ID))==105)
mapping<-data.frame(SYMBOL=input$Gene_symbol,ENTREZID=input$Entrez_ID,In_original49=tolower(input$In_original49)=='true',Newly_added=tolower(input$Newly_added)=='true')
approved<-AnnotationDbi::select(org.Hs.eg.db,keys=mapping$ENTREZID,keytype='ENTREZID',columns='SYMBOL')
approved<-unique(approved[,c('ENTREZID','SYMBOL')]);stopifnot(!anyDuplicated(approved$ENTREZID),!anyNA(approved$SYMBOL))
mapping$OrgDb_approved_SYMBOL<-approved$SYMBOL[match(mapping$ENTREZID,approved$ENTREZID)]
mapping$Symbol_matches_OrgDb<-mapping$SYMBOL==mapping$OrgDb_approved_SYMBOL
stopifnot(!anyNA(mapping$OrgDb_approved_SYMBOL))
write_csv(mapping,file.path(tables,'输入105基因_Entrez与符号核对.csv'))
original<-readRDS(file.path(raw,'原49基因_图4完整分析对象.rds'))
stopifnot(setequal(original$mapping$ENTREZID,mapping$ENTREZID[mapping$In_original49]),sum(mapping$Newly_added)==56)
versions4<-read.csv(file.path(raw,'图4_R软件版本.csv'),fileEncoding='UTF-8-BOM')
for(p in c('clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi'))stopifnot(as.character(packageVersion(p))==versions4$Version[match(p,versions4$Package)])
pkgs<-c('clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi','gson','ggplot2','patchwork','ragg','svglite')
write_csv(data.frame(Package=pkgs,Version=vapply(pkgs,function(p)as.character(packageVersion(p)),'')),file.path(audit,'R软件版本.csv'))
writeLines(capture.output(sessionInfo()),file.path(audit,'R_sessionInfo.txt'))
for(p in c('org.Hs.eg.db','GO.db'))write.table(AnnotationDbi::metadata(get(p)),file.path(raw,paste0(p,'_metadata.tsv')),sep='\t',quote=FALSE,row.names=FALSE,fileEncoding='UTF-8')
query<-as.character(mapping$ENTREZID);symbols<-setNames(mapping$SYMBOL,mapping$ENTREZID)
kg<-readRDS(file.path(raw,'KEGG_hsa_ncbi_geneid_GSON.rds'))
res<-list();top<-list();summaries<-list();members<-list();validations<-list();comparisons<-list();oldres<-list()
for(domain in c('BP','CC','MF','KEGG')){
  message('Enriching expanded105: ',domain)
  if(domain=='KEGG')obj<-enrichKEGG(gene=query,organism=kg,keyType='ncbi-geneid',pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,use_internal_data=FALSE)
  else obj<-enrichGO(gene=query,OrgDb=org.Hs.eg.db,keyType='ENTREZID',ont=domain,pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,readable=FALSE)
  oldobj<-readRDS(file.path(raw,paste0('原49_',domain,'_enrichResult.rds')))
  stopifnot(inherits(obj,'enrichResult'),setequal(obj@universe,oldobj@universe),setequal(obj@result$ID,oldobj@result$ID))
  saveRDS(obj,file.path(objects,paste0('扩展105_',domain,'_enrichResult.rds')))
  df<-obj@result;df$Domain<-domain
  df$Gene_symbols<-vapply(strsplit(df$geneID,'/',fixed=TRUE),function(g)paste(sort(unique(na.omit(symbols[g]))),collapse='/'),'')
  df$BH_significant<-!is.na(df$p.adjust)&df$p.adjust<.05&df$FoldEnrichment>1
  df$GeneRatio_numeric<-vapply(strsplit(df$GeneRatio,'/',fixed=TRUE),function(x)as.numeric(x[1])/as.numeric(x[2]),0.)
  df$Minus_log10_P<--log10(pmax(df$pvalue,.Machine$double.xmin));df$Minus_log10_FDR<--log10(pmax(df$p.adjust,.Machine$double.xmin))
  res[[domain]]<-df;oldres[[domain]]<-original$results[[domain]]
  write_csv(df,file.path(tables,paste0('扩展105_',domain,'_全部富集检验.csv')))
  write_csv(df[df$BH_significant,],file.path(tables,paste0('扩展105_',domain,'_BH显著富集结果.csv')))
  write_csv(oldres[[domain]],file.path(tables,paste0('原49_',domain,'_全部富集检验.csv')))
  choose<-function(d){z<-d[d$BH_significant,];if(domain=='KEGG')z<-z[order(z$pvalue,z$p.adjust,z$ID),]else z<-z[order(z$p.adjust,z$pvalue,z$ID),];z<-head(z,10);z$Selected_rank<-seq_len(nrow(z));z}
  top[[domain]]<-choose(df)
  oldtop<-choose(oldres[[domain]]);oldtop$Gene_set<-'Original49';newtop<-top[[domain]];newtop$Gene_set<-'Expanded105'
  cc<-rbind(oldtop,newtop);cc$Signed_score<-ifelse(cc$Gene_set=='Original49',cc$Minus_log10_FDR,-cc$Minus_log10_FDR)
  cc$Plot_row<-seq_len(nrow(cc));comparisons[[domain]]<-cc
  prefix<-c(BP='D',CC='E',MF='F',KEGG='G')[domain]
  write_csv(cc,file.path(tables,paste0(prefix,'_',domain,'_49与105对比_绘图数据.csv')))
  bg<-do.call(rbind,strsplit(df$BgRatio,'/'));gr<-do.call(rbind,strsplit(df$GeneRatio,'/'))
  pp<-phyper(df$Count-1,as.numeric(bg[,1]),as.numeric(bg[,2])-as.numeric(bg[,1]),as.numeric(gr[,2]),lower.tail=FALSE)
  maxp<-max(abs(pp-df$pvalue));maxbh<-max(abs(p.adjust(df$pvalue,'BH')-df$p.adjust))
  countok<-all(vapply(seq_len(nrow(df)),function(i)length(intersect(query,obj@geneSets[[df$ID[i]]]))==df$Count[i],TRUE))
  stopifnot(maxp<1e-10,maxbh<1e-10,countok)
  validations[[domain]]<-data.frame(Domain=domain,Max_P_difference=maxp,Max_BH_difference=maxbh,Count_matches_geneset=countok,
    Same_background_as_Figure4=setequal(obj@universe,oldobj@universe),Same_test_family_as_Figure4=setequal(df$ID,oldobj@result$ID))
  members[[domain]]<-do.call(rbind,lapply(names(obj@geneSets),function(id){g<-intersect(query,obj@geneSets[[id]]);if(!length(g))return(NULL);data.frame(Domain=domain,Term_ID=id,EntrezID=g,Gene_symbol=unname(symbols[g]))}))
  write_csv(data.frame(EntrezID=obj@universe,In_expanded105=obj@universe%in%query,In_original49=obj@universe%in%original$mapping$ENTREZID),file.path(raw,paste0(domain,'_共同有效背景基因.csv')))
  summaries[[domain]]<-rbind(data.frame(Gene_set='Original49',Domain=domain,Input_unique_Entrez=49,Effective_foreground=length(intersect(original$mapping$ENTREZID,obj@universe)),
    Effective_background=length(obj@universe),Tested_terms=nrow(oldres[[domain]]),BH_significant_terms=sum(oldres[[domain]]$BH_significant),Displayed_terms=nrow(oldtop),Minimum_FDR=min(oldres[[domain]]$p.adjust)),
    data.frame(Gene_set='Expanded105',Domain=domain,Input_unique_Entrez=105,Effective_foreground=length(intersect(query,obj@universe)),Effective_background=length(obj@universe),
    Tested_terms=nrow(df),BH_significant_terms=sum(df$BH_significant),Displayed_terms=nrow(top[[domain]]),Minimum_FDR=min(df$p.adjust)))
}
write_csv(do.call(rbind,top[c('BP','CC','MF')]),file.path(tables,'A_扩展105_GO三类前10_绘图数据.csv'))
write_csv(top$KEGG,file.path(tables,'B_扩展105_KEGG前10_绘图数据.csv'))
write_csv(do.call(rbind,summaries),file.path(tables,'49与105富集汇总.csv'))
write_csv(do.call(rbind,members),file.path(raw,'105输入基因_全部被检验术语注释.csv'))
write_csv(do.call(rbind,validations),file.path(audit,'R数值与背景独立核对.csv'))
protocol<-list(engine='R clusterProfiler::enrichGO and enrichKEGG, unchanged functions',original_count=49,expanded_count=105,newly_added_count=56,
    scope='Original49 Figure2C candidates vs union105 from Figure5; neither group is just six core genes',organism='Homo sapiens',
    GO_annotation='org.Hs.eg.db 3.23.1 GOALL; BP CC MF adjusted separately',KEGG_annotation='Same official human KEGG GSON snapshot retrieved 2026-10-18 as Figure4',
    background='Same database-annotated human background within each domain for both gene sets; verified equal IDs and test families',
    original_results='Reused exact Figure4 R results; package versions, universe IDs and tested term IDs checked against the expanded analysis',
    pAdjustMethod='BH',pvalueCutoff=1,qvalueCutoff=1,minGSSize=10,maxGSSize=500,significance='BH adjusted P < 0.05 and FoldEnrichment > 1',
    A_selection='At most ten significant terms per GO ontology, ordered by BH adjusted P, nominal P then ID; height -log10(BH adjusted P)',
    B_selection='At most ten BH-significant pathways ordered by nominal P, BH adjusted P then ID; length -log10(nominal P), dot area Count',
    C_selection='KEGG BRITE br08901 Level1 Cellular Processes only; BH-significant pathways ranked by overlapping-gene Count descending, then adjusted P and ID; at most ten; axis Count',
    comparison_selection='Within each domain select top ten significant terms independently in Original49 and Expanded105; CC Original49 has only four. Positive and negative directions separate the gene sets only.',
    comparison_axis='Absolute -log10(BH adjusted P); Original49 to right, Expanded105 to left; direction is not expression up/down or activation/inhibition',
    comparison_inference='Descriptive comparison of enrichment, not a formal between-set significance test; nested sets and different foreground sizes affect P values',
    reference_difference='Reference uses DAVID and compares 47 vs106 genes; user data are 49 vs105 and use requested clusterProfiler; use adjusted P rather than label ambiguous Storey qvalue',
    reference_DOI='10.1186/s40643-026-01083-8',reference_figure='6A-G')
write_json(protocol,file.path(audit,'analysis_protocol.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
saveRDS(list(mapping=mapping,input=input,original_results=oldres,results=res,selected=top,comparisons=comparisons,members=members,
    summary=do.call(rbind,summaries),protocol=protocol),file.path(objects,'图6完整富集分析对象.rds'))
message('FIGURE6 ENRICHMENT COMPLETE');print(do.call(rbind,summaries),row.names=FALSE)
