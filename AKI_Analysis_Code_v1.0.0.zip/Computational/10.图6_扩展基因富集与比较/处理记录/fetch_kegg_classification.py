from pathlib import Path
import urllib.request,json,datetime,hashlib,re
import pandas as pd
ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/10.图6_扩展基因富集与比较')
RAW=ROOT/'原始数据';RAW.mkdir(parents=True,exist_ok=True)
url='https://rest.kegg.jp/get/br:br08901/json';target=RAW/'KEGG_br08901_通路分类.json'
if not target.exists():
    with urllib.request.urlopen(url,timeout=60) as response:raw=response.read()
    json.loads(raw);target.write_bytes(raw)
    (RAW/'KEGG_br08901_来源.json').write_text(json.dumps(dict(URL=url,Retrieved_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),Bytes=len(raw),SHA256=hashlib.sha256(raw).hexdigest()),indent=2),encoding='utf-8')
tree=json.loads(target.read_text(encoding='utf-8'));rows=[]
for level1 in tree['children']:
    for level2 in level1.get('children',[]):
        for leaf in level2.get('children',[]):
            match=re.match(r'^(\d{5})\s+(.+)',leaf['name'])
            if match:rows.append(dict(ID='hsa'+match.group(1),Pathway_name=match.group(2),Level1=level1['name'],Level2=level2['name']))
df=pd.DataFrame(rows).drop_duplicates()
df.to_csv(RAW/'KEGG_br08901_通路分类表.csv',index=False,encoding='utf-8-sig')
cell=df[df.Level1.str.contains('Cellular Processes',regex=False)]
assert len(cell)>10
print('Classification rows',len(df),'Cellular Processes rows',len(cell));print(cell[['ID','Pathway_name']].to_string(index=False))
