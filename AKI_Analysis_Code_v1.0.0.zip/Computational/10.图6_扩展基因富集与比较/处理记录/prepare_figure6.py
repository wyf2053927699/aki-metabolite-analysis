from pathlib import Path
import pandas as pd
import numpy as np
import json,hashlib

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/10.图6_扩展基因富集与比较')
T=ROOT/'各子图数据表';A=ROOT/'处理记录';R=ROOT/'原始数据'
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip')
def save(df,name):df.to_csv(T/name,index=False,encoding='utf-8-sig')
go=read('A_扩展105_GO三类前10_绘图数据.csv');kegg=read('B_扩展105_KEGG前10_绘图数据.csv')
fullk=read('扩展105_KEGG_全部富集检验.csv')
classification=pd.read_csv(R/'KEGG_br08901_通路分类表.csv',encoding='utf-8-sig')
cellclass=classification[classification.Level1.str.contains('Cellular Processes',regex=False)]
assert not cellclass.ID.duplicated().any()
cellpool=fullk.merge(cellclass[['ID','Level1','Level2']],on='ID',how='inner',validate='one_to_one')
save(cellpool,'C_CellularProcesses_全部被检验通路.csv')
cell=cellpool[cellpool.BH_significant].sort_values(['Count','p.adjust','ID'],ascending=[False,True,True]).head(10).copy()
cell['Selected_rank']=range(1,len(cell)+1)
assert len(cell)>0
save(cell,'C_细胞过程前10_绘图数据.csv')
mapping=read('输入105基因_Entrez与符号核对.csv')
for domain in ['BP','CC','MF','KEGG']:
    bg=pd.read_csv(R/(domain+'_共同有效背景基因.csv'),encoding='utf-8-sig',dtype={'EntrezID':str})
    mapping['In_'+domain]=mapping.ENTREZID.astype(str).isin(set(bg.EntrezID))
save(mapping,'输入105基因_注释覆盖核对.csv')
summary=read('49与105富集汇总.csv')
matched=[];comp={}
for panel,domain in [('D','BP'),('E','CC'),('F','MF'),('G','KEGG')]:
    z=read(f'{panel}_{domain}_49与105对比_绘图数据.csv');comp[panel]=z
    old=read('原49_'+domain+'_全部富集检验.csv').set_index('ID')
    new=read('扩展105_'+domain+'_全部富集检验.csv').set_index('ID')
    allpaired=[]
    for term in old.index:
        a=old.loc[term];b=new.loc[term]
        row={'Domain':domain,'ID':term,'Description':b.Description,
            'Original49_Count':int(a.Count),'Expanded105_Count':int(b.Count),
            'Original49_pvalue':a.pvalue,'Expanded105_pvalue':b.pvalue,
            'Original49_p.adjust':a['p.adjust'],'Expanded105_p.adjust':b['p.adjust'],
            'Original49_FDR_score':a.Minus_log10_FDR,'Expanded105_FDR_score':b.Minus_log10_FDR,
            'Original49_GeneRatio':a.GeneRatio,'Expanded105_GeneRatio':b.GeneRatio,
            'Original49_BH_significant':a.BH_significant,'Expanded105_BH_significant':b.BH_significant,
            'Original49_Genes':a.Gene_symbols,'Expanded105_Genes':b.Gene_symbols,
            'Selected_original49':term in set(z.loc[z.Gene_set=='Original49','ID']),
            'Selected_expanded105':term in set(z.loc[z.Gene_set=='Expanded105','ID'])}
        allpaired.append(row)
        if row['Selected_original49'] or row['Selected_expanded105']:matched.append(row)
    save(pd.DataFrame(allpaired),f'{panel}_{domain}_两组同术语完整对照.csv')
matched=pd.DataFrame(matched)
save(matched,'D至G_展示术语_两组数值并列核对.csv')
protocol=json.loads((A/'analysis_protocol.json').read_text(encoding='utf-8'))
protocol['C_classification_source']='KEGG br:br08901 JSON retrieved 2026-10-19; exact Level1 Cellular Processes category, intersected with tested human pathways'
protocol['C_eligible_tested_pathways']=len(cellpool)
protocol['C_BH_significant_pathways']=int(cellpool.BH_significant.sum())
protocol['C_displayed_pathways']=len(cell)
(A/'analysis_protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
palette={'BP':'#24A07C','CC':'#D96623','MF':'#6B73B1','KEGG':'#FB766F','CellularProcesses':'#E64C34','Original49':'#A4801F','Expanded105':'#529957'}
(A/'配色与图形规则.json').write_text(json.dumps({'reference_DOI':'10.1186/s40643-026-01083-8','reference_figure':'6A-G',
    'palette':palette,'method':'GO and KEGG hues follow Figure4; Cellular Processes and comparison hues extracted from modal RGB interiors of the supplied Figure6 PDF raster',
    'comparison_axis':'Magnitude is -log10(BH adjusted P); direction separates gene sets, not expression direction'},ensure_ascii=False,indent=2),encoding='utf-8')

labels={'Gene_set':'基因集','Domain':'类别','Selected_rank':'组内展示顺序','ID':'术语/通路ID','Description':'完整名称','Count':'命中基因数',
    'pvalue':'原始P值','p.adjust':'BH校正P值','GeneRatio':'基因比例','BgRatio':'背景比例','FoldEnrichment':'富集倍数',
    'Minus_log10_P':'−log10(原始P)','Minus_log10_FDR':'−log10(BH校正P)','Gene_symbols':'命中基因',
    'Signed_score':'作图方向分值','Plot_row':'作图行序','Level1':'KEGG一级类别','Level2':'KEGG二级类别',
    'Input_unique_Entrez':'输入基因数','Effective_foreground':'有效前景数','Effective_background':'有效背景数','Tested_terms':'检验条目数',
    'BH_significant_terms':'BH显著条目数','Displayed_terms':'绘图条目数','Minimum_FDR':'最小BH校正P',
    'SYMBOL':'输入基因符号','ENTREZID':'Entrez ID','In_original49':'原49候选基因中','Newly_added':'新增基因',
    'OrgDb_approved_SYMBOL':'OrgDb认可符号','Symbol_matches_OrgDb':'符号与OrgDb一致','Parameter':'参数','Value':'值',
    'In_BP':'具有BP注释','In_CC':'具有CC注释','In_MF':'具有MF注释','In_KEGG':'具有KEGG注释',
    'Original49_Count':'原49命中数','Expanded105_Count':'扩展105命中数','Original49_pvalue':'原49原始P','Expanded105_pvalue':'扩展105原始P',
    'Original49_p.adjust':'原49BH校正P','Expanded105_p.adjust':'扩展105BH校正P','Original49_FDR_score':'原49显著性分值','Expanded105_FDR_score':'扩展105显著性分值',
    'Original49_GeneRatio':'原49基因比例','Expanded105_GeneRatio':'扩展105基因比例','Original49_BH_significant':'原49是否显著','Expanded105_BH_significant':'扩展105是否显著',
    'Original49_Genes':'原49命中基因','Expanded105_Genes':'扩展105命中基因','Selected_original49':'原49前10中','Selected_expanded105':'扩展105前10中'}
sheets=[]
def add(name,key,df,title,notes,widths=None):
    fields=list(df.columns)
    if widths is None:widths=[95 if f in ['Gene_symbols','Original49_Genes','Expanded105_Genes'] else 82 if f in ['Description','Value'] else 38 if f in ['Level1','Level2'] else 24 for f in fields]
    rows=df.astype(object).where(pd.notna(df),None).values.tolist()
    sheets.append(dict(name=name,key=key,fields=fields,labels=[labels.get(f,f) for f in fields],widths=widths,title=title,notes=(notes+['']*3)[:3],rows=rows))
add('结果概览','summary',summary,'图6｜原49个与扩展105个候选基因的富集分析',[
    'GO三类分别BH校正；KEGG单独BH校正；阈值BH校正P<0.05且富集倍数>1。',
    '两组使用相同背景、注释快照、R包版本及被检验术语家族。',
    '原49结果直接沿用图4；各组最多展示10项显著条目，不足10项按真实数目。'])
base=['Domain','Selected_rank','ID','Description','Count','pvalue','p.adjust','GeneRatio','BgRatio','FoldEnrichment','Minus_log10_FDR','Gene_symbols']
add('A_扩展105_GO','A',go[base],'图6A｜扩展105候选基因的GO富集',[
    'BP/CC/MF分别按BH校正P、原始P、ID排序，最多各10项。','柱高=−log10(BH校正P)；配色沿用图4及参考文献。','完整富集结果与背景基因见各子图数据表及原始数据。'])
baseb=['Selected_rank','ID','Description','Count','pvalue','p.adjust','GeneRatio','BgRatio','FoldEnrichment','Minus_log10_P','Gene_symbols']
add('B_扩展105_KEGG','B',kegg[baseb],'图6B｜扩展105候选基因的KEGG前10显著通路',[
    '先通过BH显著性阈值，再按原始P、BH校正P、ID取前10。','柱长=−log10(原始P)；黑点面积=命中基因数。','采用与图4完全相同的官方KEGG人类注释快照。'])
add('C_细胞过程','C',cell[baseb+['Level1','Level2']],'图6C｜KEGG Cellular Processes类别中的显著通路',[
    '按官方BRITE br08901分类提取，不依据通路名称手动挑选。','从BH显著通路中按命中基因数降序取前10；柱长=Count。',
    f'符合类别且被检验的通路{len(cellpool)}条，其中{int(cellpool.BH_significant.sum())}条BH显著，图中展示{len(cell)}条。'])
for panel,domain in [('D','BP'),('E','CC'),('F','MF'),('G','KEGG')]:
    fields=['Gene_set','Selected_rank','ID','Description','Count','pvalue','p.adjust','GeneRatio','BgRatio','FoldEnrichment','Minus_log10_FDR','Signed_score','Plot_row','Gene_symbols']
    add(panel+'_'+domain+'对比',panel,comp[panel][fields],'图6'+panel+'｜'+domain+'：原49与扩展105候选基因对比',[
        '两组各自独立选取前10个显著条目；对比条目不要求一一相同。','金色向右：原49；绿色向左：扩展105；绝对长度=−log10(BH校正P)。',
        '方向仅区分基因集；不是表达上/下调，也不是两组差异的显著性检验。'])
add('展示术语并列核对','matched',matched,'图6D–G｜所有展示术语在两组中的完整数值',[
    '将任一组前10中的每个术语，按ID对齐两组命中数、P值及BH校正P。','可用本表核查同一术语在扩展前后的数值变化。','所有被检验术语的完整并列表另存D/E/F/G对应CSV。'])
add('输入105基因','mapping',mapping,'图6｜105个输入基因及Entrez ID核对',[
    '49个原始候选基因+56个GeneMANIA扩展的新基因。','保留图5提供的Entrez ID，逐一核查org.Hs.eg.db认可符号。','未按STRING映射、连通性或仅6个核心靶点缩减输入。'])
params=pd.DataFrame([dict(Parameter=k,Value=json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else str(v)) for k,v in protocol.items()])
versions=pd.read_csv(A/'R软件版本.csv',encoding='utf-8-sig',dtype=str)
params=pd.concat([params,pd.DataFrame([dict(Parameter='Package: '+r.Package,Value=r.Version) for r in versions.itertuples()])],ignore_index=True)
add('分析参数与来源','parameters',params,'图6｜分析方法、背景及版本',[
    '参考文献 DOI：10.1186/s40643-026-01083-8，图6A–G。','原文为DAVID、47对106；本次按用户数据为clusterProfiler、49对105。',
    '官方KEGG分类来源：https://rest.kegg.jp/get/br:br08901/json'],[43,135])
(A/'workbook_payload.json').write_text(json.dumps({'sheets':sheets,'summary':{'workbook':'图6_全部子图数据与比较结果.xlsx'}},ensure_ascii=False,allow_nan=False),encoding='utf-8')
manifest=[dict(File=str(p.relative_to(ROOT)).replace('\\','/'),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(R.iterdir()) if p.is_file()]
pd.DataFrame(manifest).to_csv(A/'原始输入与注释_SHA256.csv',index=False,encoding='utf-8-sig')
print(summary.to_string(index=False));print('C:',len(cellpool),'tested;',int(cellpool.BH_significant.sum()),'significant;',len(cell),'displayed')
print(cell[['ID','Description','Count','p.adjust']].to_string(index=False))
