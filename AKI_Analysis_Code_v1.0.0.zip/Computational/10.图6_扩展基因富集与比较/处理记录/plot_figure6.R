options(stringsAsFactors=FALSE)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(ggplot2);library(patchwork);library(jsonlite)})
arg<-grep('^--file=',commandArgs(),value=TRUE);script_dir<-if(length(arg))dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))else''
root<-if(basename(script_dir)=='处理记录')dirname(script_dir)else'./Computational/10.图6_扩展基因富集与比较'
audit<-file.path(root,'处理记录');tables<-file.path(root,'各子图数据表');out<-file.path(root,'图片');qa<-file.path(audit,'图片预览');pdir<-file.path(audit,'单页PDF')
for(d in c(out,qa,pdir))dir.create(d,recursive=TRUE,showWarnings=FALSE)
obj<-readRDS(file.path(audit,'R对象','图6完整富集分析对象.rds'))
export<-'--export'%in%commandArgs(TRUE)
pal<-c(BP='#24A07C',CC='#D96623',MF='#6B73B1',KEGG='#FB766F',CellularProcesses='#E64C34',Original49='#A4801F',Expanded105='#529957')
read_csv<-function(nm)read.csv(file.path(tables,nm),fileEncoding='UTF-8-BOM',check.names=FALSE)
theme_ref<-function()theme_classic(base_size=10,base_family='Arial')+theme(
  plot.title=element_text(size=13,margin=margin(b=6)),plot.subtitle=element_text(size=8.5,margin=margin(b=7)),
  axis.title=element_text(size=10),axis.text=element_text(size=8.5,color='#202020'),axis.line=element_line(linewidth=.35,color='#555555'),
  axis.ticks=element_line(linewidth=.3),legend.title=element_text(size=9),legend.text=element_text(size=8.5),legend.key.height=grid::unit(4,'mm'),
  strip.background=element_rect(fill='#D9D9D9',color=NA),strip.text=element_text(size=9),plot.margin=margin(9,11,9,11))
go<-do.call(rbind,obj$selected[c('BP','CC','MF')]);go$Domain<-factor(go$Domain,levels=c('BP','CC','MF'))
go<-go[order(go$Domain,go$Minus_log10_FDR,go$ID),];go$key<-factor(go$ID,levels=go$ID)
go_labels<-setNames(go$Description,go$ID)
A<-ggplot(go,aes(x=key,y=Minus_log10_FDR,fill=Domain))+geom_col(width=.83)+
  facet_grid(.~Domain,scales='free_x',space='free_x',switch='x')+
  scale_fill_manual(values=pal,guide='none')+scale_x_discrete(labels=go_labels,expand=expansion(add=.55))+
  scale_y_continuous(expand=expansion(mult=c(0,.08)),breaks=scales::breaks_pretty(5))+
  labs(x=NULL,y=expression(-log[10]('BH adjusted P')),title='GO enrichment',subtitle='105 expanded candidate genes | up to 10 terms per ontology | BH FDR < 0.05')+
  theme_ref()+theme(axis.text.x=element_text(angle=65,hjust=1,vjust=1,size=7.3),
    strip.placement='outside',strip.background=element_blank(),strip.text.x=element_text(size=10),panel.spacing.x=grid::unit(3,'mm'),plot.margin=margin(9,10,9,65))
k<-obj$selected$KEGG;k$key<-factor(k$ID,levels=rev(k$ID))
klab<-setNames(vapply(k$Description,function(s)paste(strwrap(s,35),collapse='\n'),''),k$ID)
B<-ggplot(k,aes(x=Minus_log10_P,y=key))+geom_col(fill=pal['KEGG'],width=.76)+geom_point(aes(size=Count),color='#282828')+
  facet_grid('KEGG'~.)+scale_y_discrete(labels=klab,expand=expansion(add=.65))+
  scale_x_continuous(expand=expansion(mult=c(0,.08)),breaks=scales::breaks_pretty(5))+
  scale_size_area(max_size=5.0,breaks=pretty(range(k$Count),n=4))+
  labs(x=expression(-log[10]('P value')),y=NULL,size='Count',title='KEGG enrichment',subtitle='105 expanded candidate genes | BH FDR < 0.05')+
  theme_ref()+theme(axis.text.y=element_text(size=8.6,lineheight=.92),legend.position='right')
cell<-read_csv('C_细胞过程前10_绘图数据.csv');cell$key<-factor(cell$ID,levels=rev(cell$ID))
clab<-setNames(vapply(cell$Description,function(s)paste(strwrap(s,36),collapse='\n'),''),cell$ID)
C<-ggplot(cell,aes(x=Count,y=key))+geom_col(fill=pal['CellularProcesses'],width=.72)+
  geom_text(aes(label=Count),hjust=-.45,size=8/ggplot2::.pt,family='Arial')+
  scale_y_discrete(labels=clab,expand=expansion(add=.6))+scale_x_continuous(expand=expansion(mult=c(0,.13)),breaks=scales::breaks_pretty(5))+
  labs(x='Overlapping genes (Count)',y=NULL,title='Cellular Processes',subtitle='KEGG classification | BH FDR < 0.05 | ranked by Count')+
  theme_ref()+theme(axis.text.y=element_text(size=8.6,lineheight=.92))
compare_plot<-function(domain,small=FALSE){
  z<-obj$comparisons[[domain]];z$Gene_set<-factor(z$Gene_set,levels=c('Original49','Expanded105'))
  z$label<-vapply(z$Description,function(s)paste(strwrap(s,if(small)44 else 64),collapse='\n'),'')
  old<-z[z$Gene_set=='Original49',];new<-z[z$Gene_set=='Expanded105',]
  xmax<-ceiling(max(abs(z$Signed_score))/5)*5
  p<-ggplot(z,aes(x=Signed_score,y=Plot_row,fill=Gene_set))+geom_col(orientation='y',width=.80)+
    geom_vline(xintercept=0,linewidth=.35,color='#9B9B9B')+
    geom_hline(yintercept=nrow(old)+.5,linewidth=.25,color='#E2E2E2')+
    geom_text(data=old,aes(x=-xmax*.015,label=label),hjust=1,lineheight=.88,size=(if(small)7.5 else 9.5)/ggplot2::.pt,family='Arial')+
    geom_text(data=new,aes(x=xmax*.015,label=label),hjust=0,lineheight=.88,size=(if(small)7.5 else 9.5)/ggplot2::.pt,family='Arial')+
    scale_fill_manual(values=pal[c('Original49','Expanded105')],labels=c('Original candidates (n = 49)','Expanded candidates (n = 105)'))+
    scale_y_reverse(limits=c(nrow(z)+.7,.2),breaks=NULL,expand=expansion(mult=c(0,0)))+
    scale_x_continuous(limits=c(-xmax,xmax),breaks=scales::breaks_pretty(n=7),labels=function(x)format(abs(x),trim=TRUE),expand=expansion(mult=c(0,0)))+
    labs(x=expression(-log[10]('BH adjusted P')),y=NULL,fill=NULL,title=paste0(domain,' enrichment comparison'))+
    theme_ref()+theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),legend.position='top',legend.justification='left',
      legend.text=element_text(size=if(small)8 else 10),legend.key.width=grid::unit(4,'mm'),
      plot.title=element_text(size=if(small)12 else 15),plot.margin=margin(9,16,9,16))+
    guides(fill=guide_legend(nrow=1,byrow=TRUE))
  p
}
comp<-lapply(c('BP','CC','MF','KEGG'),compare_plot);names(comp)<-c('D','E','F','G')
sm<-lapply(c('BP','CC','MF','KEGG'),function(x)compare_plot(x,TRUE));names(sm)<-c('D','E','F','G')
tag_theme<-theme(plot.tag=element_text(size=19,family='Times New Roman'),plot.tag.position=c(0,1))
tag<-function(p,s)wrap_elements(full=p)+labs(tag=s)+tag_theme
top<-((tag(A,'A'))|((tag(B,'B'))/(tag(C,'C'))))+plot_layout(widths=c(1.34,1))
main<-top/((tag(sm$D,'D'))|(tag(sm$E,'E')))/((tag(sm$F,'F'))|(tag(sm$G,'G')))+plot_layout(heights=c(6.7,5.4,5.4))
plots<-list(
 '图6_组合主图'=list(p=main,w=14,h=17.5),
 '图6A_扩展105_GO富集'=list(p=A,w=10,h=7.0),
 '图6B_扩展105_KEGG富集'=list(p=B,w=8.4,h=6.2),
 '图6C_细胞过程富集'=list(p=C,w=8.4,h=6.2),
 '图6D_BP_原49与扩展105对比'=list(p=comp$D,w=11.2,h=7.8),
 '图6E_CC_原49与扩展105对比'=list(p=comp$E,w=11.2,h=7.8),
 '图6F_MF_原49与扩展105对比'=list(p=comp$F,w=11.2,h=7.8),
 '图6G_KEGG_原49与扩展105对比'=list(p=comp$G,w=11.2,h=7.8))
manifest<-list()
for(nm in names(plots)){
  x<-plots[[nm]];message('Rendering ',nm)
  ggsave(file.path(qa,paste0(nm,'_preview.png')),x$p,width=x$w,height=x$h,dpi=120,device=ragg::agg_png,bg='white')
  if(export){
    ggsave(file.path(out,paste0(nm,'.png')),x$p,width=x$w,height=x$h,dpi=600,device=ragg::agg_png,bg='white')
    ggsave(file.path(out,paste0(nm,'.svg')),x$p,width=x$w,height=x$h,device=svglite::svglite,bg='white')
    ggsave(file.path(pdir,paste0(nm,'.pdf')),x$p,width=x$w,height=x$h,device=grDevices::cairo_pdf,family='Arial',bg='white')
  }
  saveRDS(x$p,file.path(audit,'R对象',paste0(nm,'_绘图对象.rds')))
  manifest[[nm]]<-list(width_inches=x$w,height_inches=x$h,dpi=600,formats=c('png','svg','pdf'),panel_letters=nm=='图6_组合主图')
}
write_json(manifest,file.path(audit,'图像尺寸与格式.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
if(!is.null(warnings()))writeLines(capture.output(warnings()),file.path(audit,'R绘图警告.txt'))
message('FIGURE6 PLOTTING COMPLETE')
