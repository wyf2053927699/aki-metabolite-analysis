from pathlib import Path
import pandas as pd
import numpy as np
from scipy.stats import hypergeom
import openpyxl,json,math,re,hashlib,xml.etree.ElementTree as ET
from PIL import Image
from pypdf import PdfReader
import pdfplumber

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/10.图6_扩展基因富集与比较')
A=ROOT/'处理记录';R=ROOT/'原始数据';T=ROOT/'各子图数据表';checks=[]
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip')
def check(name,ok,detail=''):checks.append(dict(Check=name,Passed=bool(ok),Detail=str(detail)))
def genes(s):return set(str(s).split('/')) if s else set()
mapping=read('输入105基因_注释覆盖核对.csv');original=pd.read_csv(R/'输入_49个交集靶点.csv',encoding='utf-8-sig',dtype=str)
gene105=set(mapping.SYMBOL);gene49=set(original.Gene_symbol)
check('105 unique genes and IDs',len(mapping)==105 and mapping.SYMBOL.nunique()==105 and mapping.ENTREZID.nunique()==105)
check('49 original genes retained',gene49<=gene105 and set(mapping.loc[mapping.In_original49,'SYMBOL'])==gene49)
check('56 added genes',mapping.Newly_added.sum()==56 and set(mapping.loc[mapping.Newly_added,'SYMBOL'])==gene105-gene49)
check('All105 symbols agree with OrgDb',mapping.Symbol_matches_OrgDb.all())
summary=read('49与105富集汇总.csv').set_index(['Gene_set','Domain'])
go=read('A_扩展105_GO三类前10_绘图数据.csv');kegg=read('B_扩展105_KEGG前10_绘图数据.csv');cell=read('C_细胞过程前10_绘图数据.csv')
membership=pd.read_csv(R/'105输入基因_全部被检验术语注释.csv',encoding='utf-8-sig')
domains=['BP','CC','MF','KEGG'];new_results={};old_results={};comparisons={}
for domain in domains:
    new=read('扩展105_'+domain+'_全部富集检验.csv');old=read('原49_'+domain+'_全部富集检验.csv');new_results[domain]=new;old_results[domain]=old
    check(domain+' same complete test family',set(new.ID)==set(old.ID))
    check(domain+' unchanged background ratios',new.set_index('ID').BgRatio.sort_index().equals(old.set_index('ID').BgRatio.sort_index()))
    check(domain+' overlap counts monotonic after expansion',(new.set_index('ID').Count.sort_index()>=old.set_index('ID').Count.sort_index()).all())
    for gene_set,frame,scope in [('Original49',old,gene49),('Expanded105',new,gene105)]:
        bg=frame.BgRatio.str.split('/',expand=True).astype(int);fg=frame.GeneRatio.str.split('/',expand=True).astype(int)
        actual=hypergeom.sf(frame.Count.to_numpy()-1,bg[1].to_numpy(),bg[0].to_numpy(),fg[1].to_numpy())
        relative=np.abs(actual-frame.pvalue.to_numpy())/np.maximum(actual,np.finfo(float).tiny)
        check(gene_set+' '+domain+' independent hypergeometric P',relative.max()<1e-8,relative.max())
        order=np.argsort(frame.pvalue.to_numpy());p=frame.pvalue.to_numpy()[order];m=len(p)
        bh_sorted=np.minimum.accumulate((p*m/np.arange(1,m+1))[::-1])[::-1];bh=np.empty(m);bh[order]=np.minimum(bh_sorted,1)
        check(gene_set+' '+domain+' independent BH',np.allclose(frame['p.adjust'],bh,rtol=1e-12,atol=0))
        check(gene_set+' '+domain+' no invalid P values',frame.pvalue.between(0,1).all() and (frame['p.adjust']>0).all())
        check(gene_set+' '+domain+' term size limits',bg[0].between(10,500).all())
        check(gene_set+' '+domain+' gene counts and scope',all(len(genes(r.Gene_symbols))==r.Count and genes(r.Gene_symbols)<=scope for r in frame.itertuples()))
        significant=(frame['p.adjust']<.05)&(frame.FoldEnrichment>1)
        check(gene_set+' '+domain+' significance flags',(frame.BH_significant==significant).all())
        check(gene_set+' '+domain+' summary counts',len(frame)==summary.loc[(gene_set,domain),'Tested_terms'] and significant.sum()==summary.loc[(gene_set,domain),'BH_significant_terms'])
        check(gene_set+' '+domain+' summary minimum P',math.isclose(frame['p.adjust'].min(),summary.loc[(gene_set,domain),'Minimum_FDR'],rel_tol=1e-12))
        check(gene_set+' '+domain+' log scores',np.allclose(frame.Minus_log10_FDR,-np.log10(frame['p.adjust']),rtol=1e-12))
    bgids=pd.read_csv(R/(domain+'_共同有效背景基因.csv'),encoding='utf-8-sig')
    check(domain+' common background IDs and size',len(bgids)==summary.loc[('Original49',domain),'Effective_background']==summary.loc[('Expanded105',domain),'Effective_background'])
    check(domain+' effective foreground counts',bgids.In_expanded105.sum()==summary.loc[('Expanded105',domain),'Effective_foreground'] and bgids.In_original49.sum()==summary.loc[('Original49',domain),'Effective_foreground'])
    check(domain+' coverage table',mapping['In_'+domain].sum()==summary.loc[('Expanded105',domain),'Effective_foreground'])
    selected=kegg if domain=='KEGG' else go[go.Domain==domain]
    sort=['pvalue','p.adjust','ID'] if domain=='KEGG' else ['p.adjust','pvalue','ID']
    expected=new[new.BH_significant].sort_values(sort).head(10)
    check(domain+' expanded top selection',list(expected.ID)==list(selected.ID))
    for row in selected.itertuples():
        observed=set(membership.loc[(membership.Domain==domain)&(membership.Term_ID==row.ID),'Gene_symbol'])
        check('Selected '+row.ID+' membership complete',observed==genes(row.Gene_symbols) and len(observed)==row.Count)
check('A28 terms real significant counts',len(go)==28 and (go.Domain=='CC').sum()==8)
check('KEGG96 annotated genes',mapping.In_KEGG.sum()==96)
classification=pd.read_csv(R/'KEGG_br08901_通路分类表.csv',encoding='utf-8-sig')
cell_ids=set(classification.loc[classification.Level1.str.contains('Cellular Processes',regex=False),'ID'])
pool=read('C_CellularProcesses_全部被检验通路.csv')
check('C exact classification intersection',set(pool.ID)==cell_ids&set(new_results['KEGG'].ID))
expected=pool[pool.BH_significant].sort_values(['Count','p.adjust','ID'],ascending=[False,True,True]).head(10)
check('C exact Count ranking',list(cell.ID)==list(expected.ID))
check('C only8 BH significant pathways',len(cell)==8 and pool.BH_significant.sum()==8)
check('C all BH values use full352 test family',np.allclose(cell.set_index('ID')['p.adjust'].sort_index(),new_results['KEGG'].set_index('ID').loc[cell.ID,'p.adjust'].sort_index(),rtol=1e-12))
matched=read('D至G_展示术语_两组数值并列核对.csv')
for panel,domain in [('D','BP'),('E','CC'),('F','MF'),('G','KEGG')]:
    comp=read(panel+'_'+domain+'_49与105对比_绘图数据.csv');comparisons[panel]=comp
    for gene_set,frame in [('Original49',old_results[domain]),('Expanded105',new_results[domain])]:
        z=comp[comp.Gene_set==gene_set];sort=['pvalue','p.adjust','ID'] if domain=='KEGG' else ['p.adjust','pvalue','ID']
        expected=frame[frame.BH_significant].sort_values(sort).head(10)
        check(panel+' '+gene_set+' top ten independently',list(z.ID)==list(expected.ID))
        sign=1 if gene_set=='Original49' else -1
        check(panel+' '+gene_set+' signed score correct',np.allclose(z.Signed_score,sign*-np.log10(z['p.adjust']),rtol=1e-12))
        check(panel+' '+gene_set+' data exact reuse',np.allclose(z['p.adjust'],frame.set_index('ID').loc[z.ID,'p.adjust'],rtol=1e-12))
    check(panel+' row order complete',list(comp.Plot_row)==list(range(1,len(comp)+1)))
    paired=read(panel+'_'+domain+'_两组同术语完整对照.csv')
    check(panel+' full paired table complete',set(paired.ID)==set(new_results[domain].ID) and not paired.ID.duplicated().any())
    kept=matched[matched.Domain==domain]
    check(panel+' displayed matched union',set(kept.ID)==set(comp.ID))
    for r in kept.itertuples():
        old=old_results[domain].set_index('ID').loc[r.ID];new=new_results[domain].set_index('ID').loc[r.ID]
        check(panel+' matched '+r.ID+' count monotonic',r.Original49_Count==old.Count and r.Expanded105_Count==new.Count and r.Expanded105_Count>=r.Original49_Count)

# Every workbook datum, cached formula and numerical precision is checked.
payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf-8'))
file=ROOT/'图6_全部子图数据与比较结果.xlsx';wb=openpyxl.load_workbook(file,data_only=False);values=openpyxl.load_workbook(file,data_only=True)
check('Excel11sheet list correct',wb.sheetnames==[s['name'] for s in payload['sheets']] and len(wb.sheetnames)==11)
formula_count=0
for s in payload['sheets']:
    sheet=wb[s['name']];cached=values[s['name']];bad=[]
    for i,row in enumerate(s['rows'],8):
        for j,expect in enumerate(row,1):
            val=cached.cell(i,j).value
            if expect=='' or expect is None:ok=val in ('',None)
            elif isinstance(expect,bool):ok=val==expect
            elif isinstance(expect,(float,int)):ok=isinstance(val,(float,int)) and not isinstance(val,bool) and math.isclose(val,expect,rel_tol=1e-12,abs_tol=1e-300)
            else:ok=str(val)==str(expect)
            if not ok:bad.append((i,j,expect,val))
            formula_count+=sheet.cell(i,j).data_type=='f'
    check('Excel '+s['name']+' full cell roundtrip',not bad,str(bad[:2]))
    check('Excel '+s['name']+' row count formula',cached['B6'].value==len(s['rows']))
    check('Excel '+s['name']+' freeze and native table',sheet.freeze_panes=='B8' and len(sheet.tables)==1)
    errors=[c.coordinate for row in cached for c in row if c.data_type=='e']
    check('Excel '+s['name']+' no formula errors',not errors,str(errors[:3]))
check('Excel calculated score formulas exist',formula_count>100,formula_count)
manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'));check('Eight graphic variants',len(manifest)==8)
descriptions={'图6_组合主图':set(go.Description)|set(kegg.Description)|set(cell.Description)|set().union(*[set(z.Description) for z in comparisons.values()]),
    '图6A_扩展105_GO富集':set(go.Description),'图6B_扩展105_KEGG富集':set(kegg.Description),'图6C_细胞过程富集':set(cell.Description)}
for panel,domain in [('D','BP'),('E','CC'),('F','MF'),('G','KEGG')]:descriptions['图6'+panel+'_'+domain+'_原49与扩展105对比']=set(comparisons[panel].Description)
for name,spec in manifest.items():
    im=Image.open(ROOT/'图片'/(name+'.png'));expected=(round(spec['width_inches']*600),round(spec['height_inches']*600))
    check(name+' PNG600dpi',im.size==expected and all(abs(v-600)<.1 for v in im.info.get('dpi',(0,0))),im.size)
    svg=ET.parse(ROOT/'图片'/(name+'.svg'));text=re.sub(r'\s+','',''.join(svg.getroot().itertext()))
    check(name+' vectorSVG',len(svg.findall('.//{http://www.w3.org/2000/svg}image'))==0)
    missing=[desc for desc in descriptions[name] if re.sub(r'\s+','',desc) not in text]
    check(name+' all term labels preserved',not missing,str(missing[:2]))
reader=PdfReader(ROOT/'图6_主图与全部子图.pdf');check('PDF8pages',len(reader.pages)==8);embedded=[]
for i,page in enumerate(reader.pages,1):
    check('PDF page '+str(i)+' vector',len(page.images)==0)
    check('PDF page '+str(i)+' selectable text',len(page.extract_text())>80)
    for f in page['/Resources'].get('/Font',{}).values():
        f=f.get_object()
        for child in f.get('/DescendantFonts',[f]):
            desc=child.get_object().get('/FontDescriptor')
            if desc:embedded.append(any(k in desc.get_object() for k in ['/FontFile','/FontFile2','/FontFile3']))
check('PDF all fonts embedded',bool(embedded) and all(embedded))
with pdfplumber.open(ROOT/'图6_主图与全部子图.pdf') as pdf:
    for i,page in enumerate(pdf.pages,1):
        outside=[c['text'] for c in page.chars if c['x0']<-.8 or c['x1']>page.width+.8 or c['top']<-.8 or c['bottom']>page.height+.8]
        check('PDF page '+str(i)+' no outside text',not outside,str(outside[:5]))
check('All8PDFpages rendered',len(list((A/'PDF预览').glob('图6-*.png')))==8)
old_versions=pd.read_csv(R/'图4_R软件版本.csv',encoding='utf-8-sig',dtype=str).set_index('Package')
new_versions=pd.read_csv(A/'R软件版本.csv',encoding='utf-8-sig',dtype=str).set_index('Package')
for p in ['clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi']:check(p+' version matches Figure4',old_versions.loc[p,'Version']==new_versions.loc[p,'Version'])
pd.DataFrame(checks).to_csv(A/'完整复核结果.csv',index=False,encoding='utf-8-sig')
report=dict(checks=len(checks),passed=sum(c['Passed'] for c in checks),failed=[c for c in checks if not c['Passed']],
    original_genes=49,expanded_genes=105,expanded_significant={d:int(summary.loc[('Expanded105',d),'BH_significant_terms']) for d in domains},
    CC_displayed_original=4,CC_displayed_expanded=8,cellular_processes_displayed=len(cell),score_formulas=formula_count,pdf_pages=len(reader.pages),workbook_sheets=len(wb.sheetnames))
(A/'validation_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False));assert not report['failed']
