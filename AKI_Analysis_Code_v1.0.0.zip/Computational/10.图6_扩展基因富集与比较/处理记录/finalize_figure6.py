from pathlib import Path
import json,subprocess,hashlib
from pypdf import PdfReader,PdfWriter
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/10.图6_扩展基因富集与比较')
A=ROOT/'处理记录';Q=A/'PDF预览';Q.mkdir(exist_ok=True)
manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
writer=PdfWriter()
for name in manifest:writer.append(str(A/'单页PDF'/(name+'.pdf')),outline_item=name)
writer.add_metadata({'/Title':'Figure 6: GO and KEGG enrichment of 105 expanded candidate genes compared with 49 original candidates','/Author':'Reproducible R clusterProfiler analysis'})
pdf=ROOT/'图6_主图与全部子图.pdf'
with pdf.open('wb') as f:writer.write(f)
exe='./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
process=subprocess.run([exe,'-r','105','-png',str(pdf),str(Q/'图6')],capture_output=True,text=True)
(A/'PDF渲染日志.txt').write_text(process.stdout+process.stderr,encoding='utf-8')
assert process.returncode==0
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
def contact(files,dest,cols=2,w=900,h=640):
    canvas=Image.new('RGB',(cols*w,((len(files)+cols-1)//cols)*h),'#E4E7EB');draw=ImageDraw.Draw(canvas)
    for i,p in enumerate(files):
        im=Image.open(p).convert('RGB');im.thumbnail((w-28,h-48));x=i%cols*w;y=i//cols*h
        draw.text((x+14,y+8),p.stem,font=font,fill='#263648');canvas.paste(im,(x+(w-im.width)//2,y+38))
    canvas.save(dest)
contact(sorted(Q.glob('图6-*.png')),A/'PDF全部页面_检查总览.png')
excel=sorted(A.glob('Excel预览_*.png'))
for i in range(0,len(excel),4):contact(excel[i:i+4],A/f'Excel检查总览_{i//4+1}.png',cols=1,w=1400,h=600)
Image.open(A/'图片预览'/'图6_组合主图_preview.png').convert('L').save(A/'图片预览'/'图6_组合主图_灰度检查.png')
files=list((ROOT/'图片').glob('*'))+[pdf,ROOT/'图6_全部子图数据与比较结果.xlsx']
(A/'交付文件_SHA256.json').write_text(json.dumps([dict(File=str(p.relative_to(ROOT)).replace('\\','/'),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(pdf_pages=len(PdfReader(pdf).pages),rendered_pages=len(list(Q.glob('图6-*.png'))),png_svg_files=len(files)-2),ensure_ascii=False))
