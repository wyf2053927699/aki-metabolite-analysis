from pathlib import Path
import urllib.request,urllib.parse,json,time,hashlib,csv,io,zipfile,gzip
ROOT=Path(r'.\Computational\7.图3_PPI与核心靶点分析')
RAW=ROOT/'原始数据';LOG=ROOT/'处理记录'
RAW.mkdir(parents=True,exist_ok=True);LOG.mkdir(exist_ok=True)
SOURCE=Path(r'.\Computational\5.gutMGene宿主基因交集_图2C\图2C_交集基因_49个.txt')
genes=[v.strip() for v in SOURCE.read_text(encoding='utf-8-sig').splitlines() if v.strip()]
assert len(genes)==49
def fetch(url,path,params=None):
    body=urllib.parse.urlencode(params).encode() if params else None
    req=urllib.request.Request(url,data=body,headers={'User-Agent':'AKI-local-reproducible-analysis/1.0'})
    data=urllib.request.urlopen(req,timeout=60).read()
    path.write_bytes(data)
    meta={'url':url,'parameters':params,'retrieved_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
          'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    path.with_suffix(path.suffix+'.provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    return data
# Preserve the initial automatic response, which matched VDR/VEGFA to unrelated
# proteins through annotation search. It must never be used in the analysis.
diagnostic=RAW/'诊断_初始自动映射_不用于分析';diagnostic.mkdir(exist_ok=True)
for stem in ['STRING_49基因_ID映射.tsv','STRING_49基因_功能关联网络_0.4.tsv']:
    for suffix in ['', '.provenance.json']:
        p=RAW/(stem+suffix)
        if p.exists() and not (diagnostic/p.name).exists():p.rename(diagnostic/p.name)
base='https://version-12-0.string-db.org'
version=fetch(base+'/api/json/version',RAW/'STRING_version.json');time.sleep(1.05)
info_data=fetch('https://stringdb-downloads.org/download/protein.info.v12.0/9606.protein.info.v12.0.txt.gz',
                RAW/'9606.protein.info.v12.0.txt.gz')
protein_info=list(csv.DictReader(io.StringIO(gzip.decompress(info_data).decode('utf-8')),delimiter='\t'))
rows=[];unmapped=[]
for gene in genes:
    matched=[r for r in protein_info if r['preferred_name']==gene]
    if len(matched)!=1:
        unmapped.append({'Gene_symbol':gene,'match_count':len(matched),'reason':'No unique exact preferred_name in STRING v12.0 human protein.info'})
    else:
        r=matched[0]
        rows.append({'queryItem':gene,'stringId':r['#string_protein_id'],'ncbiTaxonId':'9606',
                     'preferredName':r['preferred_name'],'annotation':r['annotation'],
                     'mapping_method':'Exact symbol match to official protein.info.v12.0'})
with (RAW/'STRING_严格基因映射.tsv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
(RAW/'STRING_未严格映射的输入基因.json').write_text(json.dumps(unmapped,ensure_ascii=False,indent=2),encoding='utf-8')
ids=[r['stringId'] for r in rows]
time.sleep(1.05)
params={'identifiers':'\r'.join(ids),'species':9606,'required_score':400,'network_type':'functional',
        'add_nodes':0,'caller_identity':'AKI-local-reproducible-analysis'}
network=fetch(base+'/api/tsv/network',RAW/'STRING_严格映射基因_功能关联网络_0.4.tsv',params)
edges=list(csv.DictReader(io.StringIO(network.decode('utf-8')),delimiter='\t'))
print(json.dumps({'root':str(ROOT),'version':json.loads(version),'mapped':len(rows),'unmapped':unmapped,'edges':len(edges),
                  'mapping_preview':rows[:2],'edge_preview':edges[:1]},ensure_ascii=True))
fetch('https://api.github.com/repos/lsbnb/cytoHubba/git/trees/main?recursive=1',RAW/'cytoHubba_repository_tree.json')
tree=json.loads((RAW/'cytoHubba_repository_tree.json').read_text())
print('REPOSITORY FILES:',json.dumps([v['path'] for v in tree.get('tree',[])],ensure_ascii=True))
jar=Path(r'./local_user\CytoscapeConfiguration\3\apps\installed\cytoHubba-v0.1.jar')
z=zipfile.ZipFile(jar)
(LOG/'installed_cytoHubba_contents.txt').write_text('\n'.join(z.namelist()),encoding='utf-8')
print('JAR CLASSES:',json.dumps([n for n in z.namelist() if n.endswith('.class')],ensure_ascii=True))
