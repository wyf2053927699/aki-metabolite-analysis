from pathlib import Path
import json,csv,shutil,hashlib,platform
ROOT=Path(r'.\Computational\7.图3_PPI与核心靶点分析');AUDIT=ROOT/'处理记录'
WORK=Path(r'.\local_workspace\.codex-work\figure3')
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
names=['图3_组合图','图3A_PPI网络','图3B_六算法前10靶点']+['图3B_'+m+'_前10靶点' for m in s['methods']]+['图3C_六算法交集']
index=[]
for i,name in enumerate(names,1):
    if i==1:tables='A、B、C全部CSV及Excel工作表'
    elif i==2:tables='A_PPI节点_含全部49个输入.csv；A_PPI连线.csv'
    elif i==3:tables='B_六算法全部排名.csv；B_六算法前10节点.csv；B_六算法子网连线.csv'
    elif i==10:tables='C_六算法集合归属_全部49基因.csv；C_63个精确互斥分区.csv；C_共同核心靶点.csv；C_六集合几何参数.csv'
    else:
        method=s['methods'][i-4];tables=f'B_{method}_前10节点.csv；B_{method}_子网连线.csv'
    index.append({'PDF页码':i,'图片':name+'.png','矢量图':name+'.svg','对应数据表（位于各子图数据表目录）':tables})
with (ROOT/'图片与数据表对应清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(index[0]));w.writeheader();w.writerows(index)

readme=f'''图3：PPI网络与候选核心靶点分析

结果
输入为图2C的49个交集基因。严格映射47个，形成46个有边节点、431条关联边。
六种算法前10名的共同交集为6个基因：{', '.join(s['core_genes'])}。
六组前10名单的并集为15个基因。

先看哪些文件
1. 图片/图3_组合图.png 为整张组合图；其余文件为A、B、C及B中六种算法的独立图片。
2. 所有PNG为600 dpi；同名SVG为可编辑矢量图。
3. 图3_主图与全部子图.pdf 共10页，依次为组合图、A、B六宫格、MCC、MNC、EPC、Radiality、Stress、Degree、C。
4. 图3_全部子图数据与参数.xlsx 共10张工作表，包含节点、边、完整排名、前10节点、子网边、集合归属、分区、几何参数、核心靶点、参数。
5. 各子图数据表/ 保存独立CSV，B中每种算法各有节点表和连线表。
6. 图片与数据表对应清单.csv 可逐项查询每张图对应的表格及PDF页码。

图3A的数据处理
STRING固定使用12.0，与参考论文表1的版本一致；物种Homo sapiens（9606）。
原文未给出网络置信度阈值。本次明确采用综合分数≥0.4、functional网络、不扩展外部蛋白。
STRING功能关联包含已知与预测关联，不能将所有连线解释为直接物理结合。
映射以官方9606.protein.info.v12.0的preferred_name与输入基因符号精确匹配为准。
VDR、VEGFA无唯一严格匹配；ST6GAL1成功匹配但当前阈值下为孤立节点。
这3个基因保留在49行输入节点审计表中；未替换为其他蛋白，也未用于当前PPI拓扑排名。
初始get_string_ids自动查询曾把VDR、VEGFA匹配为CYP27B1、COL18A1；该初始响应仅存于原始数据/诊断目录，未用于结果。
网络计算按无向、无权简单图进行；STRING原始综合分数和各证据通道分数保留在边表中。

图3B的算法和重复规则
计算MCC、MNC、EPC、Radiality、Stress、Degree六种拓扑指标，各取前10名。
使用Python实现，并核对已安装cytoHubba v0.1的算法定义；本次未调用Cytoscape插件界面。
MCC：包含该基因的每个极大团，累加（团大小−1）的阶乘；共59个极大团，最大团18个节点。使用整数计算并保留完整得分。
MNC：该节点开放邻域诱导子图的最大连通分量大小。
Degree：简单网络连接数。
Stress：通过该节点的最短路径数量，采用有序起终点对计数；已用逐条最短路径枚举独立核对。
Radiality按cytoHubba v0.1实现的公式计算；完整公式写入参数表。
EPC：删除阈值从0.50到0.99，以0.01递增；每个阈值30次校准，选择最大分量大小方差最大的阈值。
本次EPC选择删除阈值{s['EPC']['selected_deletion_threshold']:.2f}；随后模拟1000次，得分为每次所在分量大小的平均值（含自身）。
随机数使用PCG64，种子{s['EPC']['seed']}；用固定种子代替插件未固定的Math.random，以保证本项目可重复。
校准表、1000次分量大小和随机删边掩码均已保存；不同随机运行的插件EPC结果可与本次数值不同。
各算法按未舍入分数降序，同分时按基因符号字母顺序，严格取10个。
MNC和Degree在第10名分数处各有2个同分基因；本次取NFE2L2，TLR4位于截断边界。
同分数量、并列名次和边界规则已在完整排名及B_排名边界并列情况.csv中记录。
若保留全部边界同分基因，六组共同核心仍为：{', '.join(s['core_including_all_boundary_ties'])}。
子网仅保留原PPI网络中真实存在的边，没有将前10节点自动连接为完全图。
B的红—橙—黄色在各方法内按分数线性映射；红色分数最高，黄色最低；不同方法的原始分数尺度不同。

图3C的集合和几何
共同核心为六组严格前10名单的交集。63个可能的精确互斥分区全部保存，计数为0的分区也保留。
六圆布局沿用参考图的柔和配色和蓝色引出框；集合位置经过调整，以覆盖本数据全部非零分区。
图上只标非零分区；每个标注位置已检查其所在的圆组合与对应成员编码一致；面积不表示基因数。
数据表成员编码的顺序为MCC、MNC、EPC、Radiality、Stress、Degree。
绘图顺序为MCC、Stress、Degree、Radiality、EPC、MNC；两个编码及坐标都保存在分区表中。

如何重复
处理记录中保存fetch_sources.py、analyze_figure3.py、draw_figure3.py、build_figure3_workbook.mjs、validate_figure3.py。
优先使用已归档的STRING原始文件。运行本目录“重新生成.ps1”可重算排名、绘图、导出Excel并校验。
该脚本沿用本机已准备的Python依赖和Codex打包Node运行库；参数路径写在脚本开头。
在其他电脑运行Python分析和绘图时，安装requirements_figure3.txt列出的包，并修改脚本顶部路径即可。
Excel导出需要@oai/artifact-tool；已导出的CSV也能直接用于R、Python、Excel和Cytoscape。
如需重新联网下载原始数据，再单独运行fetch_sources.py；不要将初始含歧义的自动映射用于分析。
图3A及六个B子网另存GraphML，可导入Cytoscape；绘图坐标在节点表中。

来源
参考：所给s40643-026-01083-8论文图3（PDF第6页）。
STRING接口：https://string-db.org/help/api/
STRING固定版本：https://version-12-0.string-db.org
官方蛋白信息：https://stringdb-downloads.org/download/protein.info.v12.0/9606.protein.info.v12.0.txt.gz
cytoHubba：https://apps.cytoscape.org/apps/cytohubba
NetworkX极大团：https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.clique.find_cliques.html
六圆分区模板：https://github.com/LankyCyril/pyvenn
下载时间、URL、请求参数、SHA256及软件版本保存在原始数据来源记录和处理记录/summary.json中。
'''
(ROOT/'README_先看这里.txt').write_text(readme,encoding='utf-8-sig')
(ROOT/'requirements_figure3.txt').write_text('numpy==2.3.5\nnetworkx==3.5\nmatplotlib==3.11.2\nvenn==0.1.3\nPillow\npypdf\nopenpyxl\n',encoding='utf-8')
for name in ['fetch_sources.py','analyze_figure3.py','draw_figure3.py','build_figure3_workbook.mjs','validate_figure3.py','finalize_figure3.py']:
    shutil.copy2(WORK/name,AUDIT/name)
for name in ['setup_style.py','visual_qa.py']:
    shutil.copy2(Path(r'./local_user\.codex\skills\scipilot-figure-skill\scripts')/name,AUDIT/name)
for fname in ['图3_49基因输入.csv']:
    shutil.copy2(Path(s['input']['path']),AUDIT/fname)
ps=r'''$ErrorActionPreference = 'Stop'
$taskPython = './local_user\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$taskNode = './local_user\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$taskModules = './local_user\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
$taskScripts = Join-Path $PSScriptRoot '处理记录'
function Invoke-CheckedPython([string]$name, [string[]]$moreArgs = @()) {
    & $taskPython (Join-Path $taskScripts $name) @moreArgs
    if ($LASTEXITCODE -ne 0) { throw "Failed: $name" }
}
Invoke-CheckedPython 'analyze_figure3.py'
Invoke-CheckedPython 'draw_figure3.py' @('--export')
$taskLink = Join-Path $taskScripts 'node_modules'
if (-not (Test-Path -LiteralPath $taskLink)) {
    New-Item -ItemType Junction -Path $taskLink -Target $taskModules | Out-Null
}
& $taskNode (Join-Path $taskScripts 'build_figure3_workbook.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Failed: Excel export' }
Invoke-CheckedPython 'validate_figure3.py'
Write-Output 'All figures and tables have been regenerated from the archived STRING data.'
'''
(ROOT/'重新生成.ps1').write_text(ps,encoding='utf-8-sig')
manifest=[]
for folder in [ROOT/'图片',ROOT/'各子图数据表',ROOT/'Cytoscape可编辑网络']:
    for p in sorted(folder.iterdir()):
        if p.is_file():manifest.append({'file':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for p in [ROOT/s['pdf'],ROOT/s['workbook']]:manifest.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(AUDIT/'交付文件SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'manifest_files':len(manifest),'figures':len(names),'PDF_pages':10,'table_files':len(list((ROOT/'各子图数据表').glob('*.csv')))},ensure_ascii=True))
