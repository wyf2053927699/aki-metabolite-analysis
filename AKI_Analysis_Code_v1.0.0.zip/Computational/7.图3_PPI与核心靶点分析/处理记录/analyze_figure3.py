from pathlib import Path
import sys,csv,json,math,hashlib,collections,itertools,platform
sys.path.insert(0,r'.\local_workspace\.codex-work\figure3\python_deps')
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
import numpy as np
import networkx as nx
from venn._constants import PSEUDOVENN_PETAL_COORDS
ROOT=Path(r'.\Computational\7.图3_PPI与核心靶点分析')
RAW=ROOT/'原始数据';AUDIT=ROOT/'处理记录';TABLE=ROOT/'各子图数据表';EDIT=ROOT/'Cytoscape可编辑网络'
for p in (TABLE,EDIT):p.mkdir(exist_ok=True)
SOURCE=Path(r'.\Computational\5.gutMGene宿主基因交集_图2C\图2C_交集靶点_49个.csv')
METHODS=['MCC','MNC','EPC','Radiality','Stress','Degree']
C_ORDER=['MCC','Stress','Degree','Radiality','EPC','MNC']
C_COLORS={'MCC':'#F5B6AF','MNC':'#B8E3E9','EPC':'#A2CAC3','Radiality':'#A5B5D3','Stress':'#F3D2BB','Degree':'#ADA9C5'}
SEED=20261019
def readcsv(p,delim=','):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=delim))
def writecsv(p,rows,fields=None):
    fields=fields or list(dict.fromkeys(k for row in rows for k in row))
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    return fields
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
input_rows=readcsv(SOURCE);genes=sorted(r['Gene_symbol'] for r in input_rows);gene_info={r['Gene_symbol']:r for r in input_rows}
mapping=readcsv(RAW/'STRING_严格基因映射.tsv','\t');mp={r['queryItem']:r for r in mapping}
assert all(r['queryItem']==r['preferredName'] for r in mapping)
edge_raw=readcsv(RAW/'STRING_严格映射基因_功能关联网络_0.4.tsv','\t')
G=nx.Graph();G.add_nodes_from(sorted(mp));edges=[]
idmap={r['stringId']:r['queryItem'] for r in mapping}
for r in edge_raw:
    a,b=sorted([idmap[r['stringId_A']],idmap[r['stringId_B']]])
    assert a!=b and float(r['score'])>=.4 and r['ncbiTaxonId']=='9606'
    assert {r['preferredName_A'],r['preferredName_B']}=={a,b}
    e={'Source':a,'Target':b,'Combined_score':float(r['score']),
       'Neighborhood_score':float(r['nscore']),'Fusion_score':float(r['fscore']),
       'Cooccurrence_score':float(r['pscore']),'Coexpression_score':float(r['ascore']),
       'Experimental_score':float(r['escore']),'Database_score':float(r['dscore']),
       'Textmining_score':float(r['tscore']),'STRING_ID_A':mp[a]['stringId'],'STRING_ID_B':mp[b]['stringId']}
    assert not G.has_edge(a,b)
    G.add_edge(a,b,**e);edges.append(e)
edges.sort(key=lambda e:(e['Source'],e['Target']))
isolated=sorted(nx.isolates(G));H=G.subgraph(sorted(set(G)-set(isolated))).copy()
active=sorted(H);n=len(active);index={g:i for i,g in enumerate(active)}
idx_edges=np.array([(index[e['Source']],index[e['Target']]) for e in edges],dtype=int)
adj={g:sorted(H[g]) for g in H};components=[sorted(c) for c in nx.connected_components(H)]

# Scores follow the installed cytoHubba v0.1 definitions. The deterministic
# Python EPC uses a seeded PCG64 generator in place of unseeded Math.random.
scores={m:{} for m in METHODS}
cliques=list(nx.find_cliques(H));clique_rows=[]
for g in active:
    containing=[c for c in cliques if g in c]
    scores['MCC'][g]=sum(math.factorial(len(c)-1) for c in containing)
    scores['Degree'][g]=H.degree(g)
    scores['MNC'][g]=max((len(c) for c in nx.connected_components(H.subgraph(adj[g]))),default=0)
for i,c in enumerate(sorted(cliques,key=lambda c:(-len(c),sorted(c))),1):
    clique_rows.append({'Clique_ID':i,'Size':len(c),'MCC_contribution':math.factorial(len(c)-1),'Genes':' | '.join(sorted(c))})
stress={g:0 for g in active};distances={};sum_dist={}
for s in active:
    pred={g:[] for g in active};sigma={g:0 for g in active};dist={g:-1 for g in active};sigma[s]=1;dist[s]=0
    queue=collections.deque([s]);stack=[]
    while queue:
        v=queue.popleft();stack.append(v)
        for w in adj[v]:
            if dist[w]<0:dist[w]=dist[v]+1;queue.append(w)
            if dist[w]==dist[v]+1:sigma[w]+=sigma[v];pred[w].append(v)
    tau={g:0 for g in active}
    while stack:
        w=stack.pop()
        for v in pred[w]:tau[v]+=tau[w]+1
        if w!=s:stress[w]+=sigma[w]*tau[w]
    distances[s]=dist;sum_dist[s]=sum(v for v in dist.values() if v>0)
scores['Stress']=stress
for comp in components:
    diameter=max(distances[s][t] for s in comp for t in comp)
    rad_weight=(len(comp)/n)/(len(comp)-1)
    for g in comp:
        scores['Radiality'][g]=rad_weight*(len(comp)*(diameter+1)-sum_dist[g])

# EPC adaptive deletion threshold: 0.50..0.99; 30 reduced networks per
# threshold; maximize variance of largest-component size, then 1000 runs.
rng=np.random.Generator(np.random.PCG64(SEED))
def component_sizes(mask):
    parent=list(range(n));size=[1]*n
    def find(a):
        while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
        return a
    for u,v in idx_edges[mask]:
        a,b=find(int(u)),find(int(v))
        if a==b:continue
        if size[a]<size[b]:a,b=b,a
        parent[b]=a;size[a]+=size[b]
    return np.array([size[find(i)] for i in range(n)],dtype=np.int16)
calibration=[];best_ss=-1;selected_threshold=.97;calibration_masks=[]
for threshold_int in range(50,100):
    t=threshold_int/100
    masks=rng.random((30,len(edges)))>t;calibration_masks.append(masks)
    maxima=np.array([int(component_sizes(mask).max()) for mask in masks])
    ss=float(np.sum((maxima-maxima.mean())**2))
    calibration.append({'Deletion_threshold':t,'Retention_probability':1-t,'Calibration_runs':30,
                        'Largest_component_mean':float(maxima.mean()),'Largest_component_variance':ss/30,
                        'Largest_component_squared_deviations_sum':ss})
    if ss>best_ss:best_ss=ss;selected_threshold=t
simulation_masks=rng.random((1000,len(edges)))>selected_threshold
simulations=np.stack([component_sizes(mask) for mask in simulation_masks])
for g in active:scores['EPC'][g]=int(simulations[:,index[g]].sum())/1000
np.savez_compressed(AUDIT/'EPC_random_masks.npz',calibration=np.stack(calibration_masks),simulation=simulation_masks,
                    gene_order=np.array(active),edge_order=idx_edges,threshold=selected_threshold,seed=SEED)
writecsv(TABLE/'B_EPC_阈值校准.csv',calibration)
writecsv(TABLE/'B_EPC_1000次模拟分量大小.csv',[{'Iteration':i+1,**{g:int(row[index[g]]) for g in active}} for i,row in enumerate(simulations)])
writecsv(TABLE/'B_MCC_极大团及贡献.csv',clique_rows)

# Validate consequential algorithms independently before choosing core genes.
stress_independent={g:0 for g in active}
for a,b in itertools.combinations(active,2):
    if not nx.has_path(H,a,b):continue
    for path in nx.all_shortest_paths(H,a,b):
        for g in path[1:-1]:stress_independent[g]+=2
assert stress_independent==scores['Stress']
assert all(distances[s][g]==nx.shortest_path_length(H,s,g) for s in active for g in active if nx.has_path(H,s,g))

ranked={};all_ranks=[];top10_nodes=[];top10_edges=[];boundary=[]
for method in METHODS:
    ordered=sorted(active,key=lambda g:(-scores[method][g],g));cut=scores[method][ordered[9]]
    ranked[method]=ordered[:10]
    distinct=sorted(set(scores[method].values()),reverse=True)
    counts=collections.Counter(scores[method].values())
    for position,g in enumerate(ordered,1):
        score=scores[method][g]
        row={'Algorithm':method,'Order':position,'Gene_symbol':g,'Score':score,'Score_display_5dp':round(score,5),
             'Competition_rank':1+sum(v>score for v in scores[method].values()),'Tie_group_size':counts[score],
             'Selected_exact_top10':position<=10,'At_top10_boundary_score':score==cut,
             'PPI_degree':H.degree(g),'STRING_ID':mp[g]['stringId'],'Gene_name':gene_info[g]['Gene_name']}
        all_ranks.append(row)
        if position<=10:
            angle=math.pi/2-(position-1)*2*math.pi/10
            # Consistent position records allow exact reconstruction.
            top10_nodes.append({**row,'x':math.cos(angle),'y':math.sin(angle)})
    for e in edges:
        if e['Source'] in ranked[method] and e['Target'] in ranked[method]:top10_edges.append({'Algorithm':method,**e})
    boundary.append({'Algorithm':method,'Cutoff_score':cut,'Strictly_above_cutoff':sum(v>cut for v in scores[method].values()),
                     'Tied_at_cutoff':counts[cut],'Inclusive_top10_count':sum(v>=cut for v in scores[method].values()),
                     'Rule':'Descending unrounded score, then alphabetical gene symbol; exactly ten genes'})

sets={m:set(ranked[m]) for m in METHODS};core=sorted(set.intersection(*sets.values()));union=sorted(set.union(*sets.values()))
members=[]
for g in genes:
    flags={m:g in sets[m] for m in METHODS}
    members.append({'Gene_symbol':g,**flags,'Methods_in_top10':sum(flags.values()),'All_six':all(flags.values()),
                    'Gene_name':gene_info[g]['Gene_name']})
region_counts=[];geometry=[]
for i,m in enumerate(C_ORDER):
    a=(2-i)*math.pi/3
    geometry.append({'Algorithm':m,'Plot_order':i+1,'Center_x':.5+.2*math.cos(a),'Center_y':.5+.2*math.sin(a),
                     'Radius':.3,'Color':C_COLORS[m],'Alpha':.43,'Label_x':.5+.57*math.cos(a),'Label_y':.5+.57*math.sin(a)})
for mask_int in range(1,64):
    mask=f'{mask_int:06b}';flags={m:mask[i]=='1' for i,m in enumerate(METHODS)}
    matching=[g for g in union if all((g in sets[m])==flags[m] for m in METHODS)]
    plot_mask=''.join('1' if flags[m] else '0' for m in C_ORDER)
    pos=PSEUDOVENN_PETAL_COORDS[6].get(plot_mask)
    assert not matching or pos is not None,(plot_mask,matching)
    if matching:
        actual=''.join('1' if math.dist(pos,(r['Center_x'],r['Center_y']))<r['Radius'] else '0' for r in geometry)
        assert actual==plot_mask,(plot_mask,actual)
    region_counts.append({'Membership_mask':mask,**flags,'Exclusive_gene_count':len(matching),'Genes':' | '.join(matching),
                          'Plot_membership_mask':plot_mask,'Label_x':pos[0] if pos else None,'Label_y':pos[1] if pos else None})
core_rows=[]
for g in core:
    core_rows.append({'Gene_symbol':g,'Gene_name':gene_info[g]['Gene_name'],'STRING_ID':mp[g]['stringId'],
                      'PPI_degree':H.degree(g),**{m+'_score':scores[m][g] for m in METHODS},
                      **{m+'_order':next(r['Order'] for r in all_ranks if r['Algorithm']==m and r['Gene_symbol']==g) for m in METHODS},
                      'gutMGene_Gene_IDs':gene_info[g]['gutMGene_Gene_IDs'],'Disease_database_source':gene_info[g]['Disease_database_source']})

nodes=[]
for g in genes:
    mapped=g in mp;included=g in H
    i=active.index(g) if included else None
    if included:
        ring=i%2;k=i//2;ring_count=(n+1-ring)//2
        angle=math.pi/2-(k+(0 if ring==0 else .5))*2*math.pi/ring_count
        rad=1.0 if ring==0 else .73;x,y=rad*math.cos(angle),rad*math.sin(angle)
    else:x=y=None
    nodes.append({'Gene_symbol':g,'Gene_name':gene_info[g]['Gene_name'],'STRING_ID':mp[g]['stringId'] if mapped else '',
                  'Mapping_status':'Exact preferred_name match' if mapped else 'No unique exact v12.0 match',
                  'PPI_status':'Included in PPI' if included else 'Mapped isolate at score >= 0.4' if mapped else 'Unmapped',
                  'Included_in_PPI':included,'PPI_degree':H.degree(g) if included else 0 if mapped else None,
                  'x':x,'y':y,'gutMGene_Gene_IDs':gene_info[g]['gutMGene_Gene_IDs'],
                  'STP_UniProt_IDs':gene_info[g]['STP_UniProt_IDs'],
                  'Disease_database_source':gene_info[g]['Disease_database_source']})

writecsv(TABLE/'A_PPI节点_含全部49个输入.csv',nodes);writecsv(TABLE/'A_PPI连线.csv',edges)
writecsv(TABLE/'B_六算法全部排名.csv',all_ranks);writecsv(TABLE/'B_六算法前10节点.csv',top10_nodes)
writecsv(TABLE/'B_六算法子网连线.csv',top10_edges);writecsv(TABLE/'B_排名边界并列情况.csv',boundary)
writecsv(TABLE/'C_六算法集合归属_全部49基因.csv',members)
writecsv(TABLE/'C_63个精确互斥分区.csv',region_counts);writecsv(TABLE/'C_共同核心靶点.csv',core_rows)
writecsv(TABLE/'C_六集合几何参数.csv',geometry)
for method in METHODS:
    writecsv(TABLE/f'B_{method}_前10节点.csv',[r for r in top10_nodes if r['Algorithm']==method])
    writecsv(TABLE/f'B_{method}_子网连线.csv',[r for r in top10_edges if r['Algorithm']==method])
(TABLE/'C_共同核心基因.txt').write_text('\n'.join(core)+'\n',encoding='utf-8')

graph=nx.Graph(name='Figure3A_STRING12_AKI');
for r in nodes:
    if r['Included_in_PPI']:graph.add_node(r['Gene_symbol'],**{k:v for k,v in r.items() if v is not None})
for r in edges:graph.add_edge(r['Source'],r['Target'],**r)
nx.write_graphml(graph,EDIT/'图3A_PPI网络.graphml')
for method in METHODS:
    sub=graph.subgraph(ranked[method]).copy()
    for row in top10_nodes:
        if row['Algorithm']==method:sub.nodes[row['Gene_symbol']].update(row)
    nx.write_graphml(sub,EDIT/f'图3B_{method}_前10子网.graphml')

incl_sets={m:{g for g in active if scores[m][g]>=next(b['Cutoff_score'] for b in boundary if b['Algorithm']==m)} for m in METHODS}
summary={'input':{'path':str(SOURCE),'sha256':sha(SOURCE)},'reference_paper':str(Path(r'.\local_workspace\s40643-026-01083-8_translated.pdf.pdf')),
         'STRING_version':'12.0','species':9606,'network_type':'functional','required_score':400,'score_scale':'0..1 in returned tables',
         'extra_proteins':0,'input_genes':49,'strictly_mapped':len(mapping),'unmapped':sorted(set(genes)-set(mp)),
         'mapped_isolates':isolated,'PPI_nodes':n,'PPI_edges':len(edges),'connected_component_sizes':[len(c) for c in components],
         'methods':METHODS,'top_n':10,'core_genes':core,'core_count':len(core),'top10_union_count':len(union),
         'core_including_all_boundary_ties':sorted(set.intersection(*incl_sets.values())),
         'ranking_rule':'Unrounded score descending, then gene symbol alphabetical; exactly ten per method',
         'algorithm_implementation':'Python implementation of definitions checked against installed cytoHubba v0.1; not a Cytoscape GUI run',
         'cytoHubba_binary_sha256':sha(Path(r'./local_user\CytoscapeConfiguration\3\apps\installed\cytoHubba-v0.1.jar')),
         'EPC':{'seed':SEED,'generator':'numpy.random.PCG64','threshold_grid':'.50 to .99 in .01 increments',
                'calibration_runs_per_threshold':30,'calibration_rule':'Maximize variance of largest-component size; retain first maximum',
                'selected_deletion_threshold':selected_threshold,'retention_probability':1-selected_threshold,'simulation_runs':1000,
                'score':'Average size of the reduced-network component containing the node, including itself',
                'difference_from_GUI':'Seeded PCG64 replaces unseeded Java Math.random; exact random scores can differ'},
         'Radiality_formula':'For component C: w=|C|/[N*(|C|-1)], score=w*(|C|*(diam(C)+1)-sum shortest path distances). Matches cytoHubba v0.1 implementation.',
         'Stress_convention':'Ordered source-target pairs; no normalization; same ranking as dividing undirected scores by two',
         'MCC_formula':'Sum (maximal clique size - 1)! over cliques containing the gene',
         'MNC_formula':'Size of largest connected component of the induced open-neighborhood graph',
         'edge_weights_used_for_topology':False,'clique_count':len(cliques),'maximum_clique_size':max(map(len,cliques)),
         'independent_checks':{'Stress_all_shortest_paths':True,'BFS_distances':True},
         'C_plot_order':C_ORDER,'C_geometry':'Six-circle Euler layout; all observed nonzero exact intersections are represented; omitted regions contain zero genes; areas are not proportional',
         'software':{'python':platform.python_version(),'networkx':nx.__version__,'numpy':np.__version__},
         'workbook':'图3_全部子图数据与参数.xlsx','pdf':'图3_主图与全部子图.pdf'}
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(AUDIT/'figure3_data.json').write_text(json.dumps({'nodes':nodes,'edges':edges,'ranking':all_ranks,'top10_nodes':top10_nodes,
    'top10_edges':top10_edges,'membership':members,'regions':region_counts,'core':core_rows,'boundary':boundary,'geometry':geometry},ensure_ascii=False,indent=2),encoding='utf-8')
# Workbook definitions keep each network table flat, with one row per entity.
def spec(key,name,title,rows,labels,notes,widths=None):
    fields=list(labels)
    return {'key':key,'name':name,'title':title,'fields':fields,'labels':list(labels.values()),
            'rows':[[r.get(f,None) for f in fields] for r in rows],'notes':notes,
            'widths':widths or [max(20,min(48,len(str(v))+9)) for v in labels.values()]}
specs=[]
specs.append(spec('nodes','A_49个输入节点','图3A PPI节点与映射状态',nodes,
    {'Gene_symbol':'输入基因','PPI_status':'网络处理状态','PPI_degree':'PPI连接数','Included_in_PPI':'纳入网络',
     'STRING_ID':'STRING蛋白编号','Mapping_status':'映射状态','Gene_name':'基因名称','x':'绘图横坐标','y':'绘图纵坐标',
     'gutMGene_Gene_IDs':'gutMGene Gene ID','STP_UniProt_IDs':'STP UniProt编号','Disease_database_source':'疾病数据库来源'},
    ['49个输入基因；47个严格映射；46个有边节点；431条关联边。',
     'VDR、VEGFA未严格映射；ST6GAL1在当前阈值下无连线。均保留原始输入，不替换为其他蛋白。',
     '来源：STRING v12.0 human protein.info；输入为前步图2C的49个交集基因。'],[20,48,21,20,37,48,60,25,25,30,35,28]))
edge_labels={'Source':'基因A','Target':'基因B','Combined_score':'综合关联分数','Experimental_score':'实验证据分数',
             'Database_score':'数据库证据分数','Textmining_score':'文本挖掘分数','Coexpression_score':'共表达分数',
             'Neighborhood_score':'基因邻域分数','Fusion_score':'基因融合分数','Cooccurrence_score':'共现分数',
             'STRING_ID_A':'STRING编号A','STRING_ID_B':'STRING编号B'}
specs.append(spec('edges','A_431条关联边','图3A PPI关联边',edges,edge_labels,
    ['STRING v12.0；human=9606；functional网络；综合分数≥0.4；不增加外部蛋白。',
     '拓扑评分按无向、无权简单网络计算；原始STRING分数完整保留。',
     '官方接口：https://version-12-0.string-db.org/api/tsv/network']))
rank_labels={'Algorithm':'算法','Order':'确定性序号','Gene_symbol':'基因','Score':'原始得分','Competition_rank':'并列名次',
             'Tie_group_size':'同分基因数','Selected_exact_top10':'选入前10','At_top10_boundary_score':'位于第10名分数边界',
             'PPI_degree':'PPI连接数','Score_display_5dp':'显示得分（5位小数）','STRING_ID':'STRING编号','Gene_name':'基因名称'}
specs.append(spec('ranking','B_六算法完整排名','图3B 六算法完整得分与排名',all_ranks,rank_labels,
    ['按原始得分降序排列；同分时按基因符号字母顺序；每种方法严格取10个。',
     '并列名次、同分基因数和第10名边界均列出，避免隐藏截断规则。',
     '算法依据：cytoHubba v0.1；Python实现；EPC固定种子20261019。']))
top_labels={**rank_labels,'x':'子图横坐标','y':'子图纵坐标'}
specs.append(spec('top10','B_前10节点','图3B 各算法前10节点',top10_nodes,top_labels,
    ['六种算法各10个节点，共60条算法—基因记录。',
     '原始坐标、分数、并列信息均保留；每种算法另存独立CSV。','子网连线见B_子网连线；不得将前10节点自动补成完全图。']))
specs.append(spec('topedges','B_子网连线','图3B 各前10节点的诱导子网',top10_edges,{'Algorithm':'算法',**edge_labels},
    ['每一行对应一条原始STRING关联边；仅保留两端均在该方法前10名的边。',
     '同一条边可出现在多个算法子网；算法字段区分来源。','原始分数用于追溯；此图不使用分数加权排名。']))
specs.append(spec('membership','C_六组归属','图3C 六算法集合归属',members,
    {'Gene_symbol':'基因',**{m:m for m in METHODS},'Methods_in_top10':'进入前10的方法数','All_six':'六组共同核心','Gene_name':'基因名称'},
    [f'六组前10名的并集为{len(union)}个基因；共同交集为{len(core)}个。',
     'TRUE表示进入该算法的严格前10；FALSE表示未进入。未映射、孤立基因也保留在49行输入中。','对应集合顺序：'+'、'.join(METHODS)]))
specs.append(spec('regions','C_63个互斥分区','图3C 六集合的精确互斥分区',region_counts,
    {'Membership_mask':'六位成员编码',**{m:m for m in METHODS},'Exclusive_gene_count':'该精确分区基因数','Genes':'基因列表',
     'Plot_membership_mask':'绘图成员编码','Label_x':'标注横坐标','Label_y':'标注纵坐标'},
    ['编码按MCC、MNC、EPC、Radiality、Stress、Degree的顺序；1为属于，0为不属于。',
     '全部63个非空成员组合均列出，计数为0也保留；分区基因数相加等于六组并集大小。','六圆布局覆盖本数据全部非零分区；未标注的分区计数为0；面积不表示基因数。']))
specs.append(spec('geometry','C_集合几何参数','图3C 六集合的绘图参数',geometry,
    {'Algorithm':'算法','Plot_order':'绘图顺序','Center_x':'圆心横坐标','Center_y':'圆心纵坐标','Radius':'半径',
     'Color':'填充颜色','Alpha':'透明度','Label_x':'算法名横坐标','Label_y':'算法名纵坐标'},
    ['绘图采用MCC、Stress、Degree、Radiality、EPC、MNC顺序，使全部非零互斥分区都能显示。',
     '集合颜色沿用参考图的粉、青、绿、蓝、橙、紫色。','精确分区数值见C_63个互斥分区；集合成员见C_六组归属。']))
specs.append(spec('core','C_共同核心靶点','图3C 六算法共同核心靶点',core_rows,
    {'Gene_symbol':'基因','Gene_name':'基因名称','PPI_degree':'PPI连接数',**{m+'_score':m+'得分' for m in METHODS},
     **{m+'_order':m+'确定性序号' for m in METHODS},'STRING_ID':'STRING编号','gutMGene_Gene_IDs':'gutMGene Gene ID','Disease_database_source':'疾病数据库来源'},
    [f'六组严格前10名共同得到{len(core)}个候选核心靶点。',
     '该名单由本项目数据计算；不沿用论文中的7个基因。','所属网络及排名条件见参数表。']))
param_rows=[{'Parameter':k,'Value':json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v} for k,v in summary.items()]
specs.append(spec('parameters','参数与来源','图3复现参数与来源',param_rows,{'Parameter':'参数','Value':'取值或说明'},
    ['STRING文档：https://string-db.org/help/api/；cytoHubba：https://apps.cytoscape.org/apps/cytohubba',
     '复现时优先读取已归档的官方TSV；重新联网下载可能受数据库服务更新影响。','输入文件哈希、软件版本、随机种子与并列处理规则均在本表列出。'],[42,145]))
(AUDIT/'workbook_payload.json').write_text(json.dumps({'summary':summary,'sheets':specs},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'input':len(genes),'mapped':len(mp),'isolates':isolated,'nodes':n,'edges':len(edges),
                  'core':core,'core_count':len(core),'EPC_threshold':selected_threshold,
                  'cliques':len(cliques),'max_clique':max(map(len,cliques)),'cutoff_ties':boundary},ensure_ascii=True))
