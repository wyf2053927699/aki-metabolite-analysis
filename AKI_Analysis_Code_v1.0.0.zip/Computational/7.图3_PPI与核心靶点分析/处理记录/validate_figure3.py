from pathlib import Path
import sys,json,csv,gzip,io,math,hashlib,collections,itertools,xml.etree.ElementTree as ET
sys.path.insert(0,r'.\local_workspace\.codex-work\figure3\python_deps')
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
import numpy as np
import networkx as nx
from PIL import Image
from pypdf import PdfReader
from openpyxl import load_workbook
ROOT=Path(r'.\Computational\7.图3_PPI与核心靶点分析');AUDIT=ROOT/'处理记录';RAW=ROOT/'原始数据'
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'));d=json.loads((AUDIT/'figure3_data.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'));checks=[]
def check(label,ok,detail=None):checks.append({'check':label,'passed':bool(ok),'detail':detail})
def csvread(p,sep=','):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=sep))
def same(a,b):
    if a is None and b in ('',None):return True
    if isinstance(a,str) and isinstance(b,str):return a.replace('\r\n','\n')==b.replace('\r\n','\n')
    if isinstance(a,(float,int)) and isinstance(b,(float,int)) and not isinstance(a,bool) and not isinstance(b,bool):
        return a==b if isinstance(a,int) and isinstance(b,int) else math.isclose(a,b,rel_tol=1e-13,abs_tol=1e-12)
    return a==b
source=Path(s['input']['path']);source_rows=csvread(source);gene_set={r['Gene_symbol'] for r in source_rows}
check('Input hash and 49 unique symbols preserved',hashlib.sha256(source.read_bytes()).hexdigest()==s['input']['sha256'] and len(gene_set)==49)
check('All 49 input genes retained in node audit',gene_set=={r['Gene_symbol'] for r in d['nodes']} and len(d['nodes'])==49)
infos=list(csv.DictReader(io.StringIO(gzip.decompress((RAW/'9606.protein.info.v12.0.txt.gz').read_bytes()).decode()),delimiter='\t'))
lookup={r['#string_protein_id']:r for r in infos};mapping=csvread(RAW/'STRING_严格基因映射.tsv','\t')
check('All 47 retained mappings exactly match protein.info',len(mapping)==47 and all(lookup[r['stringId']]['preferred_name']==r['queryItem']==r['preferredName'] for r in mapping))
check('Unmapped genes explicitly retained',sorted(r['Gene_symbol'] for r in d['nodes'] if r['PPI_status']=='Unmapped')==['VDR','VEGFA'])
check('Isolated ST6GAL1 explicitly retained',s['mapped_isolates']==['ST6GAL1'] and next(r for r in d['nodes'] if r['Gene_symbol']=='ST6GAL1')['PPI_degree']==0)
active={r['Gene_symbol'] for r in d['nodes'] if r['Included_in_PPI']};G=nx.Graph();G.add_nodes_from(active)
G.add_edges_from((e['Source'],e['Target']) for e in d['edges'])
check('46 active nodes and 431 unique undirected edges',len(active)==46 and len(d['edges'])==G.number_of_edges()==431)
check('Only original input proteins in PPI',active<=gene_set and all(e['Source'] in active and e['Target'] in active for e in d['edges']))
check('No wrong VDR/VEGFA replacement proteins',not {'CYP27B1','COL18A1'}&active)
check('No self loops or isolates in active PPI',nx.number_of_selfloops(G)==0 and not list(nx.isolates(G)))
check('All edges pass the fixed confidence threshold',all(.4<=e['Combined_score']<=1 for e in d['edges']))
check('Node degrees reconcile to edge table',all(r['PPI_degree']==G.degree(r['Gene_symbol']) for r in d['nodes'] if r['Included_in_PPI']))
check('Graph has a single connected component',nx.is_connected(G))
for p in RAW.glob('*.provenance.json'):
    meta=json.loads(p.read_text(encoding='utf-8'));datafile=Path(str(p).removesuffix('.provenance.json'))
    check('Source snapshot hash: '+datafile.name,hashlib.sha256(datafile.read_bytes()).hexdigest()==meta['sha256'])

method_sets={};sc={m:{} for m in s['methods']}
for method in s['methods']:
    ranks=[r for r in d['ranking'] if r['Algorithm']==method];top=[r for r in d['top10_nodes'] if r['Algorithm']==method]
    sc[method]={r['Gene_symbol']:r['Score'] for r in ranks};method_sets[method]={r['Gene_symbol'] for r in top}
    expected=sorted(active,key=lambda g:(-sc[method][g],g))
    check(method+': 46 complete, correctly sorted ranks',len(ranks)==46 and [r['Gene_symbol'] for r in ranks]==expected)
    check(method+': exactly ten unique selected genes',len(top)==len(method_sets[method])==10 and [r['Gene_symbol'] for r in top]==expected[:10])
    expected_edges={frozenset((a,b)) for a,b in G.edges if a in method_sets[method] and b in method_sets[method]}
    actual_edges={frozenset((e['Source'],e['Target'])) for e in d['top10_edges'] if e['Algorithm']==method}
    check(method+': induced edges copied without additions',actual_edges==expected_edges)
cliques=list(nx.find_cliques(G))
check('MCC reconciles to maximal-clique contributions',all(sc['MCC'][g]==sum(math.factorial(len(c)-1) for c in cliques if g in c) for g in G))
check('MNC reconciles to open-neighborhood components',all(sc['MNC'][g]==max((len(c) for c in nx.connected_components(G.subgraph(G[g]))),default=0) for g in G))
check('Degree scores equal graph degrees',all(sc['Degree'][g]==G.degree(g) for g in G))
stress={g:0 for g in G}
for a,b in itertools.combinations(sorted(G),2):
    for path in nx.all_shortest_paths(G,a,b):
        for g in path[1:-1]:stress[g]+=2
check('Stress agrees with independent shortest-path enumeration',stress==sc['Stress'])
dist=dict(nx.all_pairs_shortest_path_length(G));diameter=nx.diameter(G)
check('Radiality agrees with cytoHubba-v0.1 formula',all(math.isclose(sc['Radiality'][g],(len(G)*(diameter+1)-sum(dist[g].values()))/(len(G)-1),abs_tol=1e-12) for g in G))
saved=np.load(AUDIT/'EPC_random_masks.npz');rng=np.random.Generator(np.random.PCG64(s['EPC']['seed']))
expected_cal=np.stack([rng.random((30,len(d['edges'])))>(t/100) for t in range(50,100)])
expected_sim=rng.random((1000,len(d['edges'])))>s['EPC']['selected_deletion_threshold']
check('EPC calibration and simulation masks exactly reproduce from seed',np.array_equal(saved['calibration'],expected_cal) and np.array_equal(saved['simulation'],expected_sim))
simulation=csvread(ROOT/'各子图数据表'/'B_EPC_1000次模拟分量大小.csv')
check('EPC scores match archived 1000-run component sizes',len(simulation)==1000 and all(sc['EPC'][g]==sum(int(r[g]) for r in simulation)/1000 for g in G))

intersection=set.intersection(*method_sets.values());union=set.union(*method_sets.values())
check('Core genes exactly equal all-six intersection',intersection==set(s['core_genes'])=={r['Gene_symbol'] for r in d['core']} and len(intersection)==6)
check('Every 49-row membership flag agrees with selected sets',all(r[m]==(r['Gene_symbol'] in method_sets[m]) for r in d['membership'] for m in s['methods']))
check('All 63 exclusive combinations are represented in data',len(d['regions'])==63 and {r['Membership_mask'] for r in d['regions']}=={f'{i:06b}' for i in range(1,64)})
regions_genes=[];counts_ok=True;geo_ok=True
for r in d['regions']:
    expected=sorted(g for g in union if all((g in method_sets[m])==r[m] for m in s['methods']))
    counts_ok &= r['Exclusive_gene_count']==len(expected) and r['Genes']==' | '.join(expected)
    regions_genes.extend(expected)
    if expected:
        pos=(r['Label_x'],r['Label_y'])
        actual=''.join('1' if math.dist(pos,(v['Center_x'],v['Center_y']))<v['Radius'] else '0' for v in d['geometry'])
        geo_ok &= actual==r['Plot_membership_mask']
check('Every exclusive-region gene list and count reconciles',counts_ok)
check('Exclusive regions partition the 15-gene union without duplicates',set(regions_genes)==union and len(regions_genes)==len(set(regions_genes))==15)
check('All nonzero plotted counts lie in the correct circle intersections',geo_ok)
check('All network exchange files parse and retain counts',len(list((ROOT/'Cytoscape可编辑网络').glob('*.graphml')))==7 and
      nx.read_graphml(ROOT/'Cytoscape可编辑网络'/'图3A_PPI网络.graphml').number_of_edges()==431)

wb=load_workbook(ROOT/s['workbook'],data_only=True);wf=load_workbook(ROOT/s['workbook'],data_only=False)
check('Workbook has exactly the ten intended sheets',wb.sheetnames==[p['name'] for p in payload['sheets']])
for spec in payload['sheets']:
    sh=wb[spec['name']];bad=[]
    for i,row in enumerate(spec['rows'],8):
        for j,val in enumerate(row,1):
            if not same(sh.cell(i,j).value,val):bad.append([i,j,sh.cell(i,j).value,val])
    check(spec['name']+': all data cells round-trip correctly',not bad,bad[:3])
    check(spec['name']+': row count and count formula reconcile',sh.max_row==len(spec['rows'])+7 and sh['B6'].value==len(spec['rows']) and wf[spec['name']]['B6'].data_type=='f')
    check(spec['name']+': table filter and frozen ID/header preserved',len(sh.tables)==1 and next(iter(sh.tables.values())).autoFilter is not None and sh.freeze_panes=='B8')
check('No Excel cached formula errors',not[(sh.title,c.coordinate,c.value) for sh in wb for row in sh for c in row if c.data_type=='e'])

audit=json.loads((AUDIT/'figure_audit.json').read_text(encoding='utf-8'))
check('Ten graphic variants exported with no label collisions',len(audit['figures'])==10 and all(not x['label_overlap_pairs'] and not any(a[0]=='FAIL' for a in x['layout_issues']) for x in audit['figures']))
for f in audit['figures']:
    image=Image.open(ROOT/'图片'/(f['name']+'.png'))
    check(f['name']+': 600-dpi dimensions correct',all(abs(v-600)<.1 for v in image.info.get('dpi',(0,0))) and
          all(abs(px/600-inch)<.003 for px,inch in zip(image.size,f['size_inches'])))
    svg=ET.parse(ROOT/'图片'/(f['name']+'.svg')).getroot()
    textvals=[''.join(t.itertext()) for t in svg.iter() if t.tag.endswith('}text')]
    if f['scope']=='A':expected=active
    elif f['scope'].startswith('B ') and f['scope'][2:] in s['methods']:expected=method_sets[f['scope'][2:]]
    elif f['scope']=='C':expected=set(s['core_genes'])
    else:expected=set(s['core_genes'])
    check(f['name']+': required labels remain editable SVG text',expected<=set(textvals))

reader=PdfReader(ROOT/s['pdf']);font_report=[]
check('PDF contains ten pages in documented order',len(reader.pages)==10)
for i,page in enumerate(reader.pages):
    actual=(float(page.mediabox.width)/72,float(page.mediabox.height)/72)
    expected=audit['figures'][i]['size_inches']
    check('PDF page '+str(i+1)+': dimensions match',all(abs(a-b)<.001 for a,b in zip(actual,expected)))
    for key,obj in page['/Resources'].get('/Font',{}).get_object().items():
        font=obj.get_object();desc=[f.get_object() for f in font.get('/DescendantFonts',[])] or [font]
        for ff in desc:
            fd=ff.get('/FontDescriptor');fd=fd.get_object() if fd else {}
            font_report.append({'page':i+1,'font':str(ff.get('/BaseFont')),'embedded':any(k in fd for k in ['/FontFile','/FontFile2','/FontFile3'])})
check('All PDF fonts embedded',bool(font_report) and all(f['embedded'] for f in font_report))
(AUDIT/'PDF字体检查.json').write_text(json.dumps(font_report,ensure_ascii=False,indent=2),encoding='utf-8')
report={'total':len(checks),'passed':sum(c['passed'] for c in checks),'failed':[c for c in checks if not c['passed']],'checks':checks}
(AUDIT/'最终校验报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['total','passed','failed']},ensure_ascii=True))
assert not report['failed'],'See 最终校验报告.json'
