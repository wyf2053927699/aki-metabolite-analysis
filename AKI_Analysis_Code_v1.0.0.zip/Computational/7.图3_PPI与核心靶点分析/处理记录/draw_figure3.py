from pathlib import Path
import sys,json,math,argparse,itertools
sys.path.insert(0,r'.\local_workspace\.codex-work\figure3\python_deps')
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize,to_hex
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout

ROOT=Path(r'.\Computational\7.图3_PPI与核心靶点分析')
AUDIT=ROOT/'处理记录';FIG=ROOT/'图片'
FIG.mkdir(exist_ok=True)
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
d=json.loads((AUDIT/'figure3_data.json').read_text(encoding='utf-8'))
parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');args=parser.parse_args()
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                     'savefig.facecolor':'white','text.color':'black'})
nodes={r['Gene_symbol']:r for r in d['nodes'] if r['Included_in_PPI']}
ranked={m:[r for r in d['top10_nodes'] if r['Algorithm']==m] for m in s['methods']}
method_edges={m:[r for r in d['top10_edges'] if r['Algorithm']==m] for m in s['methods']}
colors={};qa=[];figures=[]

def text(ax,*args,**kwargs):
    t=ax.text(*args,**kwargs);t.set_gid('content-label');return t

def draw_a(ax,small=False):
    ax.set(xlim=(-1.23,1.23),ylim=(-1.26,1.18),aspect='equal');ax.axis('off')
    xy={g:(r['x'],r['y']) for g,r in nodes.items()}
    segments=[[xy[r['Source']],xy[r['Target']]] for r in d['edges']]
    ax.add_collection(LineCollection(segments,colors='#777777',linewidths=.38 if not small else .30,alpha=.25,zorder=1))
    for g,(x,y) in xy.items():
        ax.add_patch(Circle((x,y),.089,facecolor='#F4ACAD',edgecolor='white',linewidth=.5,zorder=3))
        text(ax,x,y,g,ha='center',va='center',fontsize=9.0 if not small else 7.4,zorder=4)
    text(ax,0,-1.20,f"{s['PPI_nodes']} proteins, {s['PPI_edges']} associations",ha='center',va='center',fontsize=10 if not small else 9)

def draw_b(ax,method,small=False):
    ax.set(xlim=(-1.40,1.40),ylim=(-1.35,1.35),aspect='equal');ax.axis('off')
    rows=ranked[method];xy={r['Gene_symbol']:(r['x'],r['y']) for r in rows}
    lo=min(r['Score'] for r in rows);hi=max(r['Score'] for r in rows)
    norm=Normalize(lo,hi if hi>lo else lo+1);cmap=plt.colormaps['autumn_r']
    ax.add_collection(LineCollection([[xy[e['Source']],xy[e['Target']]] for e in method_edges[method]],
        colors='#777777',linewidths=.65,alpha=.7,zorder=1))
    for r in rows:
        x,y=xy[r['Gene_symbol']];color=to_hex(cmap(norm(r['Score'])));colors[(method,r['Gene_symbol'])]=color
        ax.add_patch(Rectangle((x-.225,y-.12),.45,.24,facecolor=color,edgecolor='white',linewidth=.7,zorder=3))
        text(ax,x,y,r['Gene_symbol'],ha='center',va='center',fontsize=8.8 if not small else 7.8,zorder=4)
    text(ax,0,0,method,ha='center',va='center',fontsize=16 if not small else 14,fontfamily='Times New Roman',
         bbox={'facecolor':'white','edgecolor':'none','alpha':.94,'pad':2},zorder=6)

def draw_c(ax,small=False):
    ax.set(xlim=(-.18,1.74),ylim=(-.14,1.13),aspect='equal');ax.axis('off')
    for r in d['geometry']:
        ax.add_patch(Circle((r['Center_x'],r['Center_y']),r['Radius'],facecolor=r['Color'],
                            edgecolor='none',alpha=r['Alpha'],zorder=1))
        text(ax,r['Label_x'],r['Label_y'],r['Algorithm'],ha='center',va='center',fontsize=10.5 if not small else 9.5)
    for r in d['regions']:
        if not r['Exclusive_gene_count']:continue
        x,y=r['Label_x'],r['Label_y']
        if r['Membership_mask']=='111111':
            ax.add_patch(Circle((x,y),.047,facecolor='none',edgecolor='#458BB0',linewidth=1.3,zorder=4))
        text(ax,x,y,str(r['Exclusive_gene_count']),ha='center',va='center',fontsize=11 if not small else 10,zorder=5)
    # Blue callout follows the reference; only nonzero intersections are labelled.
    ax.add_patch(Rectangle((1.22,.16),.43,.69,facecolor='white',edgecolor='#579CBD',linewidth=1.1,zorder=3))
    for y in [.16,.85]:ax.plot([.547,1.22],[.5,y],color='#579CBD',linewidth=1.0,linestyle=(0,(5,3)),zorder=2)
    text(ax,1.435,.77,'Shared targets',ha='center',va='center',fontsize=10 if not small else 9,zorder=5)
    text(ax,1.435,.46,'\n'.join(s['core_genes']),ha='center',va='center',fontsize=12 if not small else 10.5,
         linespacing=1.45,fontfamily='Times New Roman',zorder=5)
    text(ax,.5,-.10,'Nonzero regions shown; areas are not proportional',ha='center',va='center',
         fontsize=8.5 if not small else 7.5,color='#555555')

def check_and_add(fig,name,scope):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();issues=audit_layout(fig)
    texts=[t for ax in fig.axes for t in ax.texts if t.get_text() and t.get_gid()=='content-label']
    collisions=[]
    for i,a in enumerate(texts):
        for b in texts[i+1:]:
            if a.get_window_extent(renderer).overlaps(b.get_window_extent(renderer)):
                collisions.append([a.get_text(),b.get_text()])
    failures=[msg for severity,msg in issues if severity=='FAIL']
    qa.append({'name':name,'size_inches':list(fig.get_size_inches()),'scope':scope,
               'layout_issues':issues,'label_overlap_pairs':collisions,'label_count':len(texts)})
    assert not failures,(name,failures)
    assert not collisions,(name,collisions)
    fig.savefig(AUDIT/(name+'_预览.png'),dpi=150,facecolor='white')
    figures.append((name,fig))

# Combined figure follows the A/C left, six B networks right organization.
fig=plt.figure(figsize=(12.5,11.0),dpi=120,facecolor='white')
draw_a(fig.add_axes([.018,.455,.485,.53]),small=True)
draw_c(fig.add_axes([.015,.02,.49,.405]),small=True)
for i,m in enumerate(s['methods']):
    row,col=divmod(i,2)
    draw_b(fig.add_axes([.515+col*.237,.665-row*.318,.232,.307]),m,small=True)
for x,y,label in [(.012,.985,'A'),(.511,.985,'B'),(.012,.431,'C')]:
    fig.text(x,y,label,fontsize=20,fontfamily='Times New Roman',ha='left',va='top')
check_and_add(fig,'图3_组合图','A + B (six methods) + C')

fig=plt.figure(figsize=(7.6,7.6),dpi=120,facecolor='white')
draw_a(fig.add_axes([.02,.02,.96,.96]));check_and_add(fig,'图3A_PPI网络','A')
fig=plt.figure(figsize=(7.6,10.5),dpi=120,facecolor='white')
for i,m in enumerate(s['methods']):
    row,col=divmod(i,2);draw_b(fig.add_axes([.02+col*.495,.68-row*.322,.465,.305]),m)
text(fig.add_axes([.22,.005,.56,.027]),.5,.5,'Lower score: yellow     Higher score: red',ha='center',va='center',fontsize=9)
fig.axes[-1].axis('off')
check_and_add(fig,'图3B_六算法前10靶点','B six networks')
for m in s['methods']:
    fig=plt.figure(figsize=(3.8,3.8),dpi=120,facecolor='white');draw_b(fig.add_axes([.02,.02,.96,.96]),m)
    check_and_add(fig,'图3B_'+m+'_前10靶点','B '+m)
fig=plt.figure(figsize=(7.6,5.4),dpi=120,facecolor='white')
draw_c(fig.add_axes([.02,.03,.96,.94]));check_and_add(fig,'图3C_六算法交集','C')

report={'figures':qa,'colors':{m:{g:c for (method,g),c in colors.items() if method==m} for m in s['methods']},
        'dpi':600,'node_color':'#F4ACAD','B_colormap':'autumn_r, min/max normalized within each method',
        'C_nonzero_region_count':sum(bool(r['Exclusive_gene_count']) for r in d['regions']),
        'minimum_label_font_points':7.4,'standalone_panel_letters':False,
        'matplotlib_version':matplotlib.__version__}
if args.export:
    for name,fig in figures:
        for ext in ['png','svg']:fig.savefig(FIG/(name+'.'+ext),dpi=600,facecolor='white')
        print('Exported '+name,flush=True)
    with PdfPages(ROOT/s['pdf'],metadata={'Title':'AKI Figure 3: PPI and core-target analysis','Author':'Reproducible computational analysis'}) as pdf:
        for name,fig in figures:pdf.savefig(fig,facecolor='white')
    report['pdf_pages']=[{'page':i+1,'figure':name} for i,(name,fig) in enumerate(figures)]
    Image.open(FIG/'图3_组合图.png').convert('L').save(AUDIT/'图3_组合图_灰度.png',dpi=(600,600))
(AUDIT/'figure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
for name,fig in figures:plt.close(fig)
print(json.dumps({'figures':len(figures),'exported':args.export,'core':s['core_genes']},ensure_ascii=True))
