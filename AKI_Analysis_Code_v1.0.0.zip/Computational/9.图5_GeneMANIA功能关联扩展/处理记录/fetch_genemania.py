from pathlib import Path
import json,urllib.request,urllib.error,datetime,time,hashlib,shutil,sys,uuid

WORK=Path(__file__).resolve().parent
ROOT=WORK.parent if WORK.name=='处理记录' else Path('./Computational/9.图5_GeneMANIA功能关联扩展')
RAW=ROOT/'原始数据';AUDIT=ROOT/'处理记录';TABLES=ROOT/'各网络数据表'
for p in [ROOT,RAW,AUDIT,TABLES]:p.mkdir(parents=True,exist_ok=True)
source=RAW/'输入_图3的6个核心靶点.txt'
if not source.exists():source=Path('./Computational/7.图3_PPI与核心靶点分析/各子图数据表/C_共同核心基因.txt')
seeds=[s.strip() for s in source.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
assert len(seeds)==6 and len(set(seeds))==6
if source.resolve()!=(RAW/'输入_图3的6个核心靶点.txt').resolve():shutil.copyfile(source,RAW/'输入_图3的6个核心靶点.txt')
for name in ['resources.json','genemania_index.html','genemania_all.min.js']:
    if (WORK/name).exists() and not (RAW/name).exists():shutil.copyfile(WORK/name,RAW/name)
refresh='--refresh' in sys.argv
if refresh:
    sid_refresh='local-user-'+str(uuid.uuid4())
    with urllib.request.urlopen('https://genemania.org/json/resources?session_id='+sid_refresh,timeout=60) as res:
        (RAW/'resources.json').write_bytes(res.read())
resources=json.loads((RAW/'resources.json').read_text(encoding='utf-8'))
groups=resources['networkGroups']['4']
network_ids=[n['id'] for g in groups for n in (g['interactionNetworks'] or []) if n['defaultSelected']]
attrs=[g['id'] for g in resources['attributeGroups']['4'] if g['defaultSelected']]
sid='local-user-'+str(uuid.uuid4())
print('Human taxonomy',next(o['taxonomyId'] for o in resources['organisms'] if o['id']==4),flush=True)
print('Database versions',resources['versions'],flush=True)
print('Default network counts',[(g['name'],sum(n['defaultSelected'] for n in (g['interactionNetworks'] or []))) for g in groups],flush=True)
log_path=AUDIT/'GeneMANIA下载记录.json'
provenance=json.loads(log_path.read_text(encoding='utf-8')) if log_path.exists() else []
for gene in seeds:
    payload={'organism':4,'genes':gene,'attrGroups':attrs,'networks':network_ids,'geneThreshold':10,'attrThreshold':10,'weighting':'AUTOMATIC_SELECT','sessionId':sid}
    dest=RAW/(gene+'_result.json')
    if dest.exists() and not refresh:
        print(gene,'using archived response; original query and provenance retained',flush=True)
        continue
    (RAW/(gene+'_query.json')).write_text(json.dumps(payload,indent=2),encoding='utf-8')
    start=time.monotonic();when=datetime.datetime.now(datetime.timezone.utc).isoformat()
    headers={};cached=False
    if cached:raw=dest.read_bytes()
    else:
        for attempt in [1,2]:
            try:
                request=urllib.request.Request('https://genemania.org/json/search_results',data=json.dumps(payload).encode('utf-8'),
                    headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Referer':'https://genemania.org/'},method='POST')
                with urllib.request.urlopen(request,timeout=120) as response:
                    raw=response.read();headers=dict(response.headers);status=response.status
                dest.write_bytes(raw);break
            except (urllib.error.URLError,TimeoutError) as exc:
                if attempt==2:raise
                print(gene,'retry after',type(exc).__name__,flush=True)
    result=json.loads(raw)
    if result.get('error'):raise RuntimeError(gene+': '+str(result['error']))
    provenance=[r for r in provenance if r['Seed']!=gene]
    provenance.append({'Seed':gene,'URL':'https://genemania.org/json/search_results','Method':'POST','Retrieved_UTC':when,
        'Cached':cached,'Seconds':round(time.monotonic()-start,3),'Bytes':len(raw),'SHA256':hashlib.sha256(raw).hexdigest(),'Response_headers':headers,
        'Public_query_link':'https://genemania.org/link?o=9606&g='+gene+'&r=10&m=automatic'})
    (AUDIT/'GeneMANIA下载记录.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
    print(gene,'saved',len(raw),'bytes; keys:',list(result),flush=True)
print('ALL SIX QUERIES COMPLETE',flush=True)
