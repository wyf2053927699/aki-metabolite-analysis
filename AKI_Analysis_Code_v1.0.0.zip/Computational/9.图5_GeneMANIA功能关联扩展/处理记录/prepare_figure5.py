from pathlib import Path
from urllib.parse import urlparse,parse_qs
import json,math,hashlib,collections,shutil
import pandas as pd

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/9.图5_GeneMANIA功能关联扩展')
RAW=ROOT/'原始数据';A=ROOT/'处理记录';T=ROOT/'各网络数据表';G=ROOT/'可编辑网络'
G.mkdir(exist_ok=True)
seeds=[s.strip() for s in (RAW/'输入_图3的6个核心靶点.txt').read_text(encoding='utf-8-sig').splitlines() if s.strip()]
resources=json.loads((RAW/'resources.json').read_text(encoding='utf-8'))
COLORS={'coexp':'#D0B7D5','coloc':'#A0B3DC','gi':'#90E190','path':'#9BD8DE','pi':'#EAA2A2','predict':'#F6C384','spd':'#DAD4A2'}
NAMES={'coexp':'Co-expression','coloc':'Co-localization','gi':'Genetic Interactions','path':'Pathway','pi':'Physical Interactions','predict':'Predicted','spd':'Shared protein domains'}
def csv(df,name):df.to_csv(T/name,index=False,encoding='utf-8-sig')
def records(df):return df.astype(object).where(pd.notna(df),None).values.tolist()
allnodes=[];rawedges=[];nets=[];groups=[];overview=[]
for seed in seeds:
    d=json.loads((RAW/(seed+'_result.json')).read_text(encoding='utf-8'))
    assert not d.get('error')
    p=d['parameters'];assert p['organism']['taxonomyId']==9606 and p['resultsSize']==10
    assert [g['symbol'] for g in p['genes']]==[seed]
    genes=d['resultGenes'];assert len(genes)==11 and sum(g['queryGene'] for g in genes)==1
    related=sorted([g for g in genes if not g['queryGene']],key=lambda g:(-g['score'],g['gene']['symbol']))
    scores=[g['score'] for g in related];rank={g['gene']['symbol']:i+1 for i,g in enumerate(related)}
    nr=[]
    for result_order,g in enumerate(genes,1):
        gene=g['gene'];symbol=gene['symbol'];isquery=g['queryGene'];pr=rank.get(symbol,0)
        entrez=[]
        for link in g.get('links',[]):
            if link['name']=='Entrez':entrez.extend(parse_qs(urlparse(link['url']).query).get('term',[]))
        assert len(set(entrez))==1,(seed,symbol,entrez)
        theta=math.pi/2-(pr-1)*2*math.pi/10
        norm=(g['score']-min(scores))/(max(scores)-min(scores)) if not isquery else 1
        radius_from_score=.225 if isquery else .175+.060*norm
        radius=max(radius_from_score,.225 if len(symbol)>=7 else .205 if len(symbol)>=6 else .175)
        nr.append(dict(Seed=seed,Gene_symbol=symbol,Entrez_ID=str(entrez[0]),GeneMANIA_gene_ID=gene['id'],
            GeneMANIA_node_ID=gene['node']['id'],Gene_name=gene['node']['geneData']['description'],
            Is_query=isquery,Prediction_rank=pr,Score=g['score'],Response_order=result_order,
            x=0 if isquery else math.cos(theta),y=0 if isquery else math.sin(theta),Radius=radius,Radius_from_score=radius_from_score,
            Fill='#555555',Hatch='////' if isquery else '',Label_color='#FFFFFF'))
    nodes=pd.DataFrame(nr);allnodes.extend(nr)
    edge_count=0
    for rg in d['resultNetworkGroups']:
        cat=rg['networkGroup'];code=cat['code']
        assert code in COLORS
        groups.append(dict(Seed=seed,Category_code=code,Category=NAMES[code],Category_weight=rg['weight'],
            Returned_datasets=len(rg['resultNetworks']),Color=COLORS[code]))
        for net in rg['resultNetworks']:
            n=net['network'];meta=n['metadata']
            nets.append(dict(Seed=seed,Network_ID=n['id'],Network_name=n['name'],Category_code=code,Category=NAMES[code],
                Network_weight=net['weight'],Displayed_records=len(net['resultInteractions']),Source=meta['source'],
                PMID=meta.get('pubmedId',''),Year=meta.get('yearPublished',''),Title=meta.get('title',''),
                Citation_URL=meta.get('url',''),Source_URL=meta.get('sourceUrl',''),Processing=meta.get('processingDescription','')))
            for edge_order,e in enumerate(net['resultInteractions'],1):
                fg=e['fromGene']['gene'];tg=e['toGene']['gene'];src,dst=sorted([fg['symbol'],tg['symbol']])
                rawedges.append(dict(Seed=seed,Source=src,Target=dst,Category_code=code,Category=NAMES[code],Network_ID=n['id'],
                    Network_name=n['name'],Network_weight=net['weight'],Interaction_weight=e['interaction']['weight'],
                    Absolute_weight=net['weight']*e['interaction']['weight'],Original_from=fg['symbol'],Original_to=tg['symbol'],
                    From_node_ID=e['interaction']['fromNode']['id'],To_node_ID=e['interaction']['toNode']['id'],
                    Within_dataset_order=edge_order,PMID=meta.get('pubmedId',''),Citation_URL=meta.get('url',''),Color=COLORS[code]))
                edge_count+=1
    overview.append(dict(Seed=seed,Query_genes=1,Predicted_genes=10,Network_nodes=11,Evidence_records=edge_count,
        Requested_weighting='AUTOMATIC_SELECT',Returned_weighting=d['weighting'],Database_version=resources['versions']['dbVersion']))
nodes=pd.DataFrame(allnodes);raw=pd.DataFrame(rawedges);networks=pd.DataFrame(nets);weights=pd.DataFrame(groups);summary=pd.DataFrame(overview)
assert set(raw.Source)|set(raw.Target)<=set(nodes.Gene_symbol)
plot=raw.groupby(['Seed','Source','Target','Category_code','Category'],sort=True,as_index=False).agg(
    Absolute_weight=('Absolute_weight','sum'),Evidence_records=('Network_ID','size'),Network_count=('Network_ID','nunique'),
    Network_IDs=('Network_ID',lambda v:';'.join(map(str,sorted(set(v))))),Network_names=('Network_name',lambda v:';'.join(sorted(set(v)))))
plot['Color']=plot.Category_code.map(COLORS);plot['Curvature']=0.0
order={c:i for i,c in enumerate(COLORS)}
for _,idx in plot.groupby(['Seed','Source','Target']).groups.items():
    idx=sorted(idx,key=lambda i:order[plot.loc[i,'Category_code']]);n=len(idx)
    for j,i in enumerate(idx):plot.loc[i,'Curvature']=(j-(n-1)/2)*.055
plot['Width_pt']=.45+2.0*(plot.Absolute_weight/plot.groupby('Seed').Absolute_weight.transform('max'))**.5
plot['Alpha']=.43
for seed in seeds:
    degree=plot[plot.Seed==seed].groupby('Source').size().add(plot[plot.Seed==seed].groupby('Target').size(),fill_value=0)
    nodes.loc[nodes.Seed==seed,'Plot_edge_degree']=nodes.loc[nodes.Seed==seed,'Gene_symbol'].map(degree).fillna(0).astype(int)
summary['Plot_category_edges']=summary.Seed.map(plot.groupby('Seed').size())
summary['Unique_gene_pairs']=summary.Seed.map(raw.drop_duplicates(['Seed','Source','Target']).groupby('Seed').size())
pred=nodes[~nodes.Is_query][['Seed','Prediction_rank','Gene_symbol','Entrez_ID','Gene_name','Score']].sort_values(['Seed','Prediction_rank'])
unique=pred.groupby(['Gene_symbol','Entrez_ID'],sort=True,as_index=False).agg(
    Gene_name=('Gene_name','first'),Predicted_by=('Seed',lambda v:';'.join(sorted(set(v)))),
    Seed_count=('Seed','nunique'),Best_rank=('Prediction_rank','min'))
assert unique.Gene_symbol.nunique()==len(unique) and unique.Entrez_ID.nunique()==len(unique)
initial_path=Path('./Computational/5.gutMGene宿主基因交集_图2C/图2C_交集靶点_49个.csv')
initial_local=RAW/'输入_图2C的49个候选基因.csv'
if not initial_local.exists():shutil.copyfile(initial_path,initial_local)
initial=pd.read_csv(initial_local,encoding='utf-8-sig',dtype=str,keep_default_na=False)
original=set(initial.Gene_symbol)
unique['In_original49']=unique.Gene_symbol.isin(original)
expanded=[]
all_names={r.Gene_symbol:r.Gene_name for r in nodes.itertuples()}
all_entrez={r.Gene_symbol:str(r.Entrez_ID) for r in nodes.itertuples()}
for gene in sorted(original|set(unique.Gene_symbol)):
    was_initial=gene in original;u=unique[unique.Gene_symbol==gene]
    eid=initial.loc[initial.Gene_symbol==gene,'gutMGene_Gene_IDs'].iloc[0] if was_initial else all_entrez[gene]
    if was_initial and gene in all_entrez:assert str(eid)==str(all_entrez[gene]),(gene,eid,all_entrez[gene])
    expanded.append(dict(Gene_symbol=gene,Entrez_ID=str(eid),In_original49=was_initial,Is_Figure3_core=gene in seeds,
        In_predicted_top10=not u.empty,Newly_added=not was_initial,
        Predicted_by='' if u.empty else u.Predicted_by.iloc[0],Best_rank=None if u.empty else int(u.Best_rank.iloc[0]),
        Gene_name=all_names.get(gene,initial.loc[initial.Gene_symbol==gene,'Gene_name'].iloc[0] if was_initial else '')))
expanded=pd.DataFrame(expanded)
assert expanded.Entrez_ID.nunique()==len(expanded)
(T/f'扩展候选基因_{len(expanded)}个.txt').write_text('\n'.join(expanded.Gene_symbol)+'\n',encoding='utf-8')
(T/f'预测基因去重_{len(unique)}个.txt').write_text('\n'.join(unique.Gene_symbol)+'\n',encoding='utf-8')
for frame,name in [(summary,'查询与网络汇总.csv'),(nodes,'图5_全部节点及坐标.csv'),(raw,'图5_全部数据集证据连线.csv'),
    (plot,'图5_合并同类别后的绘图连线.csv'),(networks,'全部数据集权重与来源.csv'),(weights,'各类别权重.csv'),
    (pred,'六个核心靶点_预测前10基因.csv'),(unique,'预测基因_合并去重.csv'),(expanded,'原49基因_加入预测结果后去重.csv')]:csv(frame,name)
for seed in seeds:
    for frame,suffix in [(nodes,'节点'),(plot,'绘图连线'),(raw,'全部证据连线'),(networks,'数据集权重与来源')]:
        csv(frame[frame.Seed==seed],seed+'_'+suffix+'.csv')
    (T/(seed+'_预测前10基因.txt')).write_text('\n'.join(pred.loc[pred.Seed==seed,'Gene_symbol'])+'\n',encoding='utf-8')

# Editable GraphML: one multi-edge per gene pair and evidence category.
import xml.etree.ElementTree as ET
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
for seed in seeds:
    ndf=nodes[nodes.Seed==seed];edf=plot[plot.Seed==seed]
    root=ET.Element('{'+ns+'}graphml')
    for field,typ in [('Entrez_ID','string'),('Score','double'),('Is_query','boolean'),('Prediction_rank','int'),('x','double'),('y','double'),('Radius','double'),('Fill','string')]:
        ET.SubElement(root,'{'+ns+'}key',id='n_'+field,**{'for':'node','attr.name':field,'attr.type':typ})
    for field,typ in [('Category','string'),('Absolute_weight','double'),('Evidence_records','int'),('Color','string')]:
        ET.SubElement(root,'{'+ns+'}key',id='e_'+field,**{'for':'edge','attr.name':field,'attr.type':typ})
    graph=ET.SubElement(root,'{'+ns+'}graph',id=seed,edgedefault='undirected')
    for row in ndf.to_dict('records'):
        el=ET.SubElement(graph,'{'+ns+'}node',id=row['Gene_symbol'])
        for key in ['Entrez_ID','Score','Is_query','Prediction_rank','x','y','Radius','Fill']:
            val=str(row[key]).lower() if isinstance(row[key],bool) else str(row[key])
            ET.SubElement(el,'{'+ns+'}data',key='n_'+key).text=val
    for i,row in enumerate(edf.to_dict('records')):
        el=ET.SubElement(graph,'{'+ns+'}edge',id='e'+str(i),source=row['Source'],target=row['Target'])
        for key in ['Category','Absolute_weight','Evidence_records','Color']:
            ET.SubElement(el,'{'+ns+'}data',key='e_'+key).text=str(row[key])
    ET.ElementTree(root).write(G/(seed+'_GeneMANIA.graphml'),encoding='utf-8',xml_declaration=True)

protocol={'organism':'Homo sapiens, NCBI taxonomy 9606; GeneMANIA internal organism ID 4',
 'query_scope':'Six Figure3 core genes, queried individually. Not one combined six-gene query.',
 'seeds':';'.join(seeds),'related_genes_per_query':10,'network_selection':'All 538 default-selected human networks from current official resources snapshot',
 'selected_network_counts':{g['code']:sum(n['defaultSelected'] for n in (g['interactionNetworks'] or [])) for g in resources['networkGroups']['4']},
 'weighting':'AUTOMATIC_SELECT, official server; single-gene mode uses GO biological-process weighting per official documentation',
 'returned_weighting':'AUTOMATIC_SELECT (the server does not expose the resolved internal enum in these responses)',
 'max_attributes':10,'attribute_groups':'None selected (official default)',
 'database_version':resources['versions']['dbVersion'],'webapp_version':resources['versions']['webappVersion'],
 'retrieved_date':'2026-10-19','data_source':'https://genemania.org/json/search_results',
 'gene_score':'Native GeneMANIA relevance score; not a P value, probability or expression fold change',
 'edge_absolute_weight':'interaction.weight * parent resultNetwork.weight, same as the official web application',
 'plot_edge_aggregation':'Undirected pair and category; sum of absolute weights; all original dataset records are retained separately',
 'node_size':'Input hub radius .225; related score-based radius .175 + .060 * within-query min-max score. Minimum radius .225 for >=7-character symbols and .205 for 6-character symbols for legibility; both radii archived.',
 'node_position':'Query gene at origin; ten related genes arranged clockwise from top in descending prediction rank',
 'reference_DOI':'10.1186/s40643-026-01083-8','reference_figure':5,
 'reference_scope_difference':'The reference Figure5 displays seven networks including a repeated CASP3 panel; this figure uses the six distinct core genes obtained from the user data',
 'number_prediction_rows':len(pred),'number_unique_predictions':len(unique),'original49_overlap':int(unique.In_original49.sum()),
 'number_new_genes':int(expanded.Newly_added.sum()),'number_expanded_candidates':len(expanded)}
(A/'analysis_protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
payload={'seeds':seeds,'nodes':nodes.to_dict('records'),'plot_edges':plot.to_dict('records'),
    'summary':summary.to_dict('records'),'colors':COLORS,'category_names':NAMES,'protocol':protocol}
(A/'figure5_data.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),encoding='utf-8')

labels={'Seed':'输入核心靶点','Gene_symbol':'基因符号','Entrez_ID':'Entrez ID','Gene_name':'完整名称',
    'Prediction_rank':'预测排名','Score':'GeneMANIA分值','Is_query':'是否输入靶点','Source':'起点','Target':'终点',
    'Category':'证据类别','Category_code':'类别代码','Absolute_weight':'加权关联权重','Evidence_records':'原始证据条数',
    'Network_count':'来源数据集数','Network_ID':'数据集ID','Network_name':'数据集名称','Network_weight':'数据集权重',
    'Interaction_weight':'原始关联权重','Predicted_by':'对应核心靶点','Seed_count':'预测靶点数','Best_rank':'最佳预测排名',
    'In_original49':'原49候选基因中','Is_Figure3_core':'图3核心靶点','In_predicted_top10':'预测Top10中','Newly_added':'新增候选基因',
    'Category_weight':'类别权重','Returned_datasets':'返回数据集数','Color':'配色','x':'坐标x','y':'坐标y','Radius':'节点半径',
    'Query_genes':'输入基因数','Predicted_genes':'预测基因数','Network_nodes':'节点数','Plot_category_edges':'绘图类别连线数',
    'Unique_gene_pairs':'基因对数','Database_version':'数据库版本','Requested_weighting':'请求加权方式','Returned_weighting':'返回加权方式',
    'Curvature':'曲线弯曲参数','Width_pt':'线宽(pt)','Alpha':'不透明度','Response_order':'原返回顺序','Parameter':'参数','Value':'值'}
sheets=[]
def add(name,key,df,title,notes,widths=None):
    fields=list(df.columns)
    if widths is None:widths=[80 if f in ['Gene_name','Predicted_by','Value','Network_names'] else 48 if f in ['Network_name','Citation_URL'] else 25 for f in fields]
    sheets.append(dict(name=name,key=key,fields=fields,labels=[labels.get(f,f) for f in fields],widths=widths,
        title=title,notes=(notes+['']*3)[:3],rows=records(df)))
add('结果概览','summary',summary,'图5｜6个核心靶点的GeneMANIA扩展',[
    '每个核心靶点单独查询：Homo sapiens，增加10个相关基因，默认网络及自动加权。',
    f'60条预测记录，去重为{len(unique)}个基因；与原49候选基因合并后共{len(expanded)}个。',
    '官方查询日期2026-10-19；服务器数据库版本2021-08-13。'])
add('图5_全部节点','nodes',nodes,'图5｜全部6个网络的节点与固定坐标',[
    '按“输入核心靶点”筛选即可取得任一子图的完整11个节点。','条纹中心节点为输入靶点；分值为GeneMANIA原生相关性分值。',
    '每个网络单独的节点、连线CSV保存在“各网络数据表”中。'])
add('图5_绘图连线','plot_edges',plot,'图5｜同基因对、同证据类别合并后的绘图连线',[
    '保留所有返回证据类别；同一无向基因对、同一类别的加权关联权重相加。',
    '一条绘图边可以对应多条来源记录；完整明细见“原始证据连线”。','颜色对应证据类别；这些边不表示因果方向或表达上/下调。'])
add('原始证据连线','raw_edges',raw,'图5｜官方返回的全部数据集证据连线',[
    '每行是一个来源数据集中的关联记录，保留原始方向字段用于追溯。',
    '加权关联权重 = 原始关联权重 × 数据集权重，与官方网页计算一致。','PMID与文献链接保存在右侧列；分值不是P值或概率。'])
add('每个靶点预测Top10','predictions',pred,'图5｜6个核心靶点各自预测的前10个基因',[
    '共60条预测记录；预测顺序由官方GeneMANIA分值递减确定。','同一基因可由多个核心靶点预测到，在本表分别保留。','按“输入核心靶点”筛选可获得任一子图的10个扩展基因。'])
add('预测基因去重','unique',unique,'图5｜全部预测基因按基因符号与Entrez ID去重',[
    f'{len(unique)}个不重复预测基因；{int(unique.In_original49.sum())}个已在原49候选基因中。',
    '记录每个基因由哪些核心靶点预测，以及最佳预测排名。','本表未按分值或P值额外筛选。'])
add('原49加扩展后去重','expanded',expanded,'用于下一步分析｜原49候选基因与扩展基因并集',[
    f'保留原49个基因，新增{int(expanded.Newly_added.sum())}个，合并去重为{len(expanded)}个。',
    '新增条目来自功能关联预测，不等同于已经验证的急性肾损伤疾病靶点。','所有来源、Entrez ID与新增标记均保留。'])
add('网络类别权重','weights',weights,'图5｜各查询的七类证据权重与颜色',[
    '权重来自官方响应，合计约为1；单基因默认加权依据GO生物过程。','类别权重是数据整合权重，不代表图中边的数量比例。','全部数据集权重及文献来源另存CSV。'])
params=pd.DataFrame([dict(Parameter=k,Value=json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)) for k,v in protocol.items()])
add('分析参数与来源','parameters',params,'图5｜输入范围、官方版本与绘图规则',[
    '官方说明：https://pages.genemania.org/help/','参考文献 DOI：10.1186/s40643-026-01083-8，图5。',
    '原始JSON、请求参数、下载日志与数据集来源均保留。'],[40,135])
(A/'workbook_payload.json').write_text(json.dumps({'sheets':sheets,'summary':{'workbook':'图5_全部网络数据与扩展基因.xlsx'}},ensure_ascii=False,allow_nan=False),encoding='utf-8')
manifest=[]
for file in sorted(RAW.iterdir()):
    if file.is_file():manifest.append(dict(File=str(file.relative_to(ROOT)).replace('\\','/'),Bytes=file.stat().st_size,SHA256=hashlib.sha256(file.read_bytes()).hexdigest()))
pd.DataFrame(manifest).to_csv(A/'原始输入与响应_SHA256.csv',index=False,encoding='utf-8-sig')
print(json.dumps({k:protocol[k] for k in ['number_prediction_rows','number_unique_predictions','original49_overlap','number_new_genes','number_expanded_candidates']},ensure_ascii=False))
print('Rows:',len(nodes),'nodes;',len(raw),'raw evidence records;',len(plot),'plot category edges')
print('Overlap original49:',unique.loc[unique.In_original49,'Gene_symbol'].tolist())
