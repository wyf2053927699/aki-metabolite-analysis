from pathlib import Path
import sys,json,math,argparse
import numpy as np
import pandas as pd
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
sys.path.insert(0,'./local_user/.codex/skills/scipilot-figure-skill/scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Patch
from matplotlib.lines import Line2D
from matplotlib.collections import LineCollection
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/9.图5_GeneMANIA功能关联扩展')
A=ROOT/'处理记录';FIG=ROOT/'图片';PRE=A/'图片预览'
for p in [FIG,PRE]:p.mkdir(exist_ok=True)
d=json.loads((A/'figure5_data.json').read_text(encoding='utf-8'));seeds=d['seeds']
export='--export' in sys.argv
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
    'savefig.facecolor':'white','text.color':'black','hatch.linewidth':.45})
qa=[];figures=[];label_records=[]

def draw_network(ax,seed,small=False):
    ns=[n for n in d['nodes'] if n['Seed']==seed];es=[e for e in d['plot_edges'] if e['Seed']==seed]
    xy={n['Gene_symbol']:np.array([n['x'],n['y']]) for n in ns}
    ax.set(xlim=(-1.30,1.30),ylim=(-1.32,1.44),aspect='equal');ax.axis('off')
    codes=sorted(d['colors'],key=lambda c:-sum(e['Absolute_weight'] for e in es if e['Category_code']==c))
    for code in codes:
        rows=[e for e in es if e['Category_code']==code];paths=[]
        for e in rows:
            a=xy[e['Source']];b=xy[e['Target']];vec=b-a
            control=(a+b)/2+e['Curvature']*np.array([-vec[1],vec[0]])
            t=np.linspace(0,1,41)[:,None]
            paths.append((1-t)**2*a+2*(1-t)*t*control+t*t*b)
        if rows:ax.add_collection(LineCollection(paths,colors=d['colors'][code],linewidths=[e['Width_pt'] for e in rows],alpha=.43,zorder=1))
    for n in ns:
        patch=Circle((n['x'],n['y']),n['Radius'],facecolor=n['Fill'],edgecolor='#AEAEAE' if n['Is_query'] else 'white',
            linewidth=.6,hatch='//////' if n['Is_query'] else None,zorder=3)
        ax.add_patch(patch)
        fs=(9.5 if n['Is_query'] else 8.2) if small else (12.2 if n['Is_query'] else 11.0)
        label=ax.text(n['x'],n['y'],n['Gene_symbol'],fontsize=fs,color='white',ha='center',va='center',zorder=4)
        label.set_gid('gene-label')
        # Fit the same label within its circular node at the actual export size.
        ax.figure.canvas.draw();renderer=ax.figure.canvas.get_renderer()
        diameter=abs(ax.transData.transform((n['x']+n['Radius'],n['y']))[0]-ax.transData.transform((n['x']-n['Radius'],n['y']))[0])
        while label.get_window_extent(renderer).width>diameter*.87 and fs>7.3:
            fs=max(7.3,round(fs-.1,1));label.set_fontsize(fs);ax.figure.canvas.draw()
        assert label.get_window_extent(renderer).width<=diameter*.92,(seed,n['Gene_symbol'],fs,diameter,label.get_window_extent(renderer).width)
        label_records.append(dict(Figure_scope='combined' if small else 'standalone',Seed=seed,Gene_symbol=n['Gene_symbol'],Font_pt=fs,Radius=n['Radius']))
    title=ax.text(0,1.36,seed,fontsize=14 if small else 17,ha='center',va='center',color='#333333')
    title.set_gid('network-title')

def legend(fig,small=False):
    order=['coexp','coloc','gi','path','pi','predict','spd']
    handles=[Line2D([0],[0],color=d['colors'][c],linewidth=3,label=d['category_names'][c]) for c in order]
    handles.append(Patch(facecolor='#555555',edgecolor='#AEAEAE',hatch='//////',label='Input core gene'))
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.013 if small else .017),
        ncol=4 if small else 2,frameon=False,fontsize=9 if small else 9.5,
        handlelength=1.8,columnspacing=2.3 if small else 2.0,handletextpad=.7,labelspacing=.75)

def check_add(fig,name):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();issues=audit_layout(fig)
    collisions=[];outside=[]
    labels=[t for ax in fig.axes for t in ax.texts]
    for i,t in enumerate(labels):
        bb=t.get_window_extent(renderer)
        if bb.x0<0 or bb.y0<0 or bb.x1>fig.bbox.x1 or bb.y1>fig.bbox.y1:outside.append(t.get_text())
        for u in labels[i+1:]:
            if t.get_window_extent(renderer).overlaps(u.get_window_extent(renderer)):collisions.append((t.get_text(),u.get_text()))
    failures=[m for level,m in issues if level=='FAIL']
    assert not failures and not collisions and not outside,(name,failures,collisions,outside)
    fig.savefig(PRE/(name+'_preview.png'),dpi=150,facecolor='white')
    qa.append(dict(Name=name,Width_inches=fig.get_figwidth(),Height_inches=fig.get_figheight(),DPI=600,
        Labels=len(labels),Overlaps=collisions,Clipped_labels=outside,Layout_issues=issues))
    figures.append((name,fig))

fig=plt.figure(figsize=(12.6,8.8),dpi=120,facecolor='white')
for i,seed in enumerate(seeds):
    row,col=divmod(i,3);draw_network(fig.add_axes([.018+col*.328,.534-row*.431,.315,.420]),seed,True)
legend(fig,True);check_add(fig,'图5_六个核心靶点扩展网络')
for seed in seeds:
    fig=plt.figure(figsize=(6.4,7.1),dpi=120,facecolor='white')
    draw_network(fig.add_axes([.025,.18,.95,.80]),seed);legend(fig,False)
    check_add(fig,'图5_'+seed+'_扩展网络')
if export:
    for name,fig in figures:
        for ext in ['png','svg']:fig.savefig(FIG/(name+'.'+ext),dpi=600,facecolor='white')
        print('Exported',name,flush=True)
    with PdfPages(ROOT/'图5_主图与全部子网络.pdf',metadata={'Title':'Figure 5: GeneMANIA networks for six AKI core genes','Author':'Reproducible computational analysis'}) as pdf:
        for name,fig in figures:pdf.savefig(fig,facecolor='white')
    Image.open(PRE/'图5_六个核心靶点扩展网络_preview.png').convert('L').save(PRE/'图5_组合图_灰度检查.png')
pd.DataFrame(label_records).to_csv(A/'实际绘图节点字号.csv',index=False,encoding='utf-8-sig')
(A/'figure_audit.json').write_text(json.dumps({'figures':qa,'colors':d['colors'],'minimum_label_font_pt':min(r['Font_pt'] for r in label_records),
    'dpi':600,'standalone_panel_letters':False,'edge_width':'0.45 + 2.0 * sqrt(category-pair weight / max within query)',
    'node_size':'see analysis_protocol.json; fixed query radius, related radii scale within-query prediction scores',
    'matplotlib_version':matplotlib.__version__,'exported':export},ensure_ascii=False,indent=2),encoding='utf-8')
for name,fig in figures:plt.close(fig)
print(json.dumps({'figures':len(figures),'exported':export,'min_font_pt':min(r['Font_pt'] for r in label_records)},ensure_ascii=False))
