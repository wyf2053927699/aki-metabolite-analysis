from pathlib import Path
import json,math,hashlib,collections,xml.etree.ElementTree as ET
import pandas as pd
import numpy as np
import openpyxl
from PIL import Image
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/9.图5_GeneMANIA功能关联扩展')
A=ROOT/'处理记录';T=ROOT/'各网络数据表';R=ROOT/'原始数据';checks=[]
def check(name,ok,detail=''):checks.append(dict(Check=name,Passed=bool(ok),Detail=str(detail)))
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,dtype={'Entrez_ID':str},float_precision='round_trip')
nodes=read('图5_全部节点及坐标.csv');plot=read('图5_合并同类别后的绘图连线.csv');raw=read('图5_全部数据集证据连线.csv')
pred=read('六个核心靶点_预测前10基因.csv');unique=read('预测基因_合并去重.csv');expanded=read('原49基因_加入预测结果后去重.csv')
summary=read('查询与网络汇总.csv').set_index('Seed');weights=read('各类别权重.csv');networks=read('全部数据集权重与来源.csv')
seeds=[x.strip() for x in (R/'输入_图3的6个核心靶点.txt').read_text(encoding='utf-8-sig').splitlines() if x.strip()]
original=pd.read_csv(R/'输入_图2C的49个候选基因.csv',encoding='utf-8-sig',dtype=str)
orig=set(original.Gene_symbol)
check('Six distinct input core genes',len(seeds)==len(set(seeds))==6)
for seed in seeds:
    response=json.loads((R/(seed+'_result.json')).read_text(encoding='utf-8'));request=json.loads((R/(seed+'_query.json')).read_text())
    ns=nodes[nodes.Seed==seed];ps=pred[pred.Seed==seed];pe=plot[plot.Seed==seed];re=raw[raw.Seed==seed]
    check(seed+' no official error',not response.get('error'))
    check(seed+' query human correct',request['organism']==4 and response['parameters']['organism']['taxonomyId']==9606)
    check(seed+' one gene per query',request['genes']==seed and [g['symbol'] for g in response['parameters']['genes']]==[seed])
    check(seed+' requested exactly10 additions',request['geneThreshold']==10 and response['parameters']['resultsSize']==10)
    check(seed+' default 538 networks',len(request['networks'])==538 and len(set(request['networks']))==538)
    check(seed+' all11 nodes preserved',len(ns)==11 and ns.Gene_symbol.nunique()==11 and ns.Is_query.sum()==1 and ns.loc[ns.Is_query,'Gene_symbol'].iloc[0]==seed)
    check(seed+' no absent graph endpoints',(set(re.Source)|set(re.Target))<=set(ns.Gene_symbol))
    ranked=sorted((g for g in response['resultGenes'] if not g['queryGene']),key=lambda g:(-g['score'],g['gene']['symbol']))
    check(seed+' native prediction ranks',[g['gene']['symbol'] for g in ranked]==list(ps.sort_values('Prediction_rank').Gene_symbol))
    returned={g['gene']['symbol']:g['score'] for g in response['resultGenes']}
    check(seed+' all native gene scores retained',all(math.isclose(r.Score,returned[r.Gene_symbol],rel_tol=1e-13) for r in ns.itertuples()))
    native=[]
    for group in response['resultNetworkGroups']:
        for network in group['resultNetworks']:
            for edge in network['resultInteractions']:
                src,dst=sorted([edge['fromGene']['gene']['symbol'],edge['toGene']['gene']['symbol']])
                native.append((src,dst,group['networkGroup']['code'],network['network']['id'],network['weight'],edge['interaction']['weight']))
    local=[(r.Source,r.Target,r.Category_code,r.Network_ID,r.Network_weight,r.Interaction_weight) for r in re.itertuples()]
    check(seed+' complete raw evidence records',len(native)==len(local) and all(a[:4]==b[:4] and math.isclose(a[4],b[4],rel_tol=1e-12) and math.isclose(a[5],b[5],rel_tol=1e-12) for a,b in zip(native,local)))
    check(seed+' weighted edge formula',np.allclose(re.Absolute_weight,re.Network_weight*re.Interaction_weight,rtol=1e-12,atol=1e-300))
    grouped=re.groupby(['Source','Target','Category_code']).Absolute_weight.sum()
    observed=pe.set_index(['Source','Target','Category_code']).Absolute_weight
    check(seed+' plot aggregation exact',set(grouped.index)==set(observed.index) and np.allclose(grouped.sort_index(),observed.sort_index(),rtol=1e-12,atol=1e-300))
    check(seed+' evidence multiplicity retained',len(re)==pe.Evidence_records.sum())
    check(seed+' group weights sum to1',math.isclose(weights.loc[weights.Seed==seed,'Category_weight'].sum(),1,abs_tol=1e-12))
    check(seed+' dataset weights sum to1',math.isclose(networks.loc[networks.Seed==seed,'Network_weight'].sum(),1,abs_tol=1e-12))
    check(seed+' summary counts',len(re)==summary.loc[seed,'Evidence_records'] and len(pe)==summary.loc[seed,'Plot_category_edges'])
    check(seed+' nodes fit plot bounds',((ns.x-ns.Radius>-1.30)&(ns.x+ns.Radius<1.30)&(ns.y-ns.Radius>-1.32)&(ns.y+ns.Radius<1.30)).all())
    a=ns[['x','y','Radius']].to_numpy();collision=False
    for i in range(len(a)):
        for j in range(i+1,len(a)):collision|=math.dist(a[i,:2],a[j,:2])<a[i,2]+a[j,2]
    check(seed+' node circles do not overlap',not collision)
    tree=ET.parse(ROOT/'可编辑网络'/(seed+'_GeneMANIA.graphml'));nsxml={'g':'http://graphml.graphdrawing.org/xmlns'}
    check(seed+' GraphML roundtrip',len(tree.findall('.//g:node',nsxml))==11 and len(tree.findall('.//g:edge',nsxml))==len(pe))
check('60 prediction rows',len(pred)==60)
check('59 unique predictions',len(unique)==59 and unique.Gene_symbol.nunique()==59 and unique.Entrez_ID.nunique()==59)
check('Only APPL1 appears in two seed lists',list(pred.Gene_symbol.value_counts()[lambda x:x>1].index)==['APPL1'])
check('APPL1 linked to correct seeds',set(pred.loc[pred.Gene_symbol=='APPL1','Seed'])=={'AKT1','CASP3'})
check('Unique list complete',set(unique.Gene_symbol)==set(pred.Gene_symbol))
check('Three overlaps with original49',set(unique.loc[unique.In_original49,'Gene_symbol'])=={'CASP1','CXCL8','RELA'})
check('Expanded union exactly105',len(expanded)==105 and set(expanded.Gene_symbol)==orig|set(unique.Gene_symbol))
check('Original49 all retained',set(expanded.loc[expanded.In_original49,'Gene_symbol'])==orig and len(orig)==49)
check('New56 flags correct',expanded.Newly_added.sum()==56 and set(expanded.loc[expanded.Newly_added,'Gene_symbol'])==set(unique.Gene_symbol)-orig)
check('All6 hubs retained',set(expanded.loc[expanded.Is_Figure3_core,'Gene_symbol'])==set(seeds))
check('Entrez unique after merge',expanded.Entrez_ID.nunique()==105)
check('105gene text list agrees',set((T/'扩展候选基因_105个.txt').read_text(encoding='utf-8').split())==set(expanded.Gene_symbol))

payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf-8'))
book=ROOT/'图5_全部网络数据与扩展基因.xlsx'
wb=openpyxl.load_workbook(book,data_only=False);cached=openpyxl.load_workbook(book,data_only=True)
check('Workbook sheets agree',wb.sheetnames==[s['name'] for s in payload['sheets']])
for s in payload['sheets']:
    sheet=wb[s['name']];data=cached[s['name']];bad=[]
    for i,row in enumerate(s['rows'],8):
        for j,expect in enumerate(row,1):
            val=data.cell(i,j).value
            if expect is None or expect=='':ok=val in ('',None)
            elif isinstance(expect,bool):ok=val==expect
            elif isinstance(expect,(int,float)):ok=isinstance(val,(int,float)) and not isinstance(val,bool) and math.isclose(val,expect,rel_tol=1e-12,abs_tol=1e-300)
            else:ok=str(val)==str(expect)
            if not ok:bad.append((i,j,expect,val))
    check('Excel '+s['name']+' all cells roundtrip',not bad,str(bad[:2]))
    check('Excel '+s['name']+' count formula',data['B6'].value==len(s['rows']))
    check('Excel '+s['name']+' freeze panes and filter',sheet.freeze_panes=='B8' and len(sheet.tables)==1)
    errors=[c.coordinate for row in data for c in row if c.data_type=='e']
    check('Excel '+s['name']+' no cell errors',not errors,str(errors[:3]))
audit=json.loads((A/'figure_audit.json').read_text(encoding='utf-8'))
check('Seven image variants',len(audit['figures'])==7)
for fig in audit['figures']:
    name=fig['Name'];im=Image.open(ROOT/'图片'/(name+'.png'))
    expected=(round(fig['Width_inches']*600),round(fig['Height_inches']*600))
    check(name+' PNG600dpi',im.size==expected and all(abs(v-600)<.1 for v in im.info.get('dpi',(0,0))),im.size)
    svg=ET.parse(ROOT/'图片'/(name+'.svg'));text=''.join(svg.getroot().itertext())
    check(name+' vector SVG',len(svg.findall('.//{http://www.w3.org/2000/svg}image'))==0)
    expected_genes=set(nodes.Gene_symbol) if name=='图5_六个核心靶点扩展网络' else set(nodes.loc[nodes.Seed==name.split('_')[1],'Gene_symbol'])
    check(name+' SVG all labels',all(g in text for g in expected_genes))
    check(name+' no label overlaps or clipping',not fig['Overlaps'] and not fig['Clipped_labels'])
check('Minimum gene font >=7pt',audit['minimum_label_font_pt']>=7,audit['minimum_label_font_pt'])
reader=PdfReader(ROOT/'图5_主图与全部子网络.pdf');check('PDF7pages',len(reader.pages)==7)
embedded=[]
for i,page in enumerate(reader.pages,1):
    check('PDF page '+str(i)+' all vector',len(page.images)==0)
    check('PDF page '+str(i)+' selectable text',len(page.extract_text())>60)
    for value in page['/Resources'].get('/Font',{}).values():
        font=value.get_object()
        for child in font.get('/DescendantFonts',[font]):
            desc=child.get_object().get('/FontDescriptor')
            if desc:embedded.append(any(k in desc.get_object() for k in ['/FontFile','/FontFile2','/FontFile3']))
check('PDF fonts embedded',bool(embedded) and all(embedded))
check('PDF all7pages rendered',len(list((A/'PDF预览').glob('图5-*.png')))==7)
log=json.loads((A/'GeneMANIA下载记录.json').read_text(encoding='utf-8'))
check('Six downloads with original hashes',len(log)==6 and all(hashlib.sha256((R/(r['Seed']+'_result.json')).read_bytes()).hexdigest()==r['SHA256'] for r in log))
pd.DataFrame(checks).to_csv(A/'完整复核结果.csv',index=False,encoding='utf-8-sig')
report=dict(checks=len(checks),passed=sum(c['Passed'] for c in checks),failed=[c for c in checks if not c['Passed']],
    seeds=seeds,prediction_rows=len(pred),unique_predictions=len(unique),added_to_original49=int(expanded.Newly_added.sum()),expanded_candidates=len(expanded),
    evidence_records=len(raw),plot_category_edges=len(plot),pdf_pages=len(reader.pages),workbook_sheets=len(wb.sheetnames))
(A/'validation_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
assert not report['failed']
