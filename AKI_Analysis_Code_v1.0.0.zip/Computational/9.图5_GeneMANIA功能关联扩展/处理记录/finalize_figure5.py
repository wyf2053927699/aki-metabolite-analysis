from pathlib import Path
import subprocess,json,hashlib
from PIL import Image,ImageDraw,ImageFont
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name=='处理记录' else Path('./Computational/9.图5_GeneMANIA功能关联扩展')
A=ROOT/'处理记录';Q=A/'PDF预览';Q.mkdir(exist_ok=True)
pdf=ROOT/'图5_主图与全部子网络.pdf'
exe=Path('./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
proc=subprocess.run([str(exe),'-r','110','-png',str(pdf),str(Q/'图5')],capture_output=True,text=True)
(A/'PDF渲染日志.txt').write_text(proc.stdout+proc.stderr,encoding='utf-8')
assert proc.returncode==0
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
def contact(files,target,cols=2,width=820,height=670):
    canvas=Image.new('RGB',(width*cols,height*((len(files)+cols-1)//cols)),'#E4E7EB')
    draw=ImageDraw.Draw(canvas)
    for i,file in enumerate(files):
        im=Image.open(file).convert('RGB');im.thumbnail((width-28,height-48))
        x=i%cols*width;y=i//cols*height
        draw.text((x+14,y+8),file.stem,font=font,fill='#263648')
        canvas.paste(im,(x+(width-im.width)//2,y+38))
    canvas.save(target)
contact(sorted(Q.glob('图5-*.png')),A/'PDF全部页面_检查总览.png')
excel=sorted(A.glob('Excel预览_*.png'))
for i in range(0,len(excel),3):contact(excel[i:i+3],A/f'Excel检查总览_{i//3+1}.png',cols=1,width=1400,height=610)
images=sorted((ROOT/'图片').glob('*'))
manifest=[dict(File=str(f.relative_to(ROOT)).replace('\\','/'),Bytes=f.stat().st_size,SHA256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in images+[pdf,ROOT/'图5_全部网络数据与扩展基因.xlsx']]
(A/'交付文件_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pdf_pages':len(PdfReader(pdf).pages),'rendered_pages':len(list(Q.glob('图5-*.png'))),'delivered_images':len(images)},ensure_ascii=False))
