"""Redraw the complete Figure10 network with larger, unobscured labels."""
from pathlib import Path
import sys,json,textwrap,hashlib,shutil
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
sys.path.insert(0,'./local_user/.codex/skills/scipilot-figure-skill/scripts')
import numpy as np,pandas as pd,networkx as nx,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from visual_qa import audit_layout

W=Path(__file__).resolve().parent;R=W.parent
PREVIEW=W/'图片预览';PREVIEW.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':14,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
def read(name):return pd.read_csv(R/'各子图数据表'/name,encoding='utf-8-sig',keep_default_na=False)
def wrap(s,width):return '\n'.join(textwrap.wrap(s,width,break_long_words=False,break_on_hyphens=False))

def main():
    nodes=read('图10_全部节点.csv');edges=read('图10_全部连线.csv')
    original=read('图10_全部节点_含坐标.csv').set_index('Node_ID')
    assert len(nodes)==nodes.Node_ID.nunique()==123 and len(edges)==184
    graph=nx.Graph()
    for _,row in nodes.iterrows():graph.add_node(row.Node_ID,**row.to_dict())
    for _,row in edges.iterrows():graph.add_edge(row.Source,row.Target,**row.to_dict())
    assert graph.number_of_nodes()==123 and graph.number_of_edges()==184
    labels=dict(zip(nodes.Node_ID,nodes.Label));pos={}
    microbial=sorted(nodes[nodes.Type.eq('Gut microbiota')].Node_ID,key=lambda i:labels[i].casefold())
    for idx,i in enumerate(microbial):pos[i]=((idx//27)*3.45,26-idx%27)
    for typ,x in [('Target',15.0),('Pathway',18.8),('Metabolite',23.0)]:
        ids=list(nodes[nodes.Type.eq(typ)].Node_ID)
        if typ=='Metabolite':ids=sorted(ids,key=lambda i:(-graph.degree(i),labels[i]))
        for i,y in zip(ids,np.linspace(24,2,len(ids))):pos[i]=(x,float(y))
    assert set(pos)==set(original.index)
    assert all(np.allclose(pos[i],original.loc[i,['Plot_x','Plot_y']].astype(float),rtol=1e-12,atol=1e-12) for i in pos)
    params={'figure_inches':[22,18],'dpi':600,'fonts_pt':{'Gut microbiota':14,'Target':18,'Pathway':16,'Metabolite':16,'Column heading':17,'Title':21,'Footer':12},
            'Microbial_columns':4,'Maximum_rows_per_column':27,'Microbial_label_wrap_chars':25,'Label_background':'white, 97% opacity',
            'Topology':'123 original nodes and 184 original edges; all saved node coordinates unchanged',
            'Colors':{'Gut microbiota':'#FFD240','Target':'#66FF33','Pathway':'#FFF100','Metabolite':'#9B90EE'}}
    fig,ax=plt.subplots(figsize=params['figure_inches']);fig.subplots_adjust(left=.025,right=.995,top=.94,bottom=.055)
    for typ,color,alpha,width in [('Microbe-Metabolite','#B0A4C2',.36,.65),('Microbe-Target','#647279',.52,.9),('Metabolite-Target','#826D96',.65,1.1),('Target-Pathway','#5F8068',.75,1.35)]:
        pairs=[(r.Source,r.Target) for _,r in edges[edges.Relation.eq(typ)].iterrows()]
        nx.draw_networkx_edges(graph,pos,edgelist=pairs,ax=ax,edge_color=color,alpha=alpha,width=width)
    styles={'Gut microbiota':('#FFD240','D',120),'Target':('#66FF33','s',650),'Pathway':('#FFF100','v',750),'Metabolite':('#9B90EE','8',650)}
    label_artists={}
    for typ,(color,shape,size) in styles.items():
        ids=list(nodes[nodes.Type.eq(typ)].Node_ID)
        if typ!='Target':nx.draw_networkx_nodes(graph,pos,nodelist=ids,node_color=color,node_shape=shape,node_size=size,edgecolors='white',linewidths=.8,ax=ax)
        for i in ids:
            x,y=pos[i];font=params['fonts_pt'][typ]
            if typ=='Gut microbiota':
                label_artists[i]=ax.text(x+.18,y,wrap(labels[i],25),fontsize=font,ha='left',va='center',fontstyle='italic',color='#15191E',linespacing=1.15,bbox={'fc':'white','ec':'none','pad':.8,'alpha':.97},zorder=5)
            elif typ=='Target':
                ax.add_patch(FancyBboxPatch((x-.61,y-.44),1.22,.88,boxstyle='round,pad=.07,rounding_size=.10',facecolor=color,edgecolor='white',lw=.8,zorder=4))
                label_artists[i]=ax.text(x,y,labels[i],fontsize=font,ha='center',va='center',fontweight='bold',color='#111111',zorder=5)
            else:
                label_artists[i]=ax.text(x+.40,y,wrap(labels[i],22),fontsize=font,ha='left',va='center',color='#15191E',linespacing=1.15,bbox={'fc':'white','ec':'none','pad':1.4,'alpha':.97},zorder=5)
    for x,title in [(5,'Gut microbiota (107 taxa)'),(15,'Core targets (6)'),(18.8,'Pathways (2)'),(23.6,'Metabolites (8)')]:
        ax.text(x,27.45,title,ha='center',va='center',fontsize=17,fontweight='bold',color='#17202A',zorder=6)
    ax.set(xlim=(-.4,27.4),ylim=(-.8,28.2));ax.set_axis_off()
    fig.suptitle('Gut microbiota–target–pathway–metabolite network',fontsize=21,fontweight='bold',y=.985,color='#17202A')
    fig.text(.5,.018,'Human gutMGene associations and KEGG membership · 123 nodes · 184 distinct edges',ha='center',fontsize=12,color='#4D5965')
    issues=audit_layout(fig);renderer=fig.canvas.get_renderer()
    boxes={i:t.get_window_extent(renderer) for i,t in label_artists.items()}
    overlaps=[]
    ids=list(boxes)
    for a,i in enumerate(ids):
        for j in ids[a+1:]:
            b,c=boxes[i],boxes[j]
            if min(b.x1,c.x1)-max(b.x0,c.x0)>1 and min(b.y1,c.y1)-max(b.y0,c.y0)>1:
                overlaps.append([i,j,labels[i],labels[j]])
    bounds=[i for i,b in boxes.items() if b.x0<0 or b.y0<0 or b.x1>fig.bbox.width or b.y1>fig.bbox.height]
    label_node_collisions=[]
    for i,b in boxes.items():
        for j in ids:
            if i==j:continue
            cx,cy=ax.transData.transform(pos[j])
            radius=(8 if graph.nodes[j]['Type']=='Gut microbiota' else 14)*fig.dpi/72
            if min(b.x1,cx+radius)-max(b.x0,cx-radius)>1 and min(b.y1,cy+radius)-max(b.y0,cy-radius)>1:
                label_node_collisions.append([i,j])
    unchanged=[]
    backup=R/'历史版本/放大字体前_20261019_01/数据修改前SHA256.json'
    for item in json.loads(backup.read_text(encoding='utf-8-sig')):
        same=hashlib.sha256(Path(item['Path']).read_bytes()).hexdigest().upper()==item['Hash']
        unchanged.append({'File':Path(item['Path']).name,'Unchanged':same})
    report={'Node_count':graph.number_of_nodes(),'Edge_count':graph.number_of_edges(),'Label_count':len(label_artists),
            'Coordinate_values_unchanged':True,'Layout_issues':issues,'Overlapping_labels':overlaps,
            'Out_of_bounds_labels':bounds,'Label_node_collisions':label_node_collisions,'Original_data_files':unchanged,'Font_sizes_pt':params['fonts_pt']}
    (W/'图10_大字体版_检查.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    assert not issues and not overlaps and not bounds and not label_node_collisions,report
    assert all(v['Unchanged'] for v in unchanged)
    (W/'图10_大字体排版参数.json').write_text(json.dumps(params,ensure_ascii=False,indent=2),encoding='utf-8')
    stem='图10_网络_大字体版'
    fig.savefig(PREVIEW/(stem+'.png'),dpi=110)
    fig.savefig(R/'图片'/(stem+'.png'),dpi=600)
    fig.savefig(R/'图片'/(stem+'.svg'))
    fig.savefig(R/'图10_菌群靶点通路代谢物网络_大字体版.pdf')
    plt.close(fig)
    for ext in ['png','svg']:
        shutil.copy2(R/'图片'/(stem+'.'+ext),R/'图片'/('图10_网络.'+ext))
    for i,(x,y) in pos.items():
        graph.nodes[i]['Plot_x']=x;graph.nodes[i]['Plot_y']=y
        graph.nodes[i]['Label_font_pt']=params['fonts_pt'][graph.nodes[i]['Type']]
        graph.nodes[i]['Node_color']=styles[graph.nodes[i]['Type']][0]
    nx.write_graphml(graph,R/'图10_可编辑网络_大字体版.graphml')
    print(json.dumps({'status':'OK','nodes':len(nodes),'edges':len(edges),'overlaps':len(overlaps),'fonts':params['fonts_pt']},ensure_ascii=True))

if __name__=='__main__':main()
