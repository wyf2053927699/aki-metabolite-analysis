from pathlib import Path
import sys,json,shutil,collections,hashlib
import pandas as pd,openpyxl
BASE=Path(__file__).parent.parent.parent if Path(__file__).parent.name=='处理记录' else Path('./Computational')
OUT=BASE/'14.图10_菌群靶点通路代谢物网络'
for name in ['原始数据','各子图数据表','处理记录','图片']: (OUT/name).mkdir(parents=True,exist_ok=True)
def save(df,name):df.to_csv(OUT/'各子图数据表'/name,index=False,encoding='utf-8-sig')
src=BASE/'1.gutMGene数据/1.人-肠道菌群代谢物_人相关物种筛选.xlsx'
w=openpyxl.load_workbook(src,read_only=True,data_only=True)
def read_sheet(name):
    rows=list(w[name].iter_rows(min_row=6,values_only=True));return pd.DataFrame(rows[1:],columns=rows[0]).dropna(how='all').fillna('')
m=read_sheet('人类代谢物清单');gm=read_sheet('人类菌代谢物证据')
m=m[m.SMILES.astype(str).str.strip().ne('')].copy()
def cid(x):
    try:return str(int(float(str(x).strip())))
    except:return str(x).strip()
m['CID']=m['PubChem CID'].map(cid);gm['CID']=gm['Metabolite PubChem CID'].map(cid)
evsrc=BASE/'5.gutMGene宿主基因交集_图2C/gutMGene_v2_人类关联证据_508条.csv'
ev=pd.read_csv(evsrc,keep_default_na=False,dtype=str);core=['AKT1','CASP3','IL1B','IL6','JUN','NFKB1']
ev=ev[ev.Gene_symbol.isin(core)].copy()
mt=ev[ev.Association_category.eq('Microbial metabolite-host gene')].copy();mt['CID']=mt.Entity_ID.map(cid)
mt['Eligible_input_228']=mt.CID.isin(m.CID)
save(mt,'代谢物宿主基因_候选关系与输入核对.csv')
mt=mt[mt.Eligible_input_228].copy();ids=set(mt.CID)
gm=gm[gm.CID.isin(ids)].copy();gt=ev[ev.Association_category.eq('Gut microbe-host gene')].copy()
nodes={};edges=collections.defaultdict(list)
def node(i,label,typ,**extra):
    if i not in nodes:nodes[i]={'Node_ID':i,'Label':label,'Type':typ,**extra}
def edge(a,b,typ,rec):edges[tuple(sorted([a,b]))+(typ,)].append(rec)
def microbe_key(tax,name):
    tax=cid(tax)
    return 'G:'+tax if tax else 'G:NAME:'+hashlib.sha256(str(name).strip().casefold().encode('utf8')).hexdigest()[:12]
for g in core:node('T:'+g,g,'Target',Gene_symbol=g)
for _,r in mt.iterrows():
    i='M:'+r.CID;node(i,r.Entity,'Metabolite',CID=r.CID)
    edge(i,'T:'+r.Gene_symbol,'Metabolite-Target',{'PMID':r.PMID,'Source_file':r.Source_file,'Source_record':r.Source_CSV_record,'Mode':r.Association_mode,'Alteration':r.Alteration})
for _,r in gt.iterrows():
    i=microbe_key(r.Entity_ID,r.Entity);node(i,r.Entity,'Gut microbiota',TaxID=cid(r.Entity_ID))
    edge(i,'T:'+r.Gene_symbol,'Microbe-Target',{'PMID':r.PMID,'Source_file':r.Source_file,'Source_record':r.Source_CSV_record,'Mode':r.Association_mode,'Alteration':r.Alteration})
for _,r in gm.iterrows():
    i=microbe_key(r['Gut Microbiota NCBI ID'],r['Gut Microbiota']);node(i,r['Gut Microbiota'],'Gut microbiota',TaxID=cid(r['Gut Microbiota NCBI ID']))
    edge(i,'M:'+r.CID,'Microbe-Metabolite',{'PMID':str(r.PMID),'Source_file':src.name+' / 人类菌代谢物证据','Source_record':str(r.Source_data_row),'Mode':r['Associative mode'],'Alteration':''})
psrc=BASE/'11.图7_核心靶点通路定位/各子图数据表/两通路_六核心定位总表.csv'
p=pd.read_csv(psrc,dtype=str,keep_default_na=False)
for _,r in p.iterrows():
    if str(r['Shown_in_KGML']).lower() not in ['true','1','yes']:continue
    i='P:'+r.Pathway_ID;node(i,{'hsa04620':'Toll-like receptor signaling','hsa04668':'TNF signaling'}[r.Pathway_ID],'Pathway',Pathway_ID=r.Pathway_ID)
    edge('T:'+r.SYMBOL,i,'Target-Pathway',{'PMID':'','Source_file':'KEGG KGML '+r.Pathway_ID,'Source_record':'Figure7','Mode':'Pathway membership','Alteration':''})
ed=[];evidence=[]
for k,records in sorted(edges.items()):
    a,b,typ=k;eid=f'E{len(ed)+1:04d}';pmids=sorted(set(str(x['PMID']) for x in records if x['PMID']))
    ed.append({'Edge_ID':eid,'Source':a,'Target':b,'Relation':typ,'Evidence_count':len(records),'PMIDs':';'.join(pmids)})
    for r in records:evidence.append({'Edge_ID':eid,'Source':a,'Target':b,'Relation':typ,**r})
degrees=collections.Counter(x for e in ed for x in [e['Source'],e['Target']])
for i,n in nodes.items():n['Degree']=degrees[i]
nd=pd.DataFrame(nodes.values()).fillna('');ed=pd.DataFrame(ed)
met=nd[nd.Type.eq('Metabolite')].copy().sort_values(['Degree','CID'],ascending=[False,True],key=lambda s:pd.to_numeric(s) if s.name=='CID' else s)
met['Degree_rank']=range(1,len(met)+1);met['Selected_for_docking']=met.Degree_rank.le(4)
mm=m.drop_duplicates('CID').set_index('CID')
met['SMILES']=met.CID.map(mm.SMILES);met['Molecular_formula']=met.CID.map(mm['分子式\nMolecularFormula'])
save(nd,'图10_全部节点.csv');save(ed,'图10_全部连线.csv');save(pd.DataFrame(evidence),'图10_每条连线原始证据.csv');save(met,'图11A_代谢物度值与前四名.csv');save(gm,'图10_人类菌代谢物证据.csv')
for f in [evsrc,psrc]:shutil.copy2(f,OUT/'原始数据'/f.name)
m.to_csv(OUT/'原始数据/228个有结构人相关代谢物输入.csv',encoding='utf-8-sig',index=False)
report={'nodes':len(nd),'edges':len(ed),'node_types':nd.Type.value_counts().to_dict(),'edge_types':ed.Relation.value_counts().to_dict(),'eligible_metabolites':met[['Label','CID','Degree','Selected_for_docking']].to_dict('records'),'excluded_metabolites':sorted(set(ev[ev.Association_category.eq('Microbial metabolite-host gene')].Entity)-set(met.Label)),'microbe_taxonomy':'Original NCBI taxon IDs. Two missing IDs receive distinct synthetic NAME keys derived from original names; TaxID remains blank. No inferred species/genus collapsing.','degree':'Number of distinct adjacent nodes in the undirected curated network; evidence duplicates collapsed','top4_ties':'Degree descending, numeric PubChem CID ascending','source_workbook':str(src)}
(OUT/'处理记录/network_protocol.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
