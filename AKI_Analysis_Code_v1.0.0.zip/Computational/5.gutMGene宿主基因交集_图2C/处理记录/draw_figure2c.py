from pathlib import Path
import sys,json,argparse
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录'
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib import font_manager
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');args=parser.parse_args()
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
font_manager.findfont('Arial',fallback_to_default=False);font_manager.findfont('Times New Roman',fallback_to_default=False)
palette={'previous_targets':'#F6B7AE','gutMGene':'#B8E4ED','intersection':'#EDE1E1'}
size=(4.6,4.6*264/440)
fig=plt.figure(figsize=size,dpi=150,facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,440),ylim=(264,0));ax.set_aspect('equal');ax.axis('off')
left=Circle((165,122),98,facecolor=palette['previous_targets'],edgecolor='none',zorder=1)
right=Circle((244,122),98,facecolor=palette['gutMGene'],edgecolor='none',zorder=1)
ax.add_patch(left);ax.add_patch(right)
lens=Circle((244,122),98,facecolor=palette['intersection'],edgecolor='none',zorder=2);lens.set_clip_path(left);ax.add_patch(lens)
texts=[]
for x,n in [(107,s['previous_only']),(204.5,s['intersection']),(302,s['gutMGene_only'])]:
    texts.append(ax.text(x,122,str(n),ha='center',va='center',fontsize=11.5,fontfamily='Arial',color='black',zorder=3))
texts.append(ax.text(119,239,f"{s['previous_targets']} targets",ha='center',va='center',fontsize=12,fontfamily='Arial',color='black'))
texts.append(ax.text(310,239,'targets of gut microbiota',ha='center',va='center',fontsize=12,fontfamily='Arial',color='black'))
texts.append(ax.text(20,27,'C',ha='left',va='center',fontsize=16,fontfamily='Times New Roman',color='black'))
fig.canvas.draw();issues=audit_layout(fig);assert not any(level=='FAIL' for level,msg in issues),issues
renderer=fig.canvas.get_renderer();boxes=[t.get_window_extent(renderer) for t in texts]
collisions=[[i,j] for i,a in enumerate(boxes) for j,b in enumerate(boxes) if j>i and a.overlaps(b)]
assert not collisions,collisions
render_preview(fig,str(AUDIT/'figure2c_preview.png'),dpi=180)
report={'counts':{k:s[k] for k in ['previous_targets','gutMGene_human_genes','intersection','previous_only','gutMGene_only','union']},
    'labels':[f"{s['previous_targets']} targets",'targets of gut microbiota','C'],'size_inches':list(size),'dpi':600,
    'palette':palette,'area_proportional':False,'fonts':['Arial','Times New Roman'],'minimum_font_pt':11.5,
    'layout_issues':issues,'text_overlap_pairs':collisions,'matplotlib_version':matplotlib.__version__}
if args.export:
    report['exports']=export_figure(fig,str(ROOT/s['figure']),formats=['png','pdf','svg'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
    Image.open(ROOT/(s['figure']+'.png')).convert('L').save(AUDIT/'figure2c_grayscale.png',dpi=(600,600))
(AUDIT/'figure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
plt.close(fig)
print(json.dumps({'counts':report['counts'],'layout_issues':issues,'text_overlap_pairs':collisions,'exported':args.export},ensure_ascii=True))
