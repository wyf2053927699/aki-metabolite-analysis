from pathlib import Path
from collections import defaultdict,Counter
import csv,io,json,re,hashlib,math,xml.etree.ElementTree as ET
import openpyxl
from PIL import Image
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录';RAW=ROOT/'原始数据'
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'))
checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:print('FAILED',name,detail)
check('452基因输入哈希未改变',hashlib.sha256(Path(s['previous_input']['path']).read_bytes()).hexdigest()==s['previous_input']['sha256'])
pw=openpyxl.load_workbook(s['previous_input']['path'],read_only=True,data_only=True)['交集靶点']
prior={i:r for i,r in enumerate(pw.iter_rows(min_row=8,max_col=26,values_only=True),8) if r[0]}
A={str(r[0]).strip() for r in prior.values()}
human=[];source_counts={}
for src in s['sources']:
    p=RAW/src['file'];b=p.read_bytes();meta=json.loads(p.with_suffix(p.suffix+'.provenance.json').read_text(encoding='utf-8'))
    check('官方原始CSV哈希：'+p.name,hashlib.sha256(b).hexdigest()==src['sha256']==meta['sha256'])
    raw=list(csv.DictReader(io.StringIO(b.decode('gb18030'),newline='')))
    hs=[(i,r) for i,r in enumerate(raw,2) if r['human/mouse'].strip()=='human'];source_counts[p.name]=len(hs)
    check('来源记录计数：'+p.name,len(raw)==src['all_records'] and len(hs)==src['human_records'])
    human.extend({'file':p.name,'source_record':i,**r} for i,r in hs)
G={r['Gene'].strip() for r in human};I=A&G
check('238个人类基因及508条记录完整',len(G)==s['gutMGene_human_genes']==238 and len(human)==508)
check('两类人类记录数对应官方表',source_counts=={'Gut Microbe-Host Gene.csv':243,'Microbial metabolite-Host Gene.csv':265})
check('集合真实交集为49个基因',len(A)==452 and len(I)==s['intersection']==49 and len(A-G)==403 and len(G-A)==189 and len(A|G)==641)
inter=list(csv.DictReader((ROOT/'图2C_交集靶点_49个.csv').open(encoding='utf-8-sig',newline='')))
genes=list(csv.DictReader((ROOT/'gutMGene_v2_人类宿主基因_238个.csv').open(encoding='utf-8-sig',newline='')))
evidence=list(csv.DictReader((ROOT/'gutMGene_v2_人类关联证据_508条.csv').open(encoding='utf-8-sig',newline='')))
check('交集CSV准确且不重复',len(inter)==len({r['Gene_symbol'] for r in inter})==49 and {r['Gene_symbol'] for r in inter}==I)
check('宿主基因CSV完整且不重复',len(genes)==len({r['Gene_symbol'] for r in genes})==238 and {r['Gene_symbol'] for r in genes}==G)
check('人类关联证据只保留human',len(evidence)==508 and {r['Host_species'] for r in evidence}=={'human'})
expected_keys={(r['file'],r['source_record']) for r in human}
actual_keys={(r['Source_file'],int(r['Source_CSV_record'])) for r in evidence}
check('全部原始人类关联一对一保留',len(evidence)==len(actual_keys) and expected_keys==actual_keys)
raw_by_key={(r['file'],r['source_record']):r for r in human}
check('基因ID和PMID及原始关联模式未改变',all(
    r['Gene_symbol']==raw_by_key[(r['Source_file'],int(r['Source_CSV_record']))]['Gene'].strip()
    and r['Gene_ID']==raw_by_key[(r['Source_file'],int(r['Source_CSV_record']))]['Gene ID']
    and r['PMID']==raw_by_key[(r['Source_file'],int(r['Source_CSV_record']))]['PMID']
    and r['Association_mode']==raw_by_key[(r['Source_file'],int(r['Source_CSV_record']))]['Associative mode']
    for r in evidence))
by_gene=defaultdict(list)
for r in human:by_gene[r['Gene'].strip()].append(r)
check('宿主基因汇总记录数与PMID数准确',all(int(r['Evidence_record_count'])==len(by_gene[r['Gene_symbol']]) and int(r['PMID_count'])==len({v['PMID'] for v in by_gene[r['Gene_symbol']] if v['PMID']}) for r in genes))
check('49个交集对应143条关联记录',sum(r['Gene_symbol'] in I for r in evidence)==s['intersection_evidence_records']==143)
check('452原表来源行可追溯',all(prior[int(r['Previous_452_input_row'])][0]==r['Gene_symbol'] for r in inter))
check('预测靶点编号沿用前步结果',all(prior[int(r['Previous_452_input_row'])][4]==r['SEA_UniProt_entry'] and prior[int(r['Previous_452_input_row'])][5]==r['STP_UniProt_IDs'] and prior[int(r['Previous_452_input_row'])][6]==r['STP_ChEMBL_IDs'] for r in inter))
check('三个TXT集合清单正确',all(set((ROOT/f'{name}_{len(ge)}个.txt').read_text(encoding='utf-8-sig').splitlines())==ge for name,ge in [('图2C_交集基因',I),('前步452靶点独有基因',A-G),('gutMGene人类宿主基因独有',G-A)]))

wb=openpyxl.load_workbook(ROOT/s['workbook'],data_only=False);cache=openpyxl.load_workbook(ROOT/s['workbook'],data_only=True)
specs=[('49个交集靶点','intersection',['Gene_symbol','Gene_name','gutMGene_Gene_IDs','Evidence_categories','Evidence_record_count','PMID_count','PMIDs','Association_modes','Disease_database_source','SEA_UniProt_entry','STP_UniProt_IDs','STP_ChEMBL_IDs','GeneCards_relevance_score','SEA_min_P','STP_max_Probability','SEA_max_MaxTC','SEA_metabolite_count','STP_metabolite_count','Previous_452_input_row','OMIM_MIM','OMIM_Entrez_ID','SEA_min_P_raw','Disease_input_row']),
       ('238个人类宿主基因','genes',['Gene_symbol','gutMGene_Gene_IDs','Evidence_categories','Evidence_record_count','PMID_count','PMIDs','Direct_microbe_record_count','Metabolite_record_count','Direct_microbe_count','Metabolite_count','Association_modes','In_previous_452']),
       ('508条人类关联证据','evidence',['Gene_symbol','Gene_ID','Association_category','Entity','Entity_ID','PMID','Association_mode','Alteration','Throughput','Host_species','Sample','Condition','Experimental_method','Source_file','Source_CSV_record','In_49_gene_intersection'])]
check('工作表结构完整',wb.sheetnames==[v[0] for v in specs])
def clean(v):return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',lambda m:'\\u'+format(ord(m[0]),'04x'),v.replace('\r\n','\n').replace('\r','\n')) if isinstance(v,str) else v
for name,key,fields in specs:
    ws=wb[name];data=payload[key];idx={f:i for i,f in enumerate(data['fields'])}
    expected=[[clean(r[idx[f]]) for f in fields] for r in data['rows']]
    actual=list(ws.iter_rows(min_row=8,max_row=len(expected)+7,max_col=len(fields),values_only=True))
    def same(a,b):
        if b is None or b=='':return a is None or a==''
        if isinstance(b,float):return isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-14,abs_tol=1e-260)
        return a==b
    check(name+'：所有导出值正确',len(actual)==len(expected) and all(all(same(a,b) for a,b in zip(ra,rb)) for ra,rb in zip(actual,expected)))
    check(name+'：原生筛选表范围完整',len(ws.tables)==1 and next(iter(ws.tables.values())).ref==f'A7:{openpyxl.utils.get_column_letter(len(fields))}{len(expected)+7}')
    check(name+'：汇总公式与缓存准确',ws['B6'].data_type=='f' and cache[name]['B6'].value==len(expected))
    check(name+'：标识为文本及冻结表头',str(ws.freeze_panes)=='B8' and all(ws.cell(i,1).data_type=='s' for i in range(8,len(expected)+8)))
    check(name+'：无Excel错误值',not any(c.data_type=='e' for row in ws for c in row))
    check(name+'：预览已生成',(AUDIT/f'preview_{key}.png').stat().st_size>10000)
fa=json.loads((AUDIT/'figure_audit.json').read_text(encoding='utf-8'))
check('绘图数字对应真实集合',fa['counts']=={k:s[k] for k in ['previous_targets','gutMGene_human_genes','intersection','previous_only','gutMGene_only','union']})
check('图中无字体错误裁切或文字重叠',not fa['layout_issues'] and not fa['text_overlap_pairs'])
im=Image.open(ROOT/(s['figure']+'.png'));size=fa['size_inches']
check('PNG达到600dpi及目标尺寸',min(im.info['dpi'])>599 and all(abs(got-dim*600)<=1 for got,dim in zip(im.size,size)),im.size)
svg=ET.parse(ROOT/(s['figure']+'.svg'));texts={''.join(e.itertext()).strip() for e in svg.iter() if e.tag.endswith('}text')}
check('SVG标注正确且不含论文原始47',{'403','49','189','452 targets','targets of gut microbiota','C'}<=texts and '47' not in texts)
check('SVG保持纯矢量',not any(e.tag.endswith('}image') for e in svg.iter()))
pdf=PdfReader(ROOT/(s['figure']+'.pdf'));font_report=[]
for name,ref in pdf.pages[0]['/Resources']['/Font'].get_object().items():
    font=ref.get_object();desc=font.get('/DescendantFonts');leaves=[f.get_object() for f in desc] if desc else [font];embedded=[]
    for leaf in leaves:
        fd=leaf.get('/FontDescriptor');fd=fd.get_object() if fd else {};embedded.append(any(k in fd for k in ['/FontFile','/FontFile2','/FontFile3']))
    font_report.append({'font':str(font.get('/BaseFont')),'embedded':all(embedded)})
check('PDF字体实际嵌入',bool(font_report) and all(f['embedded'] for f in font_report),font_report)
check('PDF尺寸正确',abs(float(pdf.pages[0].mediabox.width)/72-size[0])<0.001 and abs(float(pdf.pages[0].mediabox.height)/72-size[1])<0.001)
check('最终PDF已独立渲染复核',(AUDIT/'最终PDF渲染核对.png').stat().st_size>10000)
(AUDIT/'pdf_font_audit.json').write_text(json.dumps(font_report,ensure_ascii=False,indent=2),encoding='utf-8')
report={'all_passed':all(r['passed'] for r in checks),'n_checks':len(checks),'checks':checks,'counts':fa['counts'],
        'visual_review':'Reference Figure 2C and final PNG, PDF render and grayscale reviewed. All three workbook sheets reviewed.',
        'scope':'Human host genes from both gutMGene v2.0 association exports; causally/correlatively annotations retained separately.',
        'Excel_text_normalization':'Two Condition cells contain original CRLF line breaks, normalized to LF in Excel. Original CSV and extracted human CSV preserve the source text.'}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_passed':report['all_passed'],'n_checks':len(checks),'failed':[r for r in checks if not r['passed']]},ensure_ascii=True,indent=2))
assert report['all_passed']
