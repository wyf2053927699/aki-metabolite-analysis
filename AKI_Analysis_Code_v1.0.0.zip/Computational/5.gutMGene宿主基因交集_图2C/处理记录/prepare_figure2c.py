from pathlib import Path
from collections import defaultdict,Counter
import csv,io,json,re,hashlib,sys
import openpyxl
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录';RAW=ROOT/'原始数据'
previous=ROOT.parent/'4.代谢物与疾病交集/代谢物_AKI_交集靶点.xlsx'
paper=Path(r'.\local_workspace\s40643-026-01083-8_translated.pdf.pdf')
wb=openpyxl.load_workbook(previous,read_only=True,data_only=True);ws=wb['交集靶点']
header=next(ws.iter_rows(min_row=7,max_row=7,max_col=26,values_only=True))
prior={}
for rownum,row in enumerate(ws.iter_rows(min_row=8,max_col=26,values_only=True),8):
    if row[0] is None:continue
    record=dict(zip(header,row));symbol=str(record['基因符号']).strip();assert symbol not in prior
    prior[symbol]=(rownum,record)
source_specs=[('Gut Microbe-Host Gene.csv','Gut microbe-host gene'),('Microbial metabolite-Host Gene.csv','Microbial metabolite-host gene')]
evidence=[];sources=[];human_by_source={};gene_evidence=defaultdict(list)
for filename,category in source_specs:
    p=RAW/filename;content=p.read_bytes();provenance=json.loads(p.with_suffix(p.suffix+'.provenance.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(content).hexdigest()==provenance['sha256']
    reader=csv.DictReader(io.StringIO(content.decode('gb18030'),newline=''));source_header=reader.fieldnames
    all_records=list(reader);human=[]
    for original_row,r in enumerate(all_records,2):
        if r['human/mouse'].strip()!='human':continue
        symbol=r['Gene'].strip();assert re.fullmatch(r'[A-Za-z0-9_.-]+',symbol)
        is_microbe=filename.startswith('Gut Microbe')
        er={'Gene_symbol':symbol,'Gene_ID':r['Gene ID'],'Association_category':category,
            'Entity':r['Gut Microbiota'] if is_microbe else r['Metabolite'],
            'Entity_ID':r['Gut Microbiota NCBI ID'] if is_microbe else r['Metabolite PubChem CID'],
            'PMID':r['PMID'],'Association_mode':r['Associative mode'],'Alteration':r['Alteration'],
            'Throughput':r['high/low-throughput'],'Host_species':r['human/mouse'],
            'Sample':r['Sample'],'Condition':r['Condition'],'Experimental_method':r['Experimental method'],
            'Source_file':filename,'Source_CSV_record':original_row,'In_49_gene_intersection':symbol in prior}
        evidence.append(er);gene_evidence[symbol].append(er);human.append(r)
    human_by_source[filename]=human
    with (AUDIT/(filename.removesuffix('.csv')+'_human_original_fields.csv')).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=source_header);writer.writeheader();writer.writerows(human)
    sources.append({'file':filename,'sha256':hashlib.sha256(content).hexdigest(),'url':provenance['url'],
        'retrieved_utc':provenance['retrieved_utc'],'all_records':len(all_records),'human_records':len(human),
        'human_unique_genes':len({r['Gene'].strip() for r in human})})
A=set(prior);G=set(gene_evidence);I=A&G
def joined(values):return ' | '.join(dict.fromkeys(str(v) for v in values if v is not None and str(v)!=''))
genes=[]
for symbol,ers in sorted(gene_evidence.items()):
    microbe=[r for r in ers if r['Association_category']=='Gut microbe-host gene']
    metabolite=[r for r in ers if r['Association_category']=='Microbial metabolite-host gene']
    genes.append({'Gene_symbol':symbol,'gutMGene_Gene_IDs':joined(sorted({r['Gene_ID'] for r in ers if r['Gene_ID']})),
        'Evidence_categories':joined(r['Association_category'] for r in ers),
        'Evidence_record_count':len(ers),'PMID_count':len({r['PMID'] for r in ers if r['PMID']}),
        'PMIDs':joined(sorted({r['PMID'] for r in ers if r['PMID']})),
        'Direct_microbe_record_count':len(microbe),'Metabolite_record_count':len(metabolite),
        'Direct_microbe_count':len({r['Entity'] for r in microbe}),
        'Metabolite_count':len({r['Entity'] for r in metabolite}),
        'Association_modes':joined(sorted({r['Association_mode'] for r in ers if r['Association_mode']})),
        'In_previous_452':symbol in A})
gene_map={r['Gene_symbol']:r for r in genes};inter=[]
for symbol in sorted(I):
    rownum,p=prior[symbol];g=gene_map[symbol]
    inter.append({**g,'Gene_name':p['基因名称'],'Disease_database_source':p['疾病数据库来源'],
        'SEA_UniProt_entry':p['SEA UniProt Entry'],'STP_UniProt_IDs':p['STP UniProt编号'],
        'STP_ChEMBL_IDs':p['STP ChEMBL靶点编号'],'GeneCards_relevance_score':p['GeneCards相关性评分'],
        'OMIM_MIM':p['OMIM MIM编号'],'OMIM_Entrez_ID':p['OMIM Entrez ID'],
        'SEA_min_P':p['SEA最小P值'],'STP_max_Probability':p['STP最大Probability'],'SEA_max_MaxTC':p['SEA最大MaxTC'],
        'SEA_metabolite_count':p['SEA关联代谢物数'],'STP_metabolite_count':p['STP关联代谢物数'],
        'Previous_452_input_row':rownum,'Disease_input_row':p['疾病合并输入表行号'],
        'SEA_min_P_raw':p['SEA最小P值原始文本'],'Shared_annotation_note':p['共享基因注释说明']})
summary={'previous_input':{'path':str(previous),'sha256':hashlib.sha256(previous.read_bytes()).hexdigest()},
    'reference_paper':{'path':str(paper),'sha256':hashlib.sha256(paper.read_bytes()).hexdigest(),'figure':'2C','pages':[5,6]},
    'sources':sources,'gutMGene_version':'2.0','gutMGene_scope':'Union of literature-curated human gut microbe-host gene and microbial metabolite-host gene exports',
    'previous_targets':len(A),'gutMGene_human_genes':len(G),'intersection':len(I),'previous_only':len(A-G),'gutMGene_only':len(G-A),'union':len(A|G),
    'human_evidence_records':len(evidence),'intersection_evidence_records':sum(r['Gene_symbol'] in I for r in evidence),
    'comparison_unit':'Existing gene symbol; trim outer whitespace; exact match; no alias inference or case conversion',
    'human_only':True,'association_mode_filter':'none; retain causally and correlatively annotated records',
    'additional_score_filter':'none','figure_geometry':'Reference-matched equal circles; areas not proportional',
    'original_paper_gut_targets':224,'original_paper_intersection':47,
    'workbook':f'图2C_{len(I)}个交集靶点.xlsx','figure':'图2C_gutMGene宿主基因交集',
    'official_database_publication':'https://academic.oup.com/nar/article/53/D1/D783/7850954'}
def csvout(name,rows):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvout(f'图2C_交集靶点_{len(I)}个.csv',inter);csvout(f'gutMGene_v2_人类宿主基因_{len(G)}个.csv',genes)
csvout('gutMGene_v2_人类关联证据_508条.csv',evidence)
for name,symbols in [('图2C_交集基因',I),('前步452靶点独有基因',A-G),('gutMGene人类宿主基因独有',G-A)]:
    (ROOT/f'{name}_{len(symbols)}个.txt').write_text('\n'.join(sorted(symbols))+'\n',encoding='utf-8-sig')
payload={'summary':summary}
for key,data in [('intersection',inter),('genes',genes),('evidence',evidence)]:
    payload[key]={'fields':list(data[0]),'rows':[list(r.values()) for r in data]}
(AUDIT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (AUDIT/'gene_membership.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Gene_symbol','Previous_452','gutMGene_human'])
    for symbol in sorted(A|G):w.writerow([symbol,symbol in A,symbol in G])
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
from profile_data import profile_data,render_report
(AUDIT/'data_profile.txt').write_text(render_report(profile_data(str(AUDIT/'gene_membership.csv'),group_cols=[])),encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['previous_targets','gutMGene_human_genes','intersection','previous_only','gutMGene_only','human_evidence_records','intersection_evidence_records']},ensure_ascii=True,indent=2))
