from pathlib import Path
import csv, json, math, hashlib, shutil, collections, xml.etree.ElementTree as ET

BASE = Path(r'.\Computational')
ROOT = BASE / '6.图2D_代谢物靶点疾病网络'
AUDIT = ROOT / '处理记录'
EDIT = ROOT / 'Cytoscape可编辑网络'
INPUT = BASE / '5.gutMGene宿主基因交集_图2C' / '图2C_交集靶点_49个.csv'
REFERENCE = Path(r'.\local_workspace\s40643-026-01083-8_translated.pdf.pdf')
for folder in (ROOT, AUDIT, EDIT):
    folder.mkdir(parents=True, exist_ok=True)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

with INPUT.open(encoding='utf-8-sig', newline='') as f:
    genes = list(csv.DictReader(f))
genes.sort(key=lambda r: r['Gene_symbol'])
assert len(genes) == len({r['Gene_symbol'] for r in genes}) == 49
float_fields = {'GeneCards_relevance_score', 'SEA_min_P', 'STP_max_Probability', 'SEA_max_MaxTC'}
int_fields = {'Evidence_record_count','PMID_count','Direct_microbe_record_count','Metabolite_record_count',
              'Direct_microbe_count','Metabolite_count','SEA_metabolite_count','STP_metabolite_count',
              'Previous_452_input_row','Disease_input_row'}
for r in genes:
    for k in float_fields | int_fields:
        if r[k] != '':
            r[k] = float(r[k]) if k in float_fields else int(r[k])
    r['In_previous_452'] = r['In_previous_452'] == 'True'

# Reference Figure 2D uses two orange set nodes and purple gene nodes.
# The associations below are set memberships, not compound-specific or PPI edges.
palette = {'gene':'#9C95F4', 'set':'#F9A63A', 'edge':'#777777', 'text':'#141414'}
radius = 3.35
inner_radius = 2.58
gene_diameter = 0.61
nodes = [
    {'id':'METABOLITE_SET','label':'Gut microbiota\nmetabolites','node_type':'metabolite_set',
     'degree':49,'x':0.0,'y':-68.4,'width':140.4,'height':67.68,'fill':palette['set'],'shape':'OCTAGON',
     'set_definition':'SEA and STP intersection; restricted to AKI and human gutMGene shared genes'},
    {'id':'AKI_SET','label':'Acute kidney\ninjury','node_type':'disease_set',
     'degree':49,'x':0.0,'y':68.4,'width':140.4,'height':67.68,'fill':palette['set'],'shape':'OCTAGON',
     'set_definition':'OMIM and GeneCards union; restricted to metabolite and human gutMGene shared genes'}
]
for i, r in enumerate(genes):
    # Staggered rings follow the reference and give long labels more space.
    # With 49 genes, use separately uniform 25-node and 24-node rings.
    j = i//2
    count = 25 if i%2==0 else 24
    a = math.pi/2 - (j+(0 if i%2==0 else .5))*2*math.pi/count
    ring_radius = radius if i%2==0 else inner_radius
    nodes.append({'id':r['Gene_symbol'],'label':r['Gene_symbol'],'node_type':'gene','degree':2,
                  'x':round(72*ring_radius*math.cos(a),6),'y':round(-72*ring_radius*math.sin(a),6),
                  'width':gene_diameter*72,'height':gene_diameter*72,'fill':palette['gene'],
                  'shape':'ELLIPSE','set_definition':'Shared candidate gene from Figure 2C',**r})

edges = []
for r in genes:
    g = r['Gene_symbol']
    for source, relation, zh, dataset, rowfield in [
        ('METABOLITE_SET','predicted_target_set_membership','代谢物预测靶点集合成员',
         'SEA_STP_交集靶点.xlsx', 'Previous_452_input_row'),
        ('AKI_SET','disease_target_set_membership','AKI疾病靶点集合成员',
         '疾病靶点_OMIM_GeneCards_合并去重.xlsx', 'Disease_input_row')
    ]:
        edges.append({'id':f'{source}__{g}','source':source,'target':g,'interaction':relation,
                      '关系说明':zh,'directed':False,'source_dataset':dataset,
                      'Figure2C_input_CSV_record':genes.index(r)+1,
                      'Previous_452_input_row':r['Previous_452_input_row'],
                      'Disease_input_row':r['Disease_input_row'],
                      'evidence_scope':'Membership in the input gene sets; not a measured molecular interaction',
                      'disease_database_source':r['Disease_database_source'] if source=='AKI_SET' else '',
                      'SEA_UniProt_entry':r['SEA_UniProt_entry'] if source=='METABOLITE_SET' else '',
                      'STP_ChEMBL_IDs':r['STP_ChEMBL_IDs'] if source=='METABOLITE_SET' else ''})

def write_csv(p, rows, fields=None):
    fields = fields or list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    return fields

node_fields = write_csv(ROOT/'图2D_节点表_51个.csv', nodes)
edge_fields = write_csv(ROOT/'图2D_连线表_98条.csv', edges)
write_csv(EDIT/'节点坐标与样式.csv', [{k:n[k] for k in ['id','label','node_type','x','y','width','height','fill','shape']} for n in nodes])

# XGMML is a native Cytoscape-supported exchange format carrying node/edge
# attributes, coordinates, and graphics. XML escaping is handled by ElementTree.
NS = 'http://www.cs.rpi.edu/XGMML'
ET.register_namespace('', NS)
ET.register_namespace('cy', 'http://www.cytoscape.org')
tag = lambda s: f'{{{NS}}}{s}'
graph = ET.Element(tag('graph'), {'label':'Figure 2D - AKI shared target network','directed':'0',
                                '{http://www.cytoscape.org}documentVersion':'3.0'})
ET.SubElement(graph, tag('att'), {'name':'description','type':'string',
             'value':'49 shared candidate genes connected to two input sets. All edges represent set membership.'})
node_index = {n['id']:str(i+1) for i,n in enumerate(nodes)}
def add_att(parent, key, value):
    if value is None or value == '':
        return
    typ = 'boolean' if isinstance(value,bool) else 'integer' if isinstance(value,int) else 'real' if isinstance(value,float) else 'string'
    val = str(value).lower() if isinstance(value,bool) else str(value)
    ET.SubElement(parent, tag('att'), {'name':key,'type':typ,'value':val})

for n in nodes:
    elem = ET.SubElement(graph, tag('node'), {'id':node_index[n['id']],'label':n['label']})
    for k,v in n.items():
        add_att(elem,k,v)
    ET.SubElement(elem, tag('graphics'), {'x':str(n['x']),'y':str(n['y']),'z':'0.0',
        'w':str(n['width']),'h':str(n['height']),'fill':n['fill'],'outline':'#FFFFFF','width':'0.8',
        'type':'ELLIPSE' if n['node_type']=='gene' else 'OCTAGON'})
for i,e in enumerate(edges,1):
    elem = ET.SubElement(graph, tag('edge'), {'id':str(1000+i),'source':node_index[e['source']],
                                            'target':node_index[e['target']],'label':e['id']})
    for k,v in e.items():
        add_att(elem,k,v)
    ET.SubElement(elem, tag('graphics'), {'fill':palette['edge'],'width':'0.65'})
ET.indent(graph,space='  ')
ET.ElementTree(graph).write(EDIT/'图2D_49基因网络.xgmml',encoding='utf-8',xml_declaration=True)

cyjs = {'data':{'name':'Figure 2D - AKI shared target network'},'directed':False,
        'elements':{'nodes':[{'data':n,'position':{'x':n['x'],'y':n['y']}} for n in nodes],
                    'edges':[{'data':e} for e in edges]}}
(EDIT/'图2D_49基因网络.cyjs').write_text(json.dumps(cyjs,ensure_ascii=False,indent=2),encoding='utf-8')

# Cytoscape desktop visual style JSON (not Cytoscape.js CSS).
style = [{'title':'Figure2D_AKI_reference','dependencies':[
    {'visualPropertyDependency':'nodeSizeLocked','value':False},
    {'visualPropertyDependency':'arrowColorMatchesEdge','value':True}], 'defaults':[
    {'visualProperty':'NODE_LABEL','value':''},
    {'visualProperty':'NODE_FILL_COLOR','value':palette['gene']},
    {'visualProperty':'NODE_BORDER_PAINT','value':'#FFFFFF'},
    {'visualProperty':'NODE_BORDER_WIDTH','value':0.8},
    {'visualProperty':'NODE_LABEL_COLOR','value':palette['text']},
    {'visualProperty':'NODE_LABEL_FONT_SIZE','value':9},
    {'visualProperty':'NODE_LABEL_WIDTH','value':120},
    {'visualProperty':'NODE_LABEL_FONT_FACE','value':'Arial,plain,12'},
    {'visualProperty':'EDGE_STROKE_UNSELECTED_PAINT','value':palette['edge']},
    {'visualProperty':'EDGE_TRANSPARENCY','value':155},
    {'visualProperty':'EDGE_WIDTH','value':0.65},
    {'visualProperty':'EDGE_SOURCE_ARROW_SHAPE','value':'NONE'},
    {'visualProperty':'EDGE_TARGET_ARROW_SHAPE','value':'NONE'},
    {'visualProperty':'NETWORK_BACKGROUND_PAINT','value':'#FFFFFF'}],
    'mappings':[
    {'mappingType':'passthrough','mappingColumn':'label','mappingColumnType':'String','visualProperty':'NODE_LABEL'},
    *[{'mappingType':'discrete','mappingColumn':'node_type','mappingColumnType':'String',
       'visualProperty':vp,'map':[{'key':kind,'value':val} for kind,val in vals.items()]}
      for vp,vals in {
          'NODE_FILL_COLOR':{'gene':palette['gene'],'metabolite_set':palette['set'],'disease_set':palette['set']},
          'NODE_SHAPE':{'gene':'ELLIPSE','metabolite_set':'OCTAGON','disease_set':'OCTAGON'},
          'NODE_WIDTH':{'gene':gene_diameter*72,'metabolite_set':140.4,'disease_set':140.4},
          'NODE_HEIGHT':{'gene':gene_diameter*72,'metabolite_set':67.68,'disease_set':67.68},
          'NODE_LABEL_FONT_SIZE':{'gene':9,'metabolite_set':12,'disease_set':12}
      }.items()]]}]
(EDIT/'Cytoscape_配色样式.json').write_text(json.dumps(style,ensure_ascii=False,indent=2),encoding='utf-8')

summary = {'input':{'path':str(INPUT),'sha256':sha(INPUT)},
           'reference':{'path':str(REFERENCE),'sha256':sha(REFERENCE),'figure':'2D','PDF_page':5},
           'genes':49,'nodes':51,'edges':98,'gene_nodes':49,'set_nodes':2,
           'edge_semantics':'Undirected membership in metabolite-prediction and disease-target input sets',
           'individual_metabolites_shown':False,'PPI_edges_added':False,'extra_filter_applied':False,
           'node_order':'Alphabetical within each clockwise ring; outer ring starts at 12 oclock; inner ring has a half-slot offset','palette':palette,
           'reference_palette_note':'Purple and orange visually matched to the supplied translated Figure 2D',
           'layout':{'type':'two staggered rings and two central octagons','outer_radius_inches':radius,'inner_radius_inches':inner_radius,
                     'gene_diameter_inches':gene_diameter,'coordinate_units':'points; y increases downwards'},
           'figure':'图2D_肠道菌群代谢物_靶点_AKI网络','workbook':'图2D_网络节点与连线.xlsx',
           'Cytoscape_format_documentation':'https://manual.cytoscape.org/en/latest/Supported_Network_File_Formats.html'}
payload = {'summary':summary,'nodes':{'fields':node_fields,'rows':[[n.get(k,None) for k in node_fields] for n in nodes]},
           'edges':{'fields':edge_fields,'rows':[[e.get(k,None) for k in edge_fields] for e in edges]}}
(AUDIT/'network_data.json').write_text(json.dumps({'nodes':nodes,'edges':edges},ensure_ascii=False,indent=2),encoding='utf-8')
(AUDIT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(INPUT,AUDIT/'输入_图2C_49个交集基因.csv')
shutil.copy2(Path(r'.\local_workspace\.codex-work\paper_figure2c\reference_2D_crop.png'),AUDIT/'参考论文_图2D.png')

readme = '''图2D：肠道菌群代谢物—候选靶点—急性肾损伤网络

一、结果
依据前一步图2C的49个交集基因绘图，共51个节点、98条无方向连线。
紫色圆形：49个交集候选基因。橙色八边形：肠道菌群代谢物靶点集、AKI疾病靶点集。
各基因分别连接两个集合节点，各有2条边。该结构用于展示集合归属，节点度数不用于筛选枢纽基因。

二、数据和连线含义
49个基因来自452个代谢物/AKI交集基因与238个gutMGene v2.0人类宿主基因的交集。
METABOLITE_SET—基因：该基因属于SEA与STP共同预测的代谢物靶点集合。
AKI_SET—基因：该基因属于OMIM与GeneCards合并的AKI检索靶点集合。
gutMGene人类宿主基因的筛选依据和PMID等证据保留在节点属性中。
连线表示输入集合成员关系；本图不表示单个代谢物的直接结合、作用方向或蛋白互作。
本轮未增加筛选阈值，未添加PPI边，也未将参考论文的47个基因套用于本项目。

三、配色和排版
参照所给论文图2D的紫色基因与橙色集合节点。
49个基因交错排列于两圈，大小一致。外圈25个、内圈24个，每圈内按字母顺序顺时针等距排列。
两个中心节点扩大并分行标注；细灰线置于节点后方，避免覆盖标签。
PNG为600 dpi，PDF/SVG为矢量文件；SVG保留文本以便修改。

四、Cytoscape继续编辑
推荐导入 Cytoscape可编辑网络/图2D_49基因网络.xgmml。
File > Import > Network from File，选择该文件。文件包含节点、连线、属性、位置与基础配色。
如需重新应用完整样式，File > Import > Styles from File 导入 Cytoscape_配色样式.json，
然后选择 Figure2D_AKI_reference。保留导入坐标即可维持环形布局。
另存cyjs、节点坐标CSV和完整节点/连线CSV，便于兼容其他工具。
可导入文件已做XML/JSON结构、标识符和数量核对；本轮成图由Python生成，未在桌面Cytoscape内验收。
官方格式说明：https://manual.cytoscape.org/en/latest/Supported_Network_File_Formats.html

五、复现
处理记录内保存准备数据、绘图、Excel导出、校验脚本与输入哈希。
先运行prepare_figure2d.py，再运行draw_figure2d.py；检查预览后加--export导出。
Excel导出使用build_figure2d_workbook.mjs；最后运行validate_figure2d.py。
'''
(ROOT/'README_先看这里.txt').write_text(readme,encoding='utf-8-sig')
(AUDIT/'data_profile.txt').write_text(
    f'Input: {len(genes)} rows; {len({r["Gene_symbol"] for r in genes})} unique gene symbols; no blank symbols.\n'
    f'Network: {len(nodes)} unique nodes, {len(edges)} unique undirected edges.\n'
    'Node types: gene=49, metabolite_set=1, disease_set=1.\n'
    'No quantitative edge weights are used; all gene node degrees are 2 by construction.\n'
    'Ring order is alphabetical, not an evidence or biological ranking.\n',encoding='utf-8')
print(json.dumps({'output':str(ROOT),'nodes':len(nodes),'edges':len(edges),'genes':len(genes)},ensure_ascii=True))
