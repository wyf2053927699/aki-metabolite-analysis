from pathlib import Path
import csv,json,hashlib,math,collections,xml.etree.ElementTree as ET
from openpyxl import load_workbook
from PIL import Image
from pypdf import PdfReader

ROOT=Path(r'.\Computational\6.图2D_代谢物靶点疾病网络')
AUDIT=ROOT/'处理记录';EDIT=ROOT/'Cytoscape可编辑网络'
summary=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
data=json.loads((AUDIT/'network_data.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'))
checks=[]
def check(name,passed,detail=None):
    checks.append({'check':name,'passed':bool(passed),'detail':detail})
def readcsv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def clean(v):
    return v.replace('\r\n','\n').replace('\r','\n') if isinstance(v,str) else v
def same(a,b):
    if a is None and b in (None,''):return True
    if isinstance(a,(float,int)) and not isinstance(a,bool) and isinstance(b,(float,int)):
        return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
    return clean(a)==clean(b)
input_path=Path(summary['input']['path'])
source=readcsv(input_path);node=data['nodes'];edge=data['edges']
source_genes={r['Gene_symbol'] for r in source}
node_genes={r['id'] for r in node if r['node_type']=='gene'}
ids={r['id'] for r in node};degree=collections.Counter()
for e in edge:degree.update([e['source'],e['target']])
check('Input SHA256 unchanged',hashlib.sha256(input_path.read_bytes()).hexdigest()==summary['input']['sha256'])
check('Source has 49 unique nonempty genes',len(source)==len(source_genes)==49 and '' not in source_genes)
check('Network gene set exactly equals Figure2C',node_genes==source_genes)
check('51 distinct node IDs',len(node)==len(ids)==51)
check('98 distinct edge IDs',len(edge)==len({e['id'] for e in edge})==98)
check('Two set nodes and 49 gene nodes',collections.Counter(n['node_type'] for n in node)=={'metabolite_set':1,'disease_set':1,'gene':49})
check('All edge endpoints exist',all(e['source'] in ids and e['target'] in ids for e in edge))
check('No self loops',all(e['source']!=e['target'] for e in edge))
check('No duplicate undirected edges',len({frozenset([e['source'],e['target']]) for e in edge})==98)
check('All edges undirected',all(e['directed'] is False for e in edge))
check('Only set-to-gene memberships',all(e['source'] in {'METABOLITE_SET','AKI_SET'} and e['target'] in node_genes for e in edge))
check('Every gene connected to both sets',all({e['source'] for e in edge if e['target']==g}=={'METABOLITE_SET','AKI_SET'} for g in node_genes))
check('Each gene degree 2',all(degree[g]==2 for g in node_genes))
check('Set nodes degree 49',degree['METABOLITE_SET']==degree['AKI_SET']==49)
check('Saved degree attribute correct',all(n['degree']==degree[n['id']] for n in node))
check('No isolated nodes',all(degree[n['id']]>0 for n in node))
# Compare numeric input values numerically, and every other original attribute exactly.
numeric={'GeneCards_relevance_score','SEA_min_P','STP_max_Probability','SEA_max_MaxTC','Evidence_record_count',
         'PMID_count','Direct_microbe_record_count','Metabolite_record_count','Direct_microbe_count','Metabolite_count',
         'SEA_metabolite_count','STP_metabolite_count','Previous_452_input_row','Disease_input_row'}
attribute_mismatches=[]
lookup={n['id']:n for n in node}
for r in source:
    n=lookup[r['Gene_symbol']]
    for k,v in r.items():
        expected=(float(v) if k in numeric and v!='' else v=='True' if k=='In_previous_452' else v)
        if not same(n[k],expected):attribute_mismatches.append([r['Gene_symbol'],k,n[k],expected])
check('All original gene attributes preserved with correct types',not attribute_mismatches,attribute_mismatches[:5])
check('gutMGene evidence-record count matches 143',sum(n.get('Evidence_record_count',0) for n in node)==143)

for fname,rows in [('图2D_节点表_51个.csv',node),('图2D_连线表_98条.csv',edge)]:
    exported=readcsv(ROOT/fname)
    check(f'{fname}: complete rows',len(exported)==len(rows))
    missing=[]
    for i,(a,b) in enumerate(zip(exported,rows)):
        for k,v in a.items():
            if not same(v,str(b.get(k,'')) if b.get(k) is not None else ''):missing.append((i,k))
    check(f'{fname}: exact attribute round trip',not missing,missing[:5])

NS={'x':'http://www.cs.rpi.edu/XGMML'}
xgmml=ET.parse(EDIT/'图2D_49基因网络.xgmml').getroot()
xn=xgmml.findall('x:node',NS);xe=xgmml.findall('x:edge',NS)
check('XGMML has 51 nodes / 98 edges',len(xn)==51 and len(xe)==98)
xid={n.attrib['id'] for n in xn}
check('XGMML endpoints resolve',all(e.attrib['source'] in xid and e.attrib['target'] in xid for e in xe))
check('XGMML coordinates, colors and shapes retained',all(n.find('x:graphics',NS) is not None and
    all(k in n.find('x:graphics',NS).attrib for k in ['x','y','w','h','fill','type']) for n in xn))
check('XGMML gene labels complete',source_genes<={n.attrib['label'] for n in xn})
check('XGMML is undirected',xgmml.attrib['directed']=='0')
cyjs=json.loads((EDIT/'图2D_49基因网络.cyjs').read_text(encoding='utf-8'))
check('CYJS exports identical network',cyjs['elements']['edges']==[{'data':e} for e in edge] and
    cyjs['elements']['nodes']==[{'data':n,'position':{'x':n['x'],'y':n['y']}} for n in node])
style=json.loads((EDIT/'Cytoscape_配色样式.json').read_text(encoding='utf-8'))
check('Cytoscape style has shape/size/color/label mappings',
      {'NODE_SHAPE','NODE_WIDTH','NODE_HEIGHT','NODE_FILL_COLOR','NODE_LABEL'}<=
      {m['visualProperty'] for m in style[0]['mappings']})

wb=load_workbook(ROOT/summary['workbook'],read_only=False,data_only=True)
wf=load_workbook(ROOT/summary['workbook'],read_only=False,data_only=False)
check('Workbook has exactly two intended sheets',wb.sheetnames==['51个节点','98条连线'])
node_fields=['id','label','node_type','degree','Gene_name','gutMGene_Gene_IDs','Disease_database_source',
    'SEA_UniProt_entry','STP_UniProt_IDs','STP_ChEMBL_IDs','Evidence_categories','Evidence_record_count',
    'PMID_count','PMIDs','Association_modes','GeneCards_relevance_score','SEA_min_P','STP_max_Probability',
    'SEA_max_MaxTC','SEA_metabolite_count','STP_metabolite_count','Previous_452_input_row','Disease_input_row',
    'x','y','width','height','fill','shape']
edge_fields=['id','source','target','关系说明','interaction','directed','source_dataset',
    'Figure2C_input_CSV_record','Previous_452_input_row','Disease_input_row','disease_database_source',
    'SEA_UniProt_entry','STP_ChEMBL_IDs','evidence_scope']
for name,rows,fields in [('51个节点',node,node_fields),('98条连线',edge,edge_fields)]:
    sh=wb[name];sf=wf[name];bad=[]
    for i,r in enumerate(rows,8):
        for j,k in enumerate(fields,1):
            if not same(sh.cell(i,j).value,r.get(k,None)):bad.append([i,j,k,sh.cell(i,j).value,r.get(k,None)])
    check(f'{name}: all saved cell values match exported network',not bad,bad[:6])
    check(f'{name}: row count reconciles',sh.max_row==len(rows)+7)
    check(f'{name}: summary cached result correct',sh['B6'].value==len(rows))
    check(f'{name}: table/filter present',len(sh.tables)==1 and next(iter(sh.tables.values())).autoFilter is not None)
    check(f'{name}: identifiers stored as text',all(sh.cell(i,1).data_type=='s' for i in range(8,len(rows)+8)))
    check(f'{name}: frozen headers and ID',sh.freeze_panes=='B8',sh.freeze_panes)
check('Node degree formulas saved for all 51 nodes',all(wf['51个节点'].cell(i,4).data_type=='f' for i in range(8,59)))
check('No Excel cached errors',not[(s.title,c.coordinate,c.value) for s in wb for row in s for c in row if c.data_type=='e'])

figure=ROOT/summary['figure'];im=Image.open(str(figure)+'.png')
check('600-dpi PNG',all(abs(d-600)<.1 for d in im.info.get('dpi',(0,0))),im.info.get('dpi'))
check('Figure dimensions 7.6 inches square',all(abs(n/600-7.6)<.003 for n in im.size),im.size)
audit=json.loads((AUDIT/'figure_audit.json').read_text(encoding='utf-8'))
check('No label overlap, clipping, or layout failures',not audit['label_overlap_pairs'] and not audit['labels_outside_nodes'] and not any(k[0]=='FAIL' for k in audit['layout_issues']))
check('No gene node overlap',audit['minimum_gene_node_gap_points']>0)
ring_groups=collections.defaultdict(list)
for n in node[2:]:
    radius=round(math.hypot(n['x'],n['y'])/72,2)
    angle=(math.atan2(n['x'],-n['y'])+2*math.pi)%(2*math.pi)
    ring_groups[radius].append((angle,n['id']))
check('Alphabetical order within each clockwise ring',all(
    [g for a,g in sorted(r)]==sorted(g for a,g in r) for r in ring_groups.values()))
check('Gene label font at least 9 pt',audit['minimum_font_pt']>=9)
svg=ET.parse(str(figure)+'.svg').getroot()
svgtexts=[''.join(t.itertext()) for t in svg.iter() if t.tag.endswith('}text')]
check('SVG retains all 49 editable gene labels',source_genes<=set(svgtexts))
reader=PdfReader(str(figure)+'.pdf');page=reader.pages[0]
check('PDF contains one page',len(reader.pages)==1)
check('PDF dimensions match figure',abs(float(page.mediabox.width)/72-7.6)<.001 and abs(float(page.mediabox.height)/72-7.6)<.001)
check('PDF includes all gene labels',all(g in page.extract_text() for g in source_genes))
font_report=[]
for name,obj in page['/Resources']['/Font'].get_object().items():
    font=obj.get_object();fonts=[d.get_object() for d in font.get('/DescendantFonts',[])] or [font]
    for f in fonts:
        descriptor=f.get('/FontDescriptor');descriptor=descriptor.get_object() if descriptor else {}
        embedded=any(key in descriptor for key in ['/FontFile','/FontFile2','/FontFile3'])
        font_report.append({'resource':str(name),'font':str(f.get('/BaseFont')),'embedded':embedded})
check('Every PDF font embedded',bool(font_report) and all(f['embedded'] for f in font_report),font_report)
(AUDIT/'pdf_font_audit.json').write_text(json.dumps(font_report,ensure_ascii=False,indent=2),encoding='utf-8')
report={'checks':checks,'total':len(checks),'passed':sum(c['passed'] for c in checks),
        'failed':[c for c in checks if not c['passed']]}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['total','passed','failed']},ensure_ascii=True))
assert not report['failed'], 'See validation_report.json'
