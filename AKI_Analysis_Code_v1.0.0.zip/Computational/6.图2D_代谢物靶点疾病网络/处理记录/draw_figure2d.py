from pathlib import Path
import sys,json,argparse,math
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Polygon,ConnectionPatch
from matplotlib import font_manager
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout,render_preview
from export_figure import export_figure

ROOT=Path(r'.\Computational\6.图2D_代谢物靶点疾病网络')
AUDIT=ROOT/'处理记录'
p=argparse.ArgumentParser();p.add_argument('--export',action='store_true');args=p.parse_args()
s=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
data=json.loads((AUDIT/'network_data.json').read_text(encoding='utf-8'))
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                     'savefig.facecolor':'white','text.color':s['palette']['text']})
font_manager.findfont('Arial',fallback_to_default=False)
font_manager.findfont('Times New Roman',fallback_to_default=False)

size=(7.6,7.6)
fig=plt.figure(figsize=size,dpi=150,facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(-3.8,3.8),ylim=(-3.8,3.8),aspect='equal');ax.axis('off')
node_map={n['id']:n for n in data['nodes']}
patches={};texts={}
for n in data['nodes']:
    x,y=n['x']/72,-n['y']/72
    w,h=n['width']/72,n['height']/72
    if n['node_type']=='gene':
        patch=Circle((x,y),w/2,facecolor=n['fill'],edgecolor='white',linewidth=.7,zorder=3)
    else:
        # An elongated octagon gives two-line labels ample space.
        b=.16
        vertices=[(x-w/2+b,y+h/2),(x+w/2-b,y+h/2),(x+w/2,y+h/2-b),
                  (x+w/2,y-h/2+b),(x+w/2-b,y-h/2),(x-w/2+b,y-h/2),
                  (x-w/2,y-h/2+b),(x-w/2,y+h/2-b)]
        patch=Polygon(vertices,closed=True,facecolor=n['fill'],edgecolor='white',linewidth=1.2,zorder=5)
    ax.add_patch(patch);patches[n['id']]=patch

for e in data['edges']:
    a,b=node_map[e['source']],node_map[e['target']]
    connection=ConnectionPatch(xyA=(a['x']/72,-a['y']/72),xyB=(b['x']/72,-b['y']/72),
        coordsA='data',coordsB='data',axesA=ax,axesB=ax,
        patchA=patches[e['source']],patchB=patches[e['target']],arrowstyle='-',
        shrinkA=1.4,shrinkB=1.0,linewidth=.65,color=s['palette']['edge'],alpha=.58,zorder=1)
    ax.add_artist(connection)

for n in data['nodes']:
    txt=ax.text(n['x']/72,-n['y']/72,n['label'],ha='center',va='center',
        fontsize=9.4 if n['node_type']=='gene' else 12.0,
        fontfamily='Arial',linespacing=1.18,zorder=6 if n['node_type']!='gene' else 4)
    texts[n['id']]=txt

fig.canvas.draw();renderer=fig.canvas.get_renderer()
issues=audit_layout(fig)
assert not any(level=='FAIL' for level,msg in issues),issues
boxes={k:t.get_window_extent(renderer) for k,t in texts.items()}
overlap=[[a,b] for i,a in enumerate(boxes) for b in list(boxes)[i+1:] if boxes[a].overlaps(boxes[b])]
assert not overlap,overlap
outside=[]
for k,t in texts.items():
    box=t.get_window_extent(renderer)
    # Text rectangle corners must fit within the corresponding visible patch.
    pts=[(box.x0,box.y0),(box.x1,box.y0),(box.x1,box.y1),(box.x0,box.y1)]
    path=patches[k].get_path().transformed(patches[k].get_transform())
    if not all(path.contains_point(pt,radius=-.5) for pt in pts):
        outside.append(k)
assert not outside, f'Labels exceed node boundary: {outside}'
min_gap=min(math.hypot(a['x']-b['x'],a['y']-b['y'])-(a['width']+b['width'])/2
            for i,a in enumerate(data['nodes'][2:]) for b in data['nodes'][2:][i+1:])
assert min_gap>0,min_gap
render_preview(fig,str(AUDIT/'figure2d_preview.png'),dpi=180)
report={'size_inches':size,'dpi':600,'genes':49,'nodes':len(data['nodes']),'edges':len(data['edges']),
        'palette':s['palette'],'minimum_font_pt':9.4,'group_font_pt':12,
        'layout_issues':issues,'label_overlap_pairs':overlap,'labels_outside_nodes':outside,
        'minimum_gene_node_gap_points':min_gap,'alphabetical_within_each_ring':True,
        'matplotlib_version':matplotlib.__version__,'panel_label':None}
if args.export:
    report['exports']=export_figure(fig,str(ROOT/s['figure']),formats=['png','pdf','svg'],dpi=600,
                                  size_inches=size,grayscale_preview=False,tight=False)
    Image.open(ROOT/(s['figure']+'.png')).convert('L').save(AUDIT/'figure2d_grayscale.png',dpi=(600,600))
(AUDIT/'figure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
plt.close(fig)
print(json.dumps({'exported':args.export,**{k:report[k] for k in ['nodes','edges','layout_issues','label_overlap_pairs','labels_outside_nodes','minimum_gene_node_gap_points']}},ensure_ascii=True))
