from pathlib import Path
from collections import Counter
import csv,io,json,hashlib
import openpyxl

ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'合并记录'
payload=json.loads((AUDIT/'merge_payload.json').read_text(encoding='utf-8'))
summary=payload['summary'];checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:print('FAILED',name,detail)
for entry in summary['input_files']:
    check('原文件哈希不变：'+Path(entry['path']).name,hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest()==entry['sha256'])
omim_ws=openpyxl.load_workbook(Path(summary['input_files'][0]['path']),read_only=True,data_only=True)['Sheet']
o=[(i,list(r)) for i,r in enumerate(omim_ws.iter_rows(values_only=True),1) if i>=6 and r[4] and str(r[4]).isdigit()]
csvrows=list(csv.reader(io.StringIO(Path(summary['input_files'][1]['path']).read_text(encoding='utf-8-sig'),newline='')))
g=[(i,r) for i,r in enumerate(csvrows,1) if i>5 and len(r)==5]
approved={str(r[5]).strip() for i,r in o if r[5]};gcgenes={r[0].strip() for i,r in g}
omim_loci={str(r[4]) for i,r in o if not r[5]}
main=[dict(zip(payload['merged']['fields'],r)) for r in payload['merged']['rows']]
expected_keys={f'gene:{s}' for s in approved|gcgenes}|{f'locus:{m}' for m in omim_loci}
check('主表去重键唯一',len({r['Deduplication_key'] for r in main})==len(main))
check('精确合并全部基因与未映射位点',{r['Deduplication_key'] for r in main}==expected_keys)
check('明确基因符号为输入并集',{r['Gene_or_locus'] for r in main if r['Entry_type']=='基因'}==approved|gcgenes)
check('未映射OMIM位点全部保留',{r['OMIM_MIM'] for r in main if r['Entry_type']!='基因'}==omim_loci)
check('共有基因数与两文件交集一致',sum(r['Sources']=='OMIM + GeneCards' for r in main)==len(approved&gcgenes)==42)
check('全部来源数据行保留',payload['omim']['rows']==[[i]+r for i,r in o] and payload['genecards']['rows']==[[i]+r for i,r in g])
omim_refs=[];gc_refs=[]
for r in main:
    for target,field in [(omim_refs,'OMIM_source_rows'),(gc_refs,'GeneCards_source_rows')]:
        target.extend(int(v) for v in r[field].split(' | ') if v)
check('每条OMIM来源记录精确归属一个合并条目',Counter(omim_refs)==Counter(i for i,r in o))
check('每条GeneCards来源记录精确归属一个合并条目',Counter(gc_refs)==Counter(i for i,r in g))
check('来源记录计数无丢失',sum(r['OMIM_record_count'] for r in main)==len(o) and sum(r['GeneCards_record_count'] for r in main)==len(g))
by_symbol={r['Gene_or_locus']:r for r in main if r['Entry_type']=='基因'}
check('GeneCards评分与类型未改变',all(by_symbol[r[0].strip()]['GeneCards_relevance_score']==float(r[3]) and by_symbol[r[0].strip()]['GeneCards_type']==r[2] and by_symbol[r[0].strip()]['GeneCards_knowledge']==float(r[4]) for i,r in g))
check('总计数对账',len(main)==3652 and len(approved|gcgenes)==3647 and len(omim_loci)==5 and len(o)==183 and len(g)==3600)
csvmain=list(csv.DictReader((ROOT/'疾病靶点_OMIM_GeneCards_合并去重.csv').open(encoding='utf-8-sig',newline='')))
check('CSV覆盖全部合并条目',len(csvmain)==len(main) and {r['Deduplication_key'] for r in csvmain}==expected_keys)
txt=(ROOT/'疾病靶点_去重基因清单_3647个.txt').read_text(encoding='utf-8-sig').splitlines()
check('基因TXT无重复且准确包含3647个符号',len(txt)==len(set(txt))==3647 and set(txt)==approved|gcgenes)

file=ROOT/summary['output_workbook']
wb=openpyxl.load_workbook(file,data_only=False)
cached=openpyxl.load_workbook(file,data_only=True)
specs=[('合并去重结果','merged'),('OMIM来源记录','omim'),('GeneCards来源记录','genecards')]
check('工作簿包含三个预期工作表',wb.sheetnames==[s[0] for s in specs])
for name,key in specs:
    ws=wb[name];expected=[r.copy() for r in payload[key]['rows']]
    if key=='genecards':
        for row in expected:row[4]=float(row[4]);row[5]=float(row[5])
    actual=list(ws.iter_rows(min_row=8,max_row=len(expected)+7,max_col=len(expected[0]),values_only=True))
    # Excel serializes empty strings as empty cells.
    canon=lambda r:tuple(None if v=='' else v for v in r)
    check(name+'：所有导出值一致',[canon(r) for r in actual]==[canon(r) for r in expected])
    check(name+'：原生筛选表覆盖全部数据',len(ws.tables)==1 and next(iter(ws.tables.values())).ref==f'A7:{openpyxl.utils.get_column_letter(len(expected[0]))}{len(expected)+7}')
    check(name+'：汇总公式与缓存计数正确',ws['B6'].data_type=='f' and cached[name]['B6'].value==len(expected))
    check(name+'：标题行与标识列冻结',str(ws.freeze_panes)==('B8' if key=='omim' else 'C8'))
    check(name+'：无Excel错误值',not any(c.data_type=='e' for row in ws for c in row))
    check(name+'：预览图存在',(AUDIT/f'preview_{key}.png').stat().st_size>10000)
check('合并结果中的基因和位点标识为文本',all(wb['合并去重结果'].cell(i,1).data_type=='s' for i in range(8,len(main)+8)))
report={'all_passed':all(c['passed'] for c in checks),'n_checks':len(checks),'checks':checks,'summary':summary,'visual_review':'All three sheet previews reviewed; title, headers, counts and source rows readable.'}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_passed':report['all_passed'],'n_checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=True,indent=2))
assert report['all_passed']
