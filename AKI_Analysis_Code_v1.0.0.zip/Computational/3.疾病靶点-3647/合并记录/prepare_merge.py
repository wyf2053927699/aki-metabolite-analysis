from pathlib import Path
from collections import defaultdict,Counter
import csv,io,json,hashlib,re
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
AUDIT=ROOT/'合并记录'
omim_path=ROOT/'OMIM-Gene-Map-Search(5).xlsx'
gc_path=ROOT/'Acute Kidney Injur-Gene cards.csv'
wb=openpyxl.load_workbook(omim_path,read_only=True,data_only=True)
ws=wb['Sheet']
omim_headers=list(next(ws.iter_rows(min_row=5,max_row=5,values_only=True)))
assert omim_headers[5]=='Approved Symbol' and omim_headers[4]=='Gene/Locus MIM number'
omim=[]
for rownum,row in enumerate(ws.iter_rows(min_row=6,values_only=True),6):
    # Extract actual gene-map records; trailing legend and abbreviation rows have no MIM number.
    if row[4] and re.fullmatch(r'\d+',str(row[4])):
        omim.append({'source_row':rownum,'data':list(row)})
csv_rows=list(csv.reader(io.StringIO(gc_path.read_text(encoding='utf-8-sig'),newline='')))
header_index=next(i for i,r in enumerate(csv_rows) if r[:2]==['Symbol','Name'])
gc_headers=csv_rows[header_index]
assert gc_headers==['Symbol','Name','Type','Relevance Score','Knowledge']
gc=[{'source_row':i+1,'data':r} for i,r in enumerate(csv_rows) if i>header_index and len(r)==5]
assert all(r['data'][0].strip() for r in gc)
groups=defaultdict(lambda:{'OMIM':[],'GeneCards':[]})
for record in omim:
    r=record['data']; symbol=str(r[5]).strip() if r[5] is not None else ''
    key=('gene',symbol) if symbol else ('locus',str(r[4]).strip())
    groups[key]['OMIM'].append(record)
for record in gc:
    groups[('gene',record['data'][0].strip())]['GeneCards'].append(record)

def join(values):return ' | '.join(dict.fromkeys(str(v) for v in values if v is not None and str(v)!=''))
merged=[]
for (kind,identifier),sources in sorted(groups.items(),key=lambda kv:(kv[0][0]!='gene',kv[0][1])):
    o=sources['OMIM'];g=sources['GeneCards']
    gscore=max((float(r['data'][3]) for r in g),default=None)
    merged.append({
        'Gene_or_locus':identifier if kind=='gene' else join(r['data'][2] for r in o),
        'Entry_type':'基因' if kind=='gene' else 'OMIM位点（无Approved Symbol）',
        'Sources':'OMIM + GeneCards' if o and g else 'OMIM' if o else 'GeneCards',
        'Gene_name':join(r['data'][1] for r in g) if g else join(r['data'][3] for r in o),
        'GeneCards_type':join(r['data'][2] for r in g),
        'GeneCards_relevance_score':gscore,
        'GeneCards_knowledge':float(g[0]['data'][4]) if g else None,
        'OMIM_MIM':join(r['data'][4] for r in o),
        'Entrez_ID_OMIM':join(r['data'][6] for r in o),
        'OMIM_record_count':len(o),'GeneCards_record_count':len(g),
        'OMIM_source_rows':join(r['source_row'] for r in o),
        'GeneCards_source_rows':join(r['source_row'] for r in g),
        'Deduplication_key':f'{kind}:{identifier}'})
gene_symbols=[r['Gene_or_locus'] for r in merged if r['Entry_type']=='基因']
os={str(r['data'][5]).strip() for r in omim if r['data'][5]}
gs={r['data'][0].strip() for r in gc}
summary={
    'input_files':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [omim_path,gc_path]],
    'source_search_term':'Acute Kidney Injur',
    'omim_original_data_records':len(omim),'omim_unique_approved_genes':len(os),
    'omim_unique_gene_or_locus_entries':len({r['data'][4] for r in omim}),
    'genecards_original_data_records':len(gc),'genecards_unique_genes':len(gs),
    'shared_approved_gene_symbols':len(os&gs),'unique_gene_symbols':len(gene_symbols),
    'unresolved_omim_locus_entries':len(merged)-len(gene_symbols),
    'merged_unique_entries':len(merged),'combined_source_data_records':len(omim)+len(gc),
    'duplicate_occurrences_collapsed':len(omim)+len(gc)-len(merged),
    'source_categories':dict(Counter(r['Sources'] for r in merged)),
    'deduplication_rule':'Exact gene symbol after trimming surrounding whitespace; OMIM uses Approved Symbol. Missing Approved Symbol is retained as a separate locus keyed by OMIM MIM number. No case conversion, alias inference, relevance-score or disease-specificity filter.',
    'output_workbook':'疾病靶点_OMIM_GeneCards_合并去重.xlsx'}
payload={'summary':summary,'merged':{'fields':list(merged[0]),'rows':[list(r.values()) for r in merged]},
         'omim':{'fields':['Source_Excel_row']+omim_headers,'rows':[[r['source_row']]+r['data'] for r in omim]},
         'genecards':{'fields':['Source_CSV_record']+gc_headers,'rows':[[r['source_row']]+r['data'] for r in gc]}}
(AUDIT/'merge_payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(AUDIT/'merge_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'疾病靶点_OMIM_GeneCards_合并去重.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(merged[0]));w.writeheader();w.writerows(merged)
(ROOT/'疾病靶点_去重基因清单_3647个.txt').write_text('\n'.join(gene_symbols)+'\n',encoding='utf-8-sig')
(ROOT/'合并去重说明.txt').write_text(f'''OMIM与GeneCards文件合并去重

原始文件保持不变：
{omim_path.name}
{gc_path.name}

OMIM有效基因图谱记录{len(omim)}行，其中89个带Approved Symbol的基因、5个无Approved Symbol的位点，共94个独立条目。
GeneCards有效记录{len(gc)}行，3,600个独立基因。
两文件共有42个基因；合并后3,647个明确基因，另保留5个无批准基因符号的OMIM位点，共3,652个条目。
累计3,783条来源记录合并为3,652个条目，折叠131次重复出现；全部来源数据行保留在工作簿来源表中。

去重规则：按去除首尾空格后的基因符号精确匹配。OMIM使用Approved Symbol，GeneCards使用Symbol。
OMIM的Gene/Locus列包含别名，不按逗号拆成多个基因，不把别名推测为新的基因。
5个无Approved Symbol的位点按OMIM MIM编号独立保留，并标明条目类型：AIR、ALL2、LALL、ALL1、PKDTS。
无评分阈值、无蛋白编码类别筛选、无疾病相关性筛选、无在线基因别名映射。
文件页眉原检索词均为“Acute Kidney Injur”。本次仅合并用户导出结果，未将关键词命中等同于经核验的AKI机制靶点。
原文件中的标题、空行、版权文字和页尾图例作为文档内容识别，不计为基因记录。

输出：
疾病靶点_OMIM_GeneCards_合并去重.xlsx：去重结果与两个来源的完整有效记录，带原始行号。
疾病靶点_OMIM_GeneCards_合并去重.csv：3,652个合并条目。
疾病靶点_去重基因清单_3647个.txt：只含3,647个明确基因符号；5个位点仍保留于总表。
合并记录/：处理脚本、计数、输入哈希、核对记录和预览。
''',encoding='utf-8-sig')
print(json.dumps({k:v for k,v in summary.items() if k not in ['input_files','deduplication_rule']},ensure_ascii=True,indent=2))
