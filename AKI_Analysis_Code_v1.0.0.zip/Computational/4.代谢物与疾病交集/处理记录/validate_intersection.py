from pathlib import Path
from collections import Counter
import csv,json,hashlib,math,xml.etree.ElementTree as ET
import openpyxl
from PIL import Image
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录'
summary=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'))
checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:print('FAILED',name,detail)
for f in summary['input_files']:
    check(f['kind']+'原文件哈希未改变',hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256'])
mw=openpyxl.load_workbook(summary['input_files'][0]['path'],read_only=True,data_only=True)
dw=openpyxl.load_workbook(summary['input_files'][1]['path'],read_only=True,data_only=True)
mrows={i:r for i,r in enumerate(mw['交集靶点'].iter_rows(min_row=8,max_col=15,values_only=True),8) if r[0]}
drows={i:r for i,r in enumerate(dw['合并去重结果'].iter_rows(min_row=8,max_col=14,values_only=True),8) if r[0]}
A={str(r[0]).strip() for r in mrows.values()}
B={str(r[0]).strip() for r in drows.values() if r[1]=='基因'}
I=A&B;AO=A-B;BO=B-A;U=A|B
check('两个输入集合真实计数正确',len(A)==808 and len(B)==3647)
check('452个交集及356和3195个独有基因计数正确',len(I)==summary['intersection']==452 and len(AO)==356 and len(BO)==3195)
check('所有集合计数恒等式正确',len(U)==4003 and len(A)==len(I)+len(AO) and len(B)==len(I)+len(BO))
check('5个无批准基因符号位点单独记录',sum(r[1]!='基因' for r in drows.values())==summary['unresolved_OMIM_loci']==5)
inter=list(csv.DictReader((ROOT/'代谢物_AKI_交集靶点.csv').open(encoding='utf-8-sig',newline='')))
members=list(csv.DictReader((ROOT/'代谢物_AKI_全部集合归属.csv').open(encoding='utf-8-sig',newline='')))
check('交集CSV准确且没有重复',len(inter)==len({r['Gene_symbol'] for r in inter})==452 and {r['Gene_symbol'] for r in inter}==I)
check('并集CSV准确且没有重复',len(members)==len({r['Gene_symbol'] for r in members})==4003 and {r['Gene_symbol'] for r in members}==U)
check('所有集合归属均正确',all(r['Membership']==('共同候选基因' if r['Gene_symbol'] in I else '代谢物靶点独有' if r['Gene_symbol'] in A else '疾病基因独有') for r in members))
check('TXT清单对应实际集合',all(set((ROOT/f'{name}_{len(genes)}个.txt').read_text(encoding='utf-8-sig').splitlines())==genes for name,genes in [('交集基因',I),('代谢物靶点独有基因',AO),('疾病独有基因',BO)]))
check('交集的两个输入表原始行号准确',all(mrows[int(r['Metabolite_intersection_input_row'])][0]==r['Gene_symbol'] and drows[int(r['Disease_merged_input_row'])][0]==r['Gene_symbol'] for r in inter))
check('疾病来源及评分未改变',all(drows[int(r['Disease_merged_input_row'])][2]==r['Disease_database_source'] and math.isclose(float(drows[int(r['Disease_merged_input_row'])][5]),float(r['GeneCards_relevance_score']),rel_tol=1e-14) for r in inter))
check('SEA与STP靶点编号和评分保持原值',all(mrows[int(r['Metabolite_intersection_input_row'])][1]==r['SEA_UniProt_entry'] and mrows[int(r['Metabolite_intersection_input_row'])][2]==r['STP_UniProt_IDs'] and mrows[int(r['Metabolite_intersection_input_row'])][3]==r['STP_ChEMBL_IDs'] and math.isclose(float(mrows[int(r['Metabolite_intersection_input_row'])][6]),float(r['SEA_min_P']),rel_tol=1e-14,abs_tol=1e-260) and math.isclose(float(mrows[int(r['Metabolite_intersection_input_row'])][7]),float(r['STP_max_Probability']),rel_tol=1e-14) for r in inter))
check('疾病数据库来源统计一致',dict(Counter(r['Disease_database_source'] for r in inter))==summary['intersection_disease_source_counts']=={'GeneCards':440,'OMIM + GeneCards':12})
wb=openpyxl.load_workbook(ROOT/summary['workbook'],data_only=False)
cache=openpyxl.load_workbook(ROOT/summary['workbook'],data_only=True)
specs=[('交集靶点','intersection',['Gene_symbol','Gene_name','Disease_database_source','GeneCards_relevance_score','SEA_UniProt_entry','STP_UniProt_IDs','STP_ChEMBL_IDs','SEA_metabolite_count','STP_metabolite_count','SEA_min_P','STP_max_Probability','SEA_max_MaxTC','OMIM_MIM','Entrez_ID_from_OMIM','GeneCards_gene_type','GeneCards_knowledge','Shared_annotation_note','Metabolite_intersection_input_row','Disease_merged_input_row','Original_OMIM_rows','Original_GeneCards_records','Previous_SEA_gene_sheet_row','Previous_STP_target_sheet_rows','SEA_min_P_raw','SEA_target_description','STP_target_description']),
       ('全部基因集合','membership',['Gene_symbol','Membership','Disease_database_source','In_metabolite_targets','In_disease_genes','Metabolite_intersection_input_row','Disease_merged_input_row'])]
check('两个预期工作表完整',wb.sheetnames==[s[0] for s in specs])
for name,key,fields in specs:
    ws=wb[name];data=payload[key];idx={f:i for i,f in enumerate(data['fields'])}
    expected=[[r[idx[f]] for f in fields] for r in data['rows']]
    actual=list(ws.iter_rows(min_row=8,max_row=len(expected)+7,max_col=len(fields),values_only=True))
    def same(a,b):
        if b is None or b=='':return a is None or a==''
        if isinstance(b,float):return isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-14,abs_tol=1e-260)
        return a==b
    check(name+'：全部导出数据正确',len(actual)==len(expected) and all(all(same(a,b) for a,b in zip(ra,rb)) for ra,rb in zip(actual,expected)))
    check(name+'：原生筛选表范围正确',len(ws.tables)==1 and next(iter(ws.tables.values())).ref==f'A7:{openpyxl.utils.get_column_letter(len(fields))}{len(expected)+7}')
    check(name+'：计数公式与缓存准确',ws['B6'].data_type=='f' and cache[name]['B6'].value==len(expected))
    check(name+'：标识文本与冻结表头正确',str(ws.freeze_panes)=='B8' and all(ws.cell(i,1).data_type=='s' for i in range(8,len(expected)+8)))
    check(name+'：无Excel错误值',not any(c.data_type=='e' for row in ws for c in row))
    check(name+'：预览图已生成',(AUDIT/f'preview_{key}.png').stat().st_size>10000)
fa=json.loads((AUDIT/'figure_audit.json').read_text(encoding='utf-8'))
check('图中计数与集合数据一致',fa['counts']=={k:summary[k] for k in ['metabolite_targets','disease_genes','intersection','metabolite_only','disease_only','union']})
check('图中文字无缺字裁切或重叠',not fa['layout_issues'] and not fa['text_overlap_pairs'])
im=Image.open(ROOT/(summary['figure']+'.png'))
check('PNG为600dpi且画布尺寸正确',im.size==(2400,int(600*4*264/385)) and min(im.info['dpi'])>599)
svg=ET.parse(ROOT/(summary['figure']+'.svg'))
texts={''.join(e.itertext()).strip() for e in svg.iter() if e.tag.endswith('}text')}
check('SVG包含正确数字及AKI标签',{'356','452','3195','808 targets','Acute kidney injury'}<=texts and 'Renal fibrosis' not in texts)
check('SVG为纯矢量',not any(e.tag.endswith('}image') for e in svg.iter()))
pdf=PdfReader(ROOT/(summary['figure']+'.pdf'));font_report=[]
for name,reference in pdf.pages[0]['/Resources']['/Font'].get_object().items():
    font=reference.get_object();descendants=font.get('/DescendantFonts');leafs=[f.get_object() for f in descendants] if descendants else [font]
    embeds=[]
    for leaf in leafs:
        fd=leaf.get('/FontDescriptor');fd=fd.get_object() if fd else {}
        embeds.append(any(k in fd for k in ['/FontFile','/FontFile2','/FontFile3']))
    font_report.append({'font':str(font.get('/BaseFont')),'embedded':all(embeds)})
check('PDF字体已实际嵌入',bool(font_report) and all(f['embedded'] for f in font_report),font_report)
check('PDF画布尺寸正确',abs(float(pdf.pages[0].mediabox.width)/72-4)<0.001 and abs(float(pdf.pages[0].mediabox.height)/72-4*264/385)<0.001)
(AUDIT/'pdf_font_audit.json').write_text(json.dumps(font_report,ensure_ascii=False,indent=2),encoding='utf-8')
report={'all_passed':all(c['passed'] for c in checks),'n_checks':len(checks),'checks':checks,'counts':fa['counts'],
        'visual_review':'Reference palette and equal-circle layout reviewed; correct AKI label, no arrow. Both workbook previews and grayscale figure reviewed.'}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_passed':report['all_passed'],'n_checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=True,indent=2))
assert report['all_passed']
