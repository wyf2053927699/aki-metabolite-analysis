from pathlib import Path
from collections import Counter
import sys,json,argparse
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录'
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib import font_manager
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout,render_preview
from export_figure import export_figure
parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');args=parser.parse_args()
summary=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
ref=Image.open(AUDIT/'参考图.png').convert('RGB')
colors=Counter(ref.get_flattened_data()).most_common(10)
palette={'metabolite':'#F6B7AE','disease':'#B8E4ED','intersection':'#EDE1E1'}
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
font_manager.findfont('Arial',fallback_to_default=False)
size=(4.0,4.0*264/385)
fig=plt.figure(figsize=size,dpi=150,facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,385),ylim=(264,0));ax.set_aspect('equal');ax.axis('off')
left=Circle((153,122),98,facecolor=palette['metabolite'],edgecolor='none',zorder=1)
right=Circle((232,122),98,facecolor=palette['disease'],edgecolor='none',zorder=1)
ax.add_patch(left);ax.add_patch(right)
lens=Circle((232,122),98,facecolor=palette['intersection'],edgecolor='none',zorder=2)
lens.set_clip_path(left);ax.add_patch(lens)
texts=[]
for x,n in [(95,summary['metabolite_only']),(192.5,summary['intersection']),(290,summary['disease_only'])]:
    texts.append(ax.text(x,122,str(n),ha='center',va='center',fontsize=11.5,fontfamily='Arial',color='black',zorder=3))
texts.append(ax.text(112,239,summary['metabolite_label'],ha='center',va='center',fontsize=12,fontfamily='Arial',color='black'))
texts.append(ax.text(273,239,summary['disease_label'],ha='center',va='center',fontsize=12,fontfamily='Arial',color='black'))
fig.canvas.draw();issues=audit_layout(fig);assert not any(level=='FAIL' for level,msg in issues),issues
renderer=fig.canvas.get_renderer();boxes=[t.get_window_extent(renderer) for t in texts]
collisions=[[i,j] for i,a in enumerate(boxes) for j,b in enumerate(boxes) if j>i and a.overlaps(b)]
assert not collisions,collisions
render_preview(fig,str(AUDIT/'venn_preview.png'),dpi=180)
audit={'counts':{k:summary[k] for k in ['metabolite_targets','disease_genes','intersection','metabolite_only','disease_only','union']},
    'labels':[summary['metabolite_label'],summary['disease_label']],'size_inches':list(size),'dpi':600,'palette':palette,
    'reference_dominant_colors':[[list(rgb),n] for rgb,n in colors[:6]],
    'layout_issues':issues,'text_overlap_pairs':collisions,'minimum_font_pt':11.5,'area_proportional':False,
    'python_version':sys.version,'matplotlib_version':matplotlib.__version__}
if args.export:
    audit['exports']=export_figure(fig,str(ROOT/summary['figure']),formats=['png','pdf','svg'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
    Image.open(ROOT/(summary['figure']+'.png')).convert('L').save(AUDIT/'venn_grayscale.png',dpi=(600,600))
(AUDIT/'figure_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
plt.close(fig)
print(json.dumps({'counts':audit['counts'],'palette':palette,'layout_issues':issues,'text_overlap_pairs':collisions,'exported':args.export},ensure_ascii=True))
