from pathlib import Path
from collections import Counter
import csv,json,hashlib,re,sys
import openpyxl
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录';BASE=ROOT.parent
metabolite_file=BASE/'2.SEA&STP靶点预测/SEA与STP交集韦恩图/SEA_STP_交集靶点.xlsx'
disease_file=BASE/'3.疾病靶点-3647/疾病靶点_OMIM_GeneCards_合并去重.xlsx'
mw=openpyxl.load_workbook(metabolite_file,read_only=True,data_only=True)
dw=openpyxl.load_workbook(disease_file,read_only=True,data_only=True)
def records(ws,ncols):
    header=next(ws.iter_rows(min_row=7,max_row=7,max_col=ncols,values_only=True))
    return [(i,dict(zip(header,row))) for i,row in enumerate(ws.iter_rows(min_row=8,max_col=ncols,values_only=True),8) if row and row[0] is not None]
mdata=records(mw['交集靶点'],15);ddata=records(dw['合并去重结果'],14)
metabolites={};diseases={};unresolved=[]
for i,r in mdata:
    symbol=str(r['基因符号']).strip();assert re.fullmatch(r'[A-Za-z0-9_.-]+',symbol)
    assert symbol not in metabolites;metabolites[symbol]=(i,r)
for i,r in ddata:
    if r['条目类型']=='基因':
        symbol=str(r['基因或位点']).strip();assert re.fullmatch(r'[A-Za-z0-9_.-]+',symbol)
        assert symbol not in diseases;diseases[symbol]=(i,r)
    else:unresolved.append({'Gene_or_locus':r['基因或位点'],'Entry_type':r['条目类型'],'OMIM_MIM':r['OMIM MIM编号'],'Source_row':i})
A=set(metabolites);B=set(diseases);common=A&B
rows=[]
for symbol in sorted(common):
    mi,m=metabolites[symbol];di,d=diseases[symbol]
    rows.append({'Gene_symbol':symbol,'Gene_name':d['基因或位点名称'],'Disease_database_source':d['来源'],
        'SEA_UniProt_entry':m['SEA UniProt Entry'],'STP_UniProt_IDs':m['STP UniProt编号'],
        'STP_ChEMBL_IDs':m['STP ChEMBL靶点编号'],'GeneCards_relevance_score':d['GeneCards相关性评分'],
        'OMIM_MIM':d['OMIM MIM编号'],'Entrez_ID_from_OMIM':d['OMIM Entrez ID'],
        'SEA_min_P':m['SEA最小P值'],'STP_max_Probability':m['STP最大Probability'],'SEA_max_MaxTC':m['SEA最大MaxTC'],
        'SEA_metabolite_count':m['SEA关联代谢物数'],'STP_metabolite_count':m['STP关联代谢物数'],
        'GeneCards_gene_type':d['GeneCards基因类型'],'GeneCards_knowledge':d['GeneCards Knowledge'],
        'Shared_annotation_note':m['共享注释说明'],
        'Metabolite_intersection_input_row':mi,'Disease_merged_input_row':di,
        'Original_OMIM_rows':d['OMIM原始Excel行号'],'Original_GeneCards_records':d['GeneCards原始CSV记录号'],
        'Previous_SEA_gene_sheet_row':m['SEA基因表原始行号'],'Previous_STP_target_sheet_rows':m['STP靶点表原始行号'],
        'SEA_min_P_raw':m['SEA最小P值原始文本'],'SEA_target_description':m['SEA靶点描述'],'STP_target_description':m['STP靶点描述']})
membership=[]
for symbol in sorted(A|B):
    m=metabolites.get(symbol);d=diseases.get(symbol)
    membership.append({'Gene_symbol':symbol,'Membership':'共同候选基因' if symbol in common else '代谢物靶点独有' if symbol in A else '疾病基因独有',
        'In_metabolite_targets':symbol in A,'In_disease_genes':symbol in B,
        'Disease_database_source':d[1]['来源'] if d else None,
        'Metabolite_intersection_input_row':m[0] if m else None,'Disease_merged_input_row':d[0] if d else None})
summary={'input_files':[{'kind':kind,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for kind,p in [('metabolite_targets',metabolite_file),('disease_genes',disease_file)]],
    'metabolite_targets':len(A),'disease_genes':len(B),'intersection':len(common),'metabolite_only':len(A-B),'disease_only':len(B-A),'union':len(A|B),
    'unresolved_OMIM_loci':len(unresolved),'comparison_unit':'Exact existing gene symbol with surrounding whitespace trimmed',
    'additional_score_filter':'none','alias_mapping':'none','case_conversion':'none',
    'intersection_disease_source_counts':dict(Counter(r['Disease_database_source'] for r in rows)),
    'disease_label':'Acute kidney injury','metabolite_label':f'{len(A)} targets',
    'figure_geometry':'Equal circles as requested reference; areas not proportional to gene counts',
    'workbook':'代谢物_AKI_交集靶点.xlsx','figure':'代谢物_AKI_靶点韦恩图'}
def csvout(name,items):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(items[0]));w.writeheader();w.writerows(items)
csvout('代谢物_AKI_交集靶点.csv',rows);csvout('代谢物_AKI_全部集合归属.csv',membership)
with (AUDIT/'未注释为基因的OMIM位点.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(unresolved[0]));w.writeheader();w.writerows(unresolved)
for name,genes in [('交集基因',common),('代谢物靶点独有基因',A-B),('疾病独有基因',B-A)]:
    (ROOT/f'{name}_{len(genes)}个.txt').write_text('\n'.join(sorted(genes))+'\n',encoding='utf-8-sig')
payload={'summary':summary}
for key,data in [('intersection',rows),('membership',membership)]:
    payload[key]={'fields':list(data[0]),'rows':[list(r.values()) for r in data]}
(AUDIT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (AUDIT/'gene_membership.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Gene_symbol','Metabolite_target','Disease_gene'])
    for g in sorted(A|B):w.writerow([g,g in A,g in B])
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
from profile_data import profile_data,render_report
(AUDIT/'data_profile.txt').write_text(render_report(profile_data(str(AUDIT/'gene_membership.csv'),group_cols=[])),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='input_files'},ensure_ascii=True,indent=2))
