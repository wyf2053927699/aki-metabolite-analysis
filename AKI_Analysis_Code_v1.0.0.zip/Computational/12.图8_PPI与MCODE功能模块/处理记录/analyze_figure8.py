from pathlib import Path
import sys,json,math,hashlib,platform
sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
import pandas as pd,networkx as nx,numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
A=ROOT/'处理记录';R=ROOT/'原始数据';T=ROOT/'各子图数据表'
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip')
def save(df,name):df.to_csv(T/name,index=False,encoding='utf-8-sig')
answer=json.loads((A/'MCODE官方插件完整返回.json').read_text(encoding='utf-8'))
assert not answer['errors'] and not answer['data']['stale']
cy=json.loads((A/'Cytoscape节点表_运行后.json').read_text(encoding='utf-8'))['rows']
cybyid={n['SUID']:n for n in cy};cybygene={n['Gene_symbol']:n for n in cy}
runid=answer['data']['id'];scorefield=f'MCODE::Score ({runid})';statusfield=f'MCODE::Node Status ({runid})';clusterfield=f'MCODE::Clusters ({runid})'
nodes=read('A_PPI全部105输入节点核对.csv');edges=read('A_PPI全部连线.csv')
G=nx.Graph();G.add_nodes_from(nodes.loc[nodes.Mapped,'Gene_symbol']);G.add_edges_from(zip(edges.Source,edges.Target))
nodes['MCODE_node_score']=[cybygene[g].get(scorefield,0) if g in cybygene else None for g in nodes.Gene_symbol]
nodes['MCODE_node_status']=[cybygene[g].get(statusfield,'Unclustered') if g in cybygene else 'Unmapped' for g in nodes.Gene_symbol]
nodes['MCODE_clusters']=[' / '.join(cybygene[g].get(clusterfield,[])) if g in cybygene else '' for g in nodes.Gene_symbol]
nodes['Cytoscape_SUID']=[str(cybygene[g]['SUID']) if g in cybygene else '' for g in nodes.Gene_symbol]
save(nodes,'A_PPI全部105输入节点核对.csv')
scores=[]
for gene in G:
    hood=G.subgraph([gene,*G.neighbors(gene)]).copy()
    if G.degree(gene)<2:score=0;k=0;density=0
    else:
        k=max(nx.core_number(hood).values(),default=0);core=nx.k_core(hood,k);density=nx.density(core);score=k*density
    official=float(cybygene[gene].get(scorefield,0))
    scores.append(dict(Gene_symbol=gene,PPI_degree=G.degree(gene),Highest_neighborhood_kcore=k,Kcore_density=density,Independent_node_score=score,Official_MCODE_node_score=official,Absolute_difference=abs(score-official)))
save(pd.DataFrame(scores),'MCODE节点得分_独立核对.csv')
summaries=[];allmembers=[];alle=[]
palette={1:'#EF151B',2:'#2D85B2',3:'#4CB04F',4:'#9565AF'}
panels={1:'B',2:'C',3:'D',4:'S1'}
for cluster in answer['data']['clusters']:
    rank=cluster['rank'];genes=sorted(cybyid[n]['Gene_symbol'] for n in cluster['nodes']);H=G.subgraph(genes).copy()
    density=nx.density(H);score=density*len(H)
    assert math.isclose(score,cluster['score'],rel_tol=1e-13)
    seed=cybyid[cluster['seedNode']]['Gene_symbol']
    member=nodes.set_index('Gene_symbol').loc[genes].reset_index().copy()
    member.insert(0,'Cluster_rank',rank);member.insert(1,'Panel',panels.get(rank,'S'+str(rank-3)))
    member['Cluster_degree']=member.Gene_symbol.map(dict(H.degree()));member['Is_seed']=member.Gene_symbol.eq(seed);member['Node_color']=palette.get(rank,'#9565AF')
    subset=edges[edges.Source.isin(genes)&edges.Target.isin(genes)].copy();subset.insert(0,'Cluster_rank',rank)
    summaries.append(dict(Cluster_rank=rank,Panel=panels.get(rank,'S'+str(rank-3)),Displayed_in_main=rank<=3,
        Node_count=len(H),Edge_count=H.number_of_edges(),Density=density,MCODE_score=score,Seed_gene=seed,
        Core_genes='/'.join(sorted(member.loc[member.Is_Figure3_core,'Gene_symbol'])),Genes='/'.join(genes),Color=palette.get(rank,'#9565AF')))
    save(member,f'{panels[rank]}_Cluster{rank}_节点.csv');save(subset,f'{panels[rank]}_Cluster{rank}_连线.csv')
    allmembers.append(member);alle.append(subset)
summary=pd.DataFrame(summaries);save(summary,'MCODE_全部模块汇总.csv')
save(pd.concat(allmembers,ignore_index=True),'MCODE_全部模块成员.csv');save(pd.concat(alle,ignore_index=True),'MCODE_全部模块连线.csv')
summary_dict=dict(Input_genes=105,Mapped=int(nodes.Mapped.sum()),Connected_nodes=sum(d>0 for _,d in G.degree()),
    Mapped_isolates=sorted(nx.isolates(G)),Unmapped=nodes.loc[~nodes.Mapped,'Gene_symbol'].tolist(),Edges=G.number_of_edges(),
    MCODE_clusters=len(summary),MCODE_parameters=answer['data']['parameters'],Cytoscape_version='3.10.2',MCODE_version='2.0.3',
    STRING_version='12.0',STRING_threshold=.4,Network_type='functional',Additional_proteins=0,
    Cluster_summaries=summary.to_dict('records'),MCODE_node_score_max_difference=max(s['Absolute_difference'] for s in scores),
    Python=platform.python_version(),NetworkX=nx.__version__,Numpy=np.__version__,Layout_seed=20261019)
(A/'analysis_summary.json').write_text(json.dumps(summary_dict,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=[dict(File=str(p.relative_to(ROOT)).replace('\\','/'),SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(R.iterdir()) if p.is_file()]
(A/'原始输入与注释_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary_dict,ensure_ascii=False,indent=2))
