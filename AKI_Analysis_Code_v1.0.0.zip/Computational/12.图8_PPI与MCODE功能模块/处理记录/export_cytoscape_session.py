from pathlib import Path
import json,urllib.request,urllib.error
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
A=ROOT/'处理记录'
def call(route,data=None):
    req=urllib.request.Request('http://127.0.0.1:1234/v1/'+route,data=json.dumps(data,ensure_ascii=False).encode('utf-8') if data is not None else None,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=120) as response:body=response.read()
    try:return json.loads(body)
    except json.JSONDecodeError:return body.decode('utf-8')
suid=json.loads((A/'Cytoscape创建网络返回.json').read_text(encoding='utf-8'))['networkSUID']
layouts=call('apply/layouts');(A/'Cytoscape可用布局.json').write_text(json.dumps(layouts,ensure_ascii=False,indent=2),encoding='utf-8')
if 'force-directed' in layouts:call('apply/layouts/force-directed/'+str(suid))
target=ROOT/'Cytoscape可编辑网络/Cytoscape官方MCODE原始分析.cys'
answer=call('commands/session/save',{'file':str(target)})
(A/'Cytoscape会话保存返回.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2),encoding='utf-8')
assert target.exists() and target.stat().st_size>1000
print(str(target),target.stat().st_size)
