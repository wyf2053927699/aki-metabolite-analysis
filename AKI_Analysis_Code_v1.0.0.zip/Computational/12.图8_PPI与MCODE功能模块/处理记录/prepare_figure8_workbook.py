from pathlib import Path
import pandas as pd,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
T=ROOT/'各子图数据表';A=ROOT/'处理记录'
def read(name):
    df=pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip',dtype={'Entrez_ID':str})
    for field in ['MCODE_node_score','Plot_X','Plot_Y','Label_X','Label_Y','Node_size_pt2']:
        if field in df:df[field]=pd.to_numeric(df[field],errors='raise' if not df[field].eq('').any() else 'coerce')
    return df
sheets=[]
heads=dict(Cluster_rank='模块排名',Panel='子图',Displayed_in_main='在主图中',Node_count='节点数',Edge_count='连线数',Density='模块密度',MCODE_score='MCODE模块得分',Seed_gene='种子基因',Core_genes='所含核心基因',Genes='全部模块基因',Color='颜色',Gene_symbol='基因符号',Entrez_ID='Entrez ID',In_original49='属于原49',Is_Figure3_core='是否图3核心',Newly_added='扩展新增基因',Mapped='严格映射成功',STRING_ID='STRING ID',PPI_degree='完整PPI度数',PPI_status='映射/连接状态',MCODE_node_score='MCODE节点得分',MCODE_node_status='MCODE节点状态',MCODE_clusters='所属MCODE模块',Plot_X='绘图X',Plot_Y='绘图Y',Label_X='标签X',Label_Y='标签Y',Node_size_pt2='节点面积(pt²)',Cluster_degree='模块内度数',Is_seed='是否种子',Node_color='节点颜色',Source='起点基因',Target='终点基因',score='STRING综合分数',nscore='邻近证据',fscore='融合证据',pscore='系统发生证据',ascore='共表达证据',escore='实验依据',dscore='数据库依据',tscore='文本挖掘证据',stringId_A='起点STRING ID',stringId_B='终点STRING ID',Edge_ID='边ID',Parameter='参数',Value='内容')
def width(f):
    if f in ['Genes','Value']:return 105
    if f in ['STRING_ID','stringId_A','stringId_B']:return 33
    if f in ['MCODE_clusters','MCODE_node_status','PPI_status','Core_genes','Parameter']:return 34
    return 23
def add(name,title,df,notes):
    obj=df.astype(object).where(pd.notna(df),None)
    sheets.append(dict(name=name,title=title,fields=list(df.columns),labels=[heads.get(f,f) for f in df.columns],rows=obj.values.tolist(),widths=[width(f) for f in df.columns],notes=notes))
add('模块汇总','图8 | 官方MCODE全部模块',read('MCODE_全部模块汇总.csv'),['来源：Cytoscape 3.10.2 / MCODE 2.0.3，默认参数。','主图B–D显示前3个模块；第4个保留于补充图与本表。','Density=2E/[N(N−1)]；MCODE模块得分=Density×N，Excel公式可复核。'])
nodefields=['Gene_symbol','Entrez_ID','In_original49','Is_Figure3_core','Newly_added','Mapped','STRING_ID','PPI_degree','PPI_status','MCODE_node_score','MCODE_node_status','MCODE_clusters','Plot_X','Plot_Y','Node_size_pt2']
add('A_全部105输入节点','A | 105个输入基因、映射状态与绘图坐标',read('A_PPI全部105输入节点核对.csv')[nodefields],['来源：图5的105基因与STRING v12.0人类官方protein.info。','103个严格映射；100个有边，3个映射孤立点，2个未映射。','未映射基因保留审计；MCODE得分和坐标为空，不填成真实0。'])
edgefields=['Edge_ID','Source','Target','stringId_A','stringId_B','score','nscore','fscore','pscore','ascore','escore','dscore','tscore']
add('A_PPI全部连线','A | 1108条真实STRING功能关联',read('A_PPI全部连线.csv')[edgefields],['来源：version-12-0.string-db.org/api/tsv/network；species=9606。','综合分数>=0.4；不添加外部蛋白，去除自环与无向重复。','STRING分数是关联置信度；功能关联不等同于直接物理结合。'])
for panel,rank in [('B',1),('C',2),('D',3),('S1',4)]:
    m=read(f'{panel}_Cluster{rank}_节点.csv')
    fields=['Gene_symbol','Entrez_ID','STRING_ID','PPI_degree','Cluster_degree','MCODE_node_score','Is_seed','Is_Figure3_core','In_original49','Newly_added','Plot_X','Plot_Y','Label_X','Label_Y','Node_size_pt2','Node_color']
    add(f'{panel}_模块{rank}节点',f'{panel} | Cluster {rank}节点及绘图参数',m[fields],['模块成员直接取自官方MCODE插件完整JSON结果。','节点大小按完整PPI度数；模块内度数另列，不混用。','坐标与SVG/Python布局一致；节点颜色表示模块身份。'])
    add(f'{panel}_模块{rank}连线',f'{panel} | Cluster {rank}全部诱导子图连线',read(f'{panel}_Cluster{rank}_连线.csv')[edgefields],['仅保留完整PPI中两个端点都属于本模块的真实边。','没有将模块节点自动连接成完全图。','所有STRING综合分数和证据通道分数保留。'])
params=pd.DataFrame([
('参考论文','DOI 10.1186/s40643-026-01083-8，图8；本地PDF第11页'),('输入基因数',105),('输入来源','图5原49基因+56个新预测基因的去重并集'),('物种','Homo sapiens, 9606'),
('STRING版本','12.0，固定版本，与图3一致'),('映射','官方protein.info preferred_name与基因符号唯一精确匹配'),('严格映射数',103),('有边节点数',100),('映射孤立点','SENP2/ST6GAL1/ZC3H12B'),('未映射','VDR/VEGFA'),
('网络类型','functional，无向简单图'),('STRING分数阈值',.4),('额外扩展蛋白',0),('PPI边数',1108),('聚类输入','全部103个已映射节点，包括3个孤立点'),('Cytoscape','3.10.2；通过本机CyREST实际调用'),('MCODE插件','2.0.3，官方已安装插件，Jar SHA256已归档'),
('degreeCutoff',2),('nodeScoreCutoff',.2),('kCore',2),('maxDepthFromStart',100),('haircut',True),('fluff',False),('includeLoops',False),('fluffNodeDensityCutoff',.1),('scope','NETWORK'),('模块总数',4),
('主图选择','按MCODE模块得分排名前3，保留参考A–D排版；第四模块另存补充图'),('节点得分核对','103个节点均独立重算，最大绝对差为0'),('模块得分公式','模块密度×节点数；密度=2E/[N(N−1)]'),('MCODE算法图','无向、无权；STRING分数用于阈值筛选，不用于加权MCODE'),
('节点大小','完整PPI度数映射为面积；各模块使用统一映射'),('颜色','整体网络灰色；Cluster1红，Cluster2蓝，Cluster3绿，Cluster4紫'),('布局','固定种子20261019，力导向+径向展开+标签避让；不改变拓扑'),
('本图分析范围','模块识别与展示；没有在此图中进行模块GO/KEGG分析'),('原文工具差异','参考论文经Metascape进行MCODE；本项目实际调用Cytoscape官方MCODE，参数与结果全部归档'),
('STRING API','https://string-db.org/help/api/'),('MCODE参数说明','https://mcode.readthedocs.io/en/latest/Tuning.html'),('MCODE结果说明','https://mcode.readthedocs.io/en/latest/Outputting.html'),('MCODE原始论文','Bader GD, Hogue CWV (2003). doi:10.1186/1471-2105-4-2'),
],columns=['Parameter','Value'])
add('参数与来源','图8 | 方法、参数和来源',params,['数据下载时间、请求参数和SHA256保存在原始数据。','CyREST原始请求、官方结果和节点表保存于处理记录。','默认复现使用归档的官方MCODE结果，不重新查询数据库。'])
(A/'workbook_payload.json').write_text(json.dumps(dict(sheets=sheets),ensure_ascii=False,allow_nan=False,indent=2),encoding='utf-8')
print('Workbook sheets',len(sheets))
