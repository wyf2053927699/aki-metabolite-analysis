from pathlib import Path
import sys,json,math,argparse
sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
import numpy as np,pandas as pd,networkx as nx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib import patheffects as pe
from matplotlib.backends.backend_pdf import PdfPages

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
A=ROOT/'处理记录';T=ROOT/'各子图数据表';OUT=ROOT/'图片';Q=A/'图片预览'
EXPORT='--export' in sys.argv
plt.rcParams.update({'font.family':'Arial','font.size':10,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.unicode_minus':False,'savefig.facecolor':'white'})
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip')
nodes=read('A_PPI全部105输入节点核对.csv');edges=read('A_PPI全部连线.csv');summary=read('MCODE_全部模块汇总.csv')
G=nx.Graph();G.add_nodes_from(nodes.loc[nodes.Mapped,'Gene_symbol']);G.add_edges_from(zip(edges.Source,edges.Target))
connected=sorted(g for g in G if G.degree(g)>0);H=G.subgraph(connected)
pos={k:np.array(v,dtype=float) for k,v in nx.spring_layout(H,seed=20261019,iterations=1200,k=.23,weight=None).items()}
layout_path=A/'PPI固定布局_v2.json'
if layout_path.exists():pos={k:np.array(v) for k,v in json.loads(layout_path.read_text(encoding='utf-8')).items()}
else:
    # Spread force-layout radii across a disk before label-aware relaxation.
    # This changes visual coordinates only, preserving every edge and node.
    radial=sorted(pos,key=lambda g:float(np.linalg.norm(pos[g])))
    for i,g in enumerate(radial):
        direction=pos[g]/max(float(np.linalg.norm(pos[g])),1e-12)
        pos[g]=direction*(.94*math.sqrt((i+.5)/len(radial)))
    labels=sorted(pos)
    for iteration in range(700):
        shifts={k:np.zeros(2) for k in labels};collisions=0
        for i,u in enumerate(labels):
            for v in labels[i+1:]:
                delta=pos[u]-pos[v];wx=(len(u)+len(v))*.0081+.025;hy=.053
                dx=wx-abs(delta[0]);dy=hy-abs(delta[1])
                if dx>0 and dy>0:
                    collisions+=1
                    if dx<dy*2:move=np.array([math.copysign(dx*.53,delta[0] or 1),0.])
                    else:move=np.array([0.,math.copysign(dy*.53,delta[1] or 1)])
                    shifts[u]+=move;shifts[v]-=move
        for g in labels:pos[g]=np.clip(pos[g]+np.clip(shifts[g],-.02,.02),-1.01,1.01)
        if not collisions:break
    layout_path.write_text(json.dumps({g:p.tolist() for g,p in pos.items()},indent=2),encoding='utf-8')
isolates=sorted(nx.isolates(G))
allpos={**pos,**{g:np.array([-.66+.66*i,-1.22]) for i,g in enumerate(isolates)}}
nodes['Plot_X']=nodes.Gene_symbol.map({g:float(p[0]) for g,p in allpos.items()});nodes['Plot_Y']=nodes.Gene_symbol.map({g:float(p[1]) for g,p in allpos.items()})
nodes['Node_size_pt2']=nodes.PPI_degree.map(lambda d:90+2.5*d)
nodes.to_csv(T/'A_PPI全部105输入节点核对.csv',index=False,encoding='utf-8-sig')
modulepos={};moduledata={};moduleedges={}
for row in summary.itertuples():
    rank=row.Cluster_rank;panel=row.Panel
    m=read(f'{panel}_Cluster{rank}_节点.csv');e=read(f'{panel}_Cluster{rank}_连线.csv')
    genes=m.Gene_symbol.tolist();n=len(genes);cols=6 if n>20 else 4 if n>8 else 3 if n>3 else 2
    rows=math.ceil(n/cols)
    p={g:np.array([float(i%cols),float(rows-1-i//cols)]) for i,g in enumerate(genes)}
    if n==3:p={genes[0]:np.array([0.,0.]),genes[1]:np.array([1.,1.]),genes[2]:np.array([2.,0.])};cols=3;rows=2
    m['Plot_X']=m.Gene_symbol.map({g:v[0] for g,v in p.items()});m['Plot_Y']=m.Gene_symbol.map({g:v[1] for g,v in p.items()});m['Label_X']=m.Plot_X+.20;m['Label_Y']=m.Plot_Y
    m['Node_size_pt2']=m.PPI_degree.map(lambda d:35+1.4*d)
    m.to_csv(T/f'{panel}_Cluster{rank}_节点.csv',index=False,encoding='utf-8-sig')
    modulepos[rank]=(p,cols,rows);moduledata[rank]=m;moduleedges[rank]=e

def clean(ax):ax.set_axis_off();ax.set_facecolor('white')
audit=[]
def ppi(ax,font=7.7,scale=1):
    clean(ax);ax.set_xlim(-1.16,1.16);ax.set_ylim(-1.42,1.18);ax.set_aspect('equal')
    ax.add_collection(LineCollection([[allpos[r.Source],allpos[r.Target]] for r in edges.itertuples()],colors='#C7C7C7',alpha=.24,linewidths=.43,zorder=1))
    mapped=nodes[nodes.Mapped]
    ax.scatter(mapped.Plot_X,mapped.Plot_Y,s=mapped.Node_size_pt2*scale,c='#D2D2D2',edgecolors='#BBBBBB',linewidths=.35,zorder=2)
    texts=[]
    for row in mapped.itertuples():texts.append(ax.text(row.Plot_X,row.Plot_Y,row.Gene_symbol,ha='center',va='center',fontsize=font,color='#292929',zorder=3,path_effects=[pe.withStroke(linewidth=.65,foreground='white',alpha=.45)]))
    ax.text(0,-1.365,'Mapped isolates',ha='center',va='center',fontsize=8.4,color='#606060')
    return texts

def module(ax,rank,font=9,scale=1):
    clean(ax);m=moduledata[rank];e=moduleedges[rank];p,cols,rows=modulepos[rank]
    ax.set_xlim(-.25,cols-.02);ax.set_ylim(-.42,rows-.48);ax.set_aspect('auto')
    ax.add_collection(LineCollection([[p[r.Source],p[r.Target]] for r in e.itertuples()],colors='#79688E',alpha=.31 if rank==1 else .66,linewidths=.55 if rank==1 else .85,zorder=1))
    ax.scatter(m.Plot_X,m.Plot_Y,s=m.Node_size_pt2*scale,c=m.Node_color,edgecolors='#2979A6',linewidths=1.1,zorder=2)
    for row in m.itertuples():ax.text(row.Label_X,row.Label_Y,row.Gene_symbol,ha='left',va='center',fontsize=font,color='#151515',zorder=3,path_effects=[pe.withStroke(linewidth=1.6,foreground='white',alpha=.88)])

def caption(fig,rank,x,y,size=15):
    row=summary[summary.Cluster_rank==rank].iloc[0]
    fig.text(x,y,f'Cluster {rank}',ha='center',fontsize=size,fontfamily='Times New Roman')
    fig.text(x,y-.024,f'{row.Node_count} nodes | {row.Edge_count} edges | MCODE score {row.MCODE_score:.3f}',ha='center',fontsize=9.2,color='#454545')

def main():
    fig=plt.figure(figsize=(14,11.2))
    a=fig.add_axes([.018,.105,.62,.82]);text=ppi(a)
    fig.text(.018,.966,'A',fontsize=23,fontfamily='Times New Roman');fig.text(.328,.946,'Expanded candidate PPI network',ha='center',fontsize=14)
    for rank,bounds,tag,y,cy,font in [(1,[.695,.59,.285,.335],'B',.966,.555,8.4),(2,[.695,.31,.285,.18],'C',.513,.274,9.8),(3,[.695,.09,.285,.135],'D',.235,.056,10.0)]:
        module(fig.add_axes(bounds),rank,font=font);fig.text(.666,y,tag,fontsize=23,fontfamily='Times New Roman');caption(fig,rank,.837,cy)
    fig.text(.035,.072,'105 input genes | 103 mapped | 100 connected proteins | 1,108 associations',fontsize=10)
    fig.text(.035,.049,'Three mapped isolates shown below the network; VDR and VEGFA retained in the input audit.',fontsize=9.1,color='#505050')
    fig.text(.035,.026,'Node size: PPI degree. Top 3 of 4 MCODE modules shown; Cluster 4 is provided separately.',fontsize=9.1,color='#505050')
    fig.canvas.draw();renderer=fig.canvas.get_renderer();boxes=[t.get_window_extent(renderer).expanded(1.015,1.03) for t in text]
    collisions=[(text[i].get_text(),text[j].get_text()) for i in range(len(text)) for j in range(i+1,len(text)) if boxes[i].overlaps(boxes[j])]
    audit.append(dict(Figure='Main',PPI_label_overlaps=collisions))
    return fig

def single_ppi():
    fig=plt.figure(figsize=(10.5,11.5));ppi(fig.add_axes([.025,.105,.95,.82]),font=8.3,scale=1.4)
    fig.text(.5,.964,'Expanded candidate PPI network',ha='center',fontsize=17)
    fig.text(.5,.938,'STRING v12.0 | Human | Functional associations | Combined score >= 0.4',ha='center',fontsize=11)
    fig.text(.05,.063,'105 input | 103 mapped | 100 connected proteins | 1,108 associations',fontsize=11)
    fig.text(.05,.041,'Mapped isolates: SENP2, ST6GAL1, ZC3H12B. Unmapped: VDR, VEGFA.',fontsize=10)
    fig.text(.05,.020,'All input genes and mapping status are retained in the accompanying tables.',fontsize=10,color='#555555')
    return fig
def single_module(rank):
    row=summary[summary.Cluster_rank==rank].iloc[0]
    size=(10,8) if rank==1 else (8.5,6) if rank==4 else (7.5,5)
    fig=plt.figure(figsize=size);module(fig.add_axes([.06,.17,.88,.68]),rank,font=11.5,scale=2)
    fig.text(.5,.945,f'MCODE Cluster {rank}',ha='center',fontsize=19,fontfamily='Times New Roman')
    fig.text(.5,.898,f'{row.Node_count} nodes | {row.Edge_count} edges | Score {row.MCODE_score:.6f} | Seed: {row.Seed_gene}',ha='center',fontsize=11)
    fig.text(.5,.075,'Node size: degree in the complete STRING PPI network. Lines: observed STRING associations.',ha='center',fontsize=10)
    if rank==4:fig.text(.5,.035,'Supplementary module: fourth-ranked MCODE result.',ha='center',fontsize=10,color='#555555')
    return fig
jobs=[('图8_组合主图',main),('图8A_扩展基因PPI网络',single_ppi)]+[(f'图8{panel}_MCODE_Cluster{rank}',lambda r=rank:single_module(r)) for rank,panel in [(1,'B'),(2,'C'),(3,'D')]]+[('图8补充_Cluster4',lambda:single_module(4))]
metadata={}
pdf=PdfPages(ROOT/'图8_主图与全部子图.pdf') if EXPORT else None
for name,builder in jobs:
    print('Rendering',name,flush=True);fig=builder();fig.savefig(Q/(name+'_preview.png'),dpi=140)
    metadata[name]=dict(Width_inches=fig.get_figwidth(),Height_inches=fig.get_figheight(),DPI=600)
    if EXPORT:
        fig.savefig(OUT/(name+'.png'),dpi=600);fig.savefig(OUT/(name+'.svg'));pdf.savefig(fig)
    plt.close(fig)
if pdf:pdf.close()
(A/'图像尺寸与格式.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
(A/'图形布局核对.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
for rank,m in moduledata.items():
    p=modulepos[rank][0];graph=G.subgraph(m.Gene_symbol).copy()
    for row in m.itertuples():graph.nodes[row.Gene_symbol].update(Gene_symbol=row.Gene_symbol,Entrez_ID=str(row.Entrez_ID),MCODE_cluster=int(rank),PPI_degree=int(row.PPI_degree),Cluster_degree=int(row.Cluster_degree),x=float(p[row.Gene_symbol][0]),y=float(p[row.Gene_symbol][1]),color=row.Node_color)
    for u,v in graph.edges():graph[u][v]['STRING_score']=float(edges[edges.Pair=='|'.join(sorted([u,v]))].iloc[0].score)
    nx.write_graphml(graph,ROOT/'Cytoscape可编辑网络'/f'Cluster{rank}.graphml')
graph=G.copy()
for row in nodes[nodes.Mapped].itertuples():graph.nodes[row.Gene_symbol].update(Gene_symbol=row.Gene_symbol,Entrez_ID=str(row.Entrez_ID),PPI_degree=int(row.PPI_degree),MCODE_clusters=row.MCODE_clusters,x=float(allpos[row.Gene_symbol][0]),y=float(allpos[row.Gene_symbol][1]))
for row in edges.itertuples():graph[row.Source][row.Target]['STRING_score']=float(row.score)
nx.write_graphml(graph,ROOT/'Cytoscape可编辑网络'/'图8A_完整映射网络103节点.graphml')
print('FIGURE8 DRAWING COMPLETE',flush=True)
