from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,datetime,time,shutil,gzip,io
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
R=ROOT/'原始数据';A=ROOT/'处理记录';T=ROOT/'各子图数据表'
for p in [R,A,T,ROOT/'图片',ROOT/'Cytoscape可编辑网络',A/'图片预览']:p.mkdir(parents=True,exist_ok=True)
BASE=Path('./Computational')
for src,name in [
    (BASE/'9.图5_GeneMANIA功能关联扩展/各网络数据表/原49基因_加入预测结果后去重.csv','输入_105个扩展候选基因.csv'),
    (BASE/'7.图3_PPI与核心靶点分析/原始数据/9606.protein.info.v12.0.txt.gz','9606.protein.info.v12.0.txt.gz'),
    (BASE/'7.图3_PPI与核心靶点分析/原始数据/9606.protein.info.v12.0.txt.gz.provenance.json','9606.protein.info.v12.0.txt.gz.provenance.json'),
    (BASE/'7.图3_PPI与核心靶点分析/各子图数据表/C_共同核心靶点.csv','输入_六个共同核心靶点.csv')]:
    if not (R/name).exists():shutil.copy2(src,R/name)

def fetch(url,name,params=None):
    dest=R/name
    if dest.exists():return dest.read_bytes()
    body=urllib.parse.urlencode(params).encode() if params else None
    for trial in range(3):
        try:
            req=urllib.request.Request(url,data=body,headers={'User-Agent':'AKI-Figure8-reproducible-research/1.0'})
            with urllib.request.urlopen(req,timeout=60) as response:data=response.read()
            dest.write_bytes(data)
            dest.with_name(dest.name+'.provenance.json').write_text(json.dumps(dict(URL=url,Parameters=params,Retrieved_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),Bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()),ensure_ascii=False,indent=2),encoding='utf-8')
            print(name,len(data),flush=True);time.sleep(1.05);return data
        except Exception:
            if trial==2:raise
            time.sleep(2)

inputs=pd.read_csv(R/'输入_105个扩展候选基因.csv',encoding='utf-8-sig',dtype={'Entrez_ID':str})
assert len(inputs)==105 and inputs.Gene_symbol.nunique()==105
info=pd.read_csv(io.BytesIO(gzip.decompress((R/'9606.protein.info.v12.0.txt.gz').read_bytes())),sep='\t',dtype=str)
rows=[]
for row in inputs.itertuples():
    matched=info[info.preferred_name==row.Gene_symbol]
    rows.append(dict(Gene_symbol=row.Gene_symbol,Entrez_ID=row.Entrez_ID,In_original49=row.In_original49,Is_Figure3_core=row.Is_Figure3_core,Newly_added=row.Newly_added,
        Match_count=len(matched),Mapped=len(matched)==1,STRING_ID=matched.iloc[0]['#string_protein_id'] if len(matched)==1 else '',
        STRING_preferred_name=matched.iloc[0].preferred_name if len(matched)==1 else '',
        Mapping_method='Unique exact preferred_name in official STRING v12.0 human protein.info',
        Status='Mapped' if len(matched)==1 else 'No unique exact mapping; retained in input audit only'))
mapping=pd.DataFrame(rows);mapping.to_csv(T/'输入105基因_STRING严格映射核对.csv',index=False,encoding='utf-8-sig')
ids=mapping.loc[mapping.Mapped,'STRING_ID'].tolist()
assert len(ids)==len(set(ids))
base='https://version-12-0.string-db.org'
fetch(base+'/api/json/version','STRING_version.json')
fetch(base+'/api/tsv/network','STRING_105输入_严格映射_功能关联网络_0.4.tsv',dict(identifiers='\r'.join(ids),species=9606,required_score=400,network_type='functional',add_nodes=0,caller_identity='AKI-Figure8-reproducible-research'))
for name,url in [('MCODE官方调参说明.html','https://mcode.readthedocs.io/en/latest/Tuning.html'),('MCODE官方导出说明.html','https://mcode.readthedocs.io/en/latest/Outputting.html')]:fetch(url,name)
print(mapping[['Mapped','Status']].value_counts().to_string());print(mapping.loc[~mapping.Mapped,['Gene_symbol','Match_count']].to_string(index=False))
