from pathlib import Path
import sys,json,math,hashlib,zipfile,xml.etree.ElementTree as ET
sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
import pandas as pd,numpy as np,networkx as nx,openpyxl,pdfplumber
from PIL import Image
from pypdf import PdfReader
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
A=ROOT/'处理记录';T=ROOT/'各子图数据表';R=ROOT/'原始数据';checks=[]
def check(name,ok,detail=''):checks.append(dict(Check=name,Passed=bool(ok),Detail=str(detail)))
def read(name):return pd.read_csv(T/name,encoding='utf-8-sig',keep_default_na=False,float_precision='round_trip')
nodes=read('A_PPI全部105输入节点核对.csv');edges=read('A_PPI全部连线.csv');summary=read('MCODE_全部模块汇总.csv')
inputs=pd.read_csv(R/'输入_105个扩展候选基因.csv',encoding='utf-8-sig')
core=set(pd.read_csv(R/'输入_六个共同核心靶点.csv',encoding='utf-8-sig').Gene_symbol)
answer=json.loads((A/'MCODE官方插件完整返回.json').read_text(encoding='utf-8'));cy=json.loads((A/'Cytoscape节点表_运行后.json').read_text(encoding='utf-8'))['rows'];suid={r['SUID']:r for r in cy}
check('All105 unique input genes preserved',len(nodes)==105 and nodes.Gene_symbol.nunique()==105 and set(nodes.Gene_symbol)==set(inputs.Gene_symbol))
check('Original49 and added56 kept',nodes.In_original49.sum()==49 and nodes.Newly_added.sum()==56)
check('103 exact mappings and 2 audited unmapped',nodes.Mapped.sum()==103 and set(nodes.loc[~nodes.Mapped,'Gene_symbol'])=={'VDR','VEGFA'})
G=nx.Graph();G.add_nodes_from(nodes.loc[nodes.Mapped,'Gene_symbol']);G.add_edges_from(zip(edges.Source,edges.Target))
check('Exact1108 undirected simple edges',len(edges)==1108 and G.number_of_edges()==1108 and not edges.Pair.duplicated().any() and nx.number_of_selfloops(G)==0)
check('No added proteins',set(edges.Source)|set(edges.Target)<=set(nodes.loc[nodes.Mapped,'Gene_symbol']))
check('Human STRING threshold enforced',edges.ncbiTaxonId.eq(9606).all() and edges.score.between(.4,1).all())
check('100 connected nodes and correct3 isolates',sum(d>0 for _,d in G.degree())==100 and set(nx.isolates(G))=={'SENP2','ST6GAL1','ZC3H12B'})
check('Every mapped degree matches edge table',all(G.degree(r.Gene_symbol)==r.PPI_degree for r in nodes[nodes.Mapped].itertuples()))
check('Official MCODE returned without errors',not answer['errors'] and not answer['data']['stale'])
p=answer['data']['parameters']
check('MCODE stated parameters actually used',p['degreeCutoff']==2 and p['nodeScoreCutoff']==.2 and p['kCore']==2 and p['maxDepthFromStart']==100 and p['haircut'] and not p['fluff'] and not p['includeLoops'] and p['scope']=='NETWORK')
check('All4 official modules retained',len(summary)==len(answer['data']['clusters'])==4 and list(summary.Cluster_rank)==[1,2,3,4])
scorecheck=read('MCODE节点得分_独立核对.csv');check('All103 official node scores independently reproduced',len(scorecheck)==103 and scorecheck.Absolute_difference.eq(0).all())
check('Unmapped scores and positions remain blank',all(nodes.loc[~nodes.Mapped,f].eq('').all() for f in ['MCODE_node_score','Plot_X','Plot_Y']))
check('Actual mapped zero scores preserved for isolates',pd.to_numeric(nodes.loc[nodes.PPI_status=='Mapped isolate','MCODE_node_score']).eq(0).all())
members=[];allm=[]
for cluster,row in zip(answer['data']['clusters'],summary.itertuples()):
    rank=row.Cluster_rank;panel=row.Panel;expected={suid[i]['Gene_symbol'] for i in cluster['nodes']}
    m=read(f'{panel}_Cluster{rank}_节点.csv');e=read(f'{panel}_Cluster{rank}_连线.csv');H=G.subgraph(expected);members.append(expected);allm.append(m)
    check(f'Cluster{rank} exact official membership',set(m.Gene_symbol)==expected and len(m)==len(expected)==row.Node_count)
    pairs={'|'.join(sorted([u,v])) for u,v in H.edges()}
    check(f'Cluster{rank} exact induced edges',set(e.Pair)==pairs and len(e)==H.number_of_edges()==row.Edge_count)
    check(f'Cluster{rank} density independently recomputed',math.isclose(nx.density(H),row.Density,rel_tol=1e-13))
    check(f'Cluster{rank} official score matches topology',math.isclose(2*H.number_of_edges()/(len(H)-1),cluster['score'],rel_tol=1e-13) and math.isclose(cluster['score'],row.MCODE_score,rel_tol=1e-13))
    check(f'Cluster{rank} seed and node degrees match',row.Seed_gene==suid[cluster['seedNode']]['Gene_symbol'] and set(m.loc[m.Is_seed,'Gene_symbol'])=={row.Seed_gene} and all(r.Cluster_degree==H.degree(r.Gene_symbol) and r.PPI_degree==G.degree(r.Gene_symbol) for r in m.itertuples()))
    check(f'Cluster{rank} all members in a2core',min(dict(H.degree()).values())>=2)
    check(f'Cluster{rank} official node table agrees',all(f'Cluster {rank}' in suid[int(r.Cytoscape_SUID)].get(f'MCODE::Clusters ({answer["data"]["id"]})',[]) for r in m.itertuples()))
    graph=nx.read_graphml(ROOT/'Cytoscape可编辑网络'/f'Cluster{rank}.graphml')
    check(f'Cluster{rank} editable GraphML topology',set(graph)==expected and {'|'.join(sorted(e)) for e in graph.edges()}==pairs)
check('Clusters disjoint with fluff disabled',len(set().union(*members))==sum(map(len,members)))
check('All6 original core targets in Cluster1',core<=members[0])
check('Main3 and supplementary4 accurately tagged',summary.loc[summary.Cluster_rank<=3,'Displayed_in_main'].all() and not summary.loc[summary.Cluster_rank==4,'Displayed_in_main'].any())
check('Module ranking descending score',summary.MCODE_score.is_monotonic_decreasing)
fullgraph=nx.read_graphml(ROOT/'Cytoscape可编辑网络/图8A_完整映射网络103节点.graphml')
check('Full103 network GraphML exact topology',set(fullgraph)==set(G) and set(map(frozenset,fullgraph.edges()))==set(map(frozenset,G.edges())))
layout=json.loads((A/'图形布局核对.json').read_text(encoding='utf-8'));check('No PPI text label overlaps in main',all(not x['PPI_label_overlaps'] for x in layout))
cys=ROOT/'Cytoscape可编辑网络/Cytoscape官方MCODE原始分析.cys'
with zipfile.ZipFile(cys) as archive:check('NativeCytoscape session valid archive',archive.testzip() is None and len(archive.namelist())>10)

payload=json.loads((A/'workbook_payload.json').read_text(encoding='utf-8'))
wf=openpyxl.load_workbook(ROOT/'图8_各子图节点连线与MCODE结果.xlsx',data_only=False);wv=openpyxl.load_workbook(ROOT/'图8_各子图节点连线与MCODE结果.xlsx',data_only=True)
check('Workbook has all12 requested sheets',wf.sheetnames==[s['name'] for s in payload['sheets']] and len(wf.sheetnames)==12)
for spec in payload['sheets']:
    ws=wf[spec['name']];vs=wv[spec['name']];ok=True;types=True
    for i,row in enumerate(spec['rows'],8):
        for j,value in enumerate(row,1):
            c=vs.cell(i,j).value
            if value is None or value=='':good=c is None or c==''
            elif isinstance(value,(int,float)) and not isinstance(value,bool):
                good=isinstance(c,(int,float)) and math.isclose(c,value,rel_tol=1e-13,abs_tol=1e-15);types&=isinstance(c,(int,float))
            else:good=c==value
            ok&=good
    check(spec['name']+' all saved values match',ok);check(spec['name']+' numeric cells are numeric',types)
    check(spec['name']+' correct headers',[ws.cell(7,j).value for j in range(1,len(spec['fields'])+1)]==spec['labels'])
    check(spec['name']+' native counter filter freeze',vs['B6'].value==len(spec['rows']) and ws['B6'].data_type=='f' and len(ws.tables)==1 and ws.freeze_panes=='B8')
    check(spec['name']+' no error cells',all(c.data_type!='e' for row in ws for c in row))
check('Module density and score are live formulas',all(wf['模块汇总'].cell(i,j).data_type=='f' for i in range(8,12) for j in [6,7]))
manifest=json.loads((A/'图像尺寸与格式.json').read_text(encoding='utf-8'))
for name,spec in manifest.items():
    im=Image.open(ROOT/'图片'/(name+'.png'))
    check(name+' expected600dpi and dimensions',all(abs(d-600)<.1 for d in im.info['dpi']) and abs(im.width-spec['Width_inches']*600)<1.1 and abs(im.height-spec['Height_inches']*600)<1.1)
    svg=ET.parse(ROOT/'图片'/(name+'.svg')).getroot();ns={'s':'http://www.w3.org/2000/svg'}
    check(name+' SVG vector and editable text',len(svg.findall('.//s:text',ns))>0 and not svg.findall('.//s:image',ns))
pdf=PdfReader(ROOT/'图8_主图与全部子图.pdf');check('PDF6 pages',len(pdf.pages)==6)
with pdfplumber.open(ROOT/'图8_主图与全部子图.pdf') as doc:
    for i,page in enumerate(doc.pages,1):
        check(f'PDF{i} vector without raster images',not page.images)
        check(f'PDF{i} text within page',all(-.1<=c['x0']<c['x1']<=page.width+.1 and -.1<=c['top']<c['bottom']<=page.height+.1 for c in page.chars))
        check(f'PDF{i} extractable text',len(page.extract_text())>60)
check('All6 PDF pages rendered',len(list((A/'PDF预览').glob('图8-*.png')))==6)
for item in json.loads((A/'原始输入与注释_SHA256.json').read_text(encoding='utf-8')):
    check('Source unchanged '+item['File'],hashlib.sha256((ROOT/item['File']).read_bytes()).hexdigest()==item['SHA256'])
failed=[c for c in checks if not c['Passed']]
result=dict(checks=len(checks),passed=len(checks)-len(failed),failed=failed,input_genes=105,mapped=103,connected=100,edges=1108,
    cluster_count=4,cluster_nodes=summary.Node_count.tolist(),cluster_edges=summary.Edge_count.tolist(),MCODE_node_score_max_difference=float(scorecheck.Absolute_difference.max()),pdf_pages=6,workbook_sheets=12)
pd.DataFrame(checks).to_csv(A/'完整复核结果.csv',index=False,encoding='utf-8-sig');(A/'validation_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False));assert not failed
