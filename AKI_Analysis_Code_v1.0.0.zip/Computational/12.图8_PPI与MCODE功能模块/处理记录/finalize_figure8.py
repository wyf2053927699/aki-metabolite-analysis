from pathlib import Path
import json,subprocess,hashlib
from pypdf import PdfReader
from PIL import Image,ImageDraw,ImageFont
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
A=ROOT/'处理记录';Q=A/'PDF预览';Q.mkdir(exist_ok=True)
pdf=ROOT/'图8_主图与全部子图.pdf'
exe='./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
run=subprocess.run([exe,'-r','105','-png',str(pdf),str(Q/'图8')],capture_output=True,text=True)
(A/'PDF渲染日志.txt').write_text(run.stdout+run.stderr,encoding='utf-8');assert run.returncode==0
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',19)
def contact(files,dest,w=1350,h=540,cols=1):
    canvas=Image.new('RGB',(cols*w,h*((len(files)+cols-1)//cols)),'#E5E9EE');draw=ImageDraw.Draw(canvas)
    for i,p in enumerate(files):
        x=i%cols*w;y=i//cols*h;im=Image.open(p).convert('RGB');im.thumbnail((w-24,h-44))
        draw.text((x+12,y+8),p.stem,font=font,fill='#253B52');canvas.paste(im,(x+(w-im.width)//2,y+36))
    canvas.save(dest)
contact(sorted(Q.glob('图8-*.png')),A/'PDF全部页面_检查总览.png',w=950,h=850,cols=2)
files=sorted(A.glob('Excel预览_*.png'))
for i in range(0,len(files),3):contact(files[i:i+3],A/f'Excel检查总览_{i//3+1}.png')
Image.open(A/'图片预览/图8_组合主图_preview.png').convert('L').save(A/'图片预览/图8_组合主图_灰度检查.png')
files=list((ROOT/'图片').glob('*'))+list((ROOT/'Cytoscape可编辑网络').glob('*'))+[pdf,ROOT/'图8_各子图节点连线与MCODE结果.xlsx']
(A/'交付文件_SHA256.json').write_text(json.dumps([dict(File=str(p.relative_to(ROOT)).replace('\\','/'),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(pdf_pages=len(PdfReader(pdf).pages),rendered_pages=len(list(Q.glob('图8-*.png'))),deliverable_files=len(files))))
