from pathlib import Path
import sys,csv,platform,importlib.metadata,json,zipfile
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'处理记录/python_deps'))
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
packages=['networkx','numpy','pandas','scipy','matplotlib','Pillow','pypdf','pdfplumber','openpyxl']
rows=[dict(Package='Python',Version=platform.python_version())]+[dict(Package=p,Version=importlib.metadata.version(p)) for p in packages]
with (ROOT/'处理记录/Python软件版本.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['Package','Version']);w.writeheader();w.writerows(rows)
(ROOT/'requirements_figure8.txt').write_text('\n'.join(r['Package']+'=='+r['Version'] for r in rows[1:])+'\n',encoding='utf-8')
jar=ROOT/'原始数据/MCODE-v2.0.3.jar'
with zipfile.ZipFile(jar) as z:manifest=z.read('META-INF/MANIFEST.MF').decode('utf-8')
(ROOT/'处理记录/MCODE_Jar_MANIFEST.txt').write_text(manifest,encoding='utf-8')
assert 'Bundle-Version: 2.0.3' in manifest
print(json.dumps(rows,ensure_ascii=False))
