from pathlib import Path
import json,urllib.request,urllib.parse,hashlib,shutil,sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
import pandas as pd,networkx as nx

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='处理记录' else Path('./Computational/12.图8_PPI与MCODE功能模块')
R=ROOT/'原始数据';T=ROOT/'各子图数据表';A=ROOT/'处理记录'
API='http://127.0.0.1:1234/v1'
def call(route,method='GET',data=None):
    body=json.dumps(data,ensure_ascii=False).encode('utf-8') if data is not None else None
    req=urllib.request.Request(API+'/'+route,data=body,method=method,headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=180) as resp:rawdata=resp.read()
    except urllib.error.HTTPError as e:
        message=e.read().decode('utf-8',errors='replace')
        (A/'Cytoscape最近一次请求错误.txt').write_text(route+'\n'+message,encoding='utf-8')
        raise RuntimeError(f'{method} {route}: HTTP {e.code}: '+message[:1200]) from e
    try:return json.loads(rawdata)
    except json.JSONDecodeError:return rawdata.decode('utf-8')
def save(x,name):(A/name).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
mapping=pd.read_csv(T/'输入105基因_STRING严格映射核对.csv',encoding='utf-8-sig',keep_default_na=False,dtype={'Entrez_ID':str})
raw=pd.read_csv(R/'STRING_105输入_严格映射_功能关联网络_0.4.tsv',sep='\t')
lookup=dict(zip(mapping.STRING_ID,mapping.Gene_symbol));lookup.pop('',None)
assert set(raw.stringId_A)|set(raw.stringId_B)<=set(lookup)
assert raw.score.ge(.4).all() and raw.ncbiTaxonId.eq(9606).all()
edges=raw.copy();edges['Source']=edges.stringId_A.map(lookup);edges['Target']=edges.stringId_B.map(lookup)
edges['Pair']=edges.apply(lambda r:'|'.join(sorted([r.Source,r.Target])),axis=1)
assert not edges.Pair.duplicated().any() and (edges.Source!=edges.Target).all()
edges=edges.sort_values('Pair').reset_index(drop=True);edges['Edge_ID']=['e'+str(i+1) for i in range(len(edges))]
edges.to_csv(T/'A_PPI全部连线.csv',index=False,encoding='utf-8-sig')
G=nx.Graph();G.add_nodes_from(mapping.loc[mapping.Mapped,'Gene_symbol']);G.add_edges_from(zip(edges.Source,edges.Target))
mapping['PPI_degree']=mapping.Gene_symbol.map(dict(G.degree())).fillna(0).astype(int)
mapping['PPI_status']=mapping.apply(lambda r:'Unmapped' if not r.Mapped else 'Connected' if r.PPI_degree>0 else 'Mapped isolate',axis=1)
mapping.to_csv(T/'A_PPI全部105输入节点核对.csv',index=False,encoding='utf-8-sig')
save(call('version'),'Cytoscape版本.json')
save(call('commands/mcode/cluster'),'MCODE命令参数说明.json')
nodes=[]
for row in mapping[mapping.Mapped].itertuples():nodes.append({'data':{'id':row.Gene_symbol,'name':row.Gene_symbol,'Gene_symbol':row.Gene_symbol,'Entrez_ID':row.Entrez_ID,'STRING_ID':row.STRING_ID,'In_original49':bool(row.In_original49),'Figure3_core':bool(row.Is_Figure3_core)}})
cyedges=[{'data':{'id':r.Edge_ID,'source':r.Source,'target':r.Target,'interaction':'STRING_functional','STRING_score':float(r.score)}} for r in edges.itertuples()]
payload={'data':{'name':'AKI Figure8 | 105 input genes | STRING v12.0 functional >=0.4'},'elements':{'nodes':nodes,'edges':cyedges}}
save(payload,'Cytoscape输入网络_CyJS.json')
created_path=A/'Cytoscape创建网络返回.json'
if created_path.exists():
    previous=json.loads(created_path.read_text(encoding='utf-8'));existing=call('networks')
    created=previous if previous['networkSUID'] in existing else call('networks','POST',payload)
else:created=call('networks','POST',payload)
save(created,'Cytoscape创建网络返回.json');suid=created['networkSUID']
save(call(f'networks/{suid}/tables/defaultnode'),'Cytoscape节点表_运行前.json')
params=dict(degreeCutoff='2',fluff='false',fluffNodeDensityCutoff='0.1',haircut='true',includeLoops='false',kCore='2',maxDepthFromStart='100',network='SUID:'+str(suid),nodeScoreCutoff='0.2',scope='NETWORK')
save(params,'MCODE实际运行参数.json')
print('MCODE request',json.dumps(params),flush=True)
answer=call('commands/mcode/cluster','POST',params);save(answer,'MCODE官方插件完整返回.json')
save(call(f'networks/{suid}/tables/defaultnode'),'Cytoscape节点表_运行后.json')
save(call(f'networks/{suid}'),'Cytoscape网络_运行后.json')
jar=Path('./local_user/CytoscapeConfiguration/3/apps/installed/MCODE-v2.0.3.jar')
shutil.copy2(jar,R/jar.name)
save(dict(App='MCODE',Version='2.0.3',Jar_path=str(jar),SHA256=hashlib.sha256(jar.read_bytes()).hexdigest()),'MCODE插件版本与SHA256.json')
print('Network',suid,'mapped',G.number_of_nodes(),'connected',sum(d>0 for n,d in G.degree()),'edges',G.number_of_edges(),flush=True)
print(json.dumps(answer,ensure_ascii=False)[:18000],flush=True)
