from pathlib import Path
from collections import defaultdict,Counter
import csv,io,json,hashlib,re,math
import openpyxl

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'汇总去重';AUDIT=OUT/'处理记录'
mapping_file=ROOT.parent/'0.化合物SMILES数据表.xlsx'
ws=openpyxl.load_workbook(mapping_file,read_only=True,data_only=True).active
assert list(next(ws.iter_rows(min_row=1,max_row=1,values_only=True)))==['CID','Name','SMILES']
mapping={str(r[0]).strip():{'name':r[1],'smiles':r[2]} for r in ws.iter_rows(min_row=2,values_only=True) if r[0]}
headers=['Target','Common name','Uniprot ID','ChEMBL ID','Target Class','Probability*','Known actives (3D/2D)']
manifest=[];relations=[];file_rows=[];groups=defaultdict(list)
for p in sorted(ROOT.glob('*.csv'),key=lambda p:int(p.stem)):
    content=p.read_bytes();reader=csv.DictReader(io.StringIO(content.decode('utf-8-sig'),newline=''))
    assert reader.fieldnames==headers,(p,reader.fieldnames)
    original=list(reader);cid=p.stem;assert cid in mapping
    manifest.append({'file':p.name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'records':len(original)})
    current=[]
    for source_row,r in enumerate(original,2):
        assert None not in r and all(v is not None for v in r.values()),(p,source_row,r)
        probability=float(r['Probability*']);assert math.isfinite(probability) and 0<=probability<=1
        target_id=r['ChEMBL ID'].strip();assert re.fullmatch(r'CHEMBL\d+',target_id)
        common=r['Common name'].strip();uniprot=r['Uniprot ID'].strip()
        accessions=uniprot.split('&');assert all(re.fullmatch(r'[A-Z0-9]{6}|[A-Z0-9]{10}',a) for a in accessions)
        count=re.fullmatch(r'\s*(\d+)\s*/\s*(\d+)\s*(?:&nbsp;?)?\s*',r['Known actives (3D/2D)'])
        assert count,(p,source_row,r['Known actives (3D/2D)'])
        note='原文件未提供基因名称' if not common else '多基因共享靶点注释' if ';' in common else '原文件单基因注释'
        record={'Compound_CID':cid,'Metabolite':mapping[cid]['name'],'ChEMBL_ID':target_id,
            'Gene_annotation_raw':r['Common name'],'Target':r['Target'],'UniProt_ID_raw':r['Uniprot ID'],
            'Target_class':r['Target Class'],'Probability':probability,'Probability_raw':r['Probability*'],
            'Known_actives_3D':int(count[1]),'Known_actives_2D':int(count[2]),
            'Known_actives_raw':r['Known actives (3D/2D)'],
            'UniProt_accession_count':len(accessions),'Gene_annotation_note':note,
            'Source_file':p.name,'Source_CSV_record':source_row}
        relations.append(record);current.append(record);groups[target_id].append(record)
    ps=[r['Probability'] for r in current]
    file_rows.append({'Compound_CID':cid,'Metabolite':mapping[cid]['name'],'Source_file':p.name,
        'Original_record_count':len(current),'Unique_ChEMBL_targets':len({r['ChEMBL_ID'] for r in current}),
        'Nonempty_gene_annotation_records':sum(bool(r['Gene_annotation_raw'].strip()) for r in current),
        'Blank_gene_annotation_records':sum(not r['Gene_annotation_raw'].strip() for r in current),
        'Min_Probability':min(ps) if ps else None,'Max_Probability':max(ps) if ps else None,
        'Probability_zero_records':sum(v==0 for v in ps),'Input_SHA256':manifest[-1]['sha256']})

def joined(values):return ' | '.join(dict.fromkeys(str(v) for v in values if v is not None and str(v)!=''))
targets=[];by_gene=defaultdict(list)
for target_id,rows in sorted(groups.items(),key=lambda kv:int(kv[0][6:])):
    common=joined(r['Gene_annotation_raw'].strip() for r in rows)
    uniprots={r['UniProt_ID_raw'].strip() for r in rows};assert len(uniprots)==1,(target_id,uniprots)
    names={r['Target'] for r in rows};classes={r['Target_class'] for r in rows}
    best=max(rows,key=lambda r:r['Probability'])
    target={'ChEMBL_ID':target_id,'Gene_annotation_raw':common,'Target':joined(r['Target'] for r in rows),
        'Max_Probability':best['Probability'],'Metabolite_count':len({r['Compound_CID'] for r in rows}),
        'UniProt_ID_raw':next(iter(uniprots)),'Target_class':joined(r['Target_class'] for r in rows),
        'UniProt_accession_count':best['UniProt_accession_count'],
        'Gene_annotation_note':best['Gene_annotation_note'],
        'Source_record_count':len(rows),'Best_score_CIDs':joined(r['Compound_CID'] for r in rows if r['Probability']==best['Probability']),
        'All_source_CIDs':joined(sorted({r['Compound_CID'] for r in rows},key=int)),
        'Annotation_variants':max(len(names),len(classes),len({r['Gene_annotation_raw'] for r in rows}))}
    targets.append(target)
    for symbol in common.split(';'):
        symbol=symbol.strip()
        if symbol:
            assert re.fullmatch(r'[A-Za-z0-9_.-]+',symbol)
            by_gene[symbol].extend(rows)
genes=[]
for symbol,rows in sorted(by_gene.items()):
    genes.append({'Gene_symbol_from_STP':symbol,'Metabolite_count':len({r['Compound_CID'] for r in rows}),
        'Target_entry_count':len({r['ChEMBL_ID'] for r in rows}),'ChEMBL_IDs':joined(sorted({r['ChEMBL_ID'] for r in rows},key=lambda s:int(s[6:]))),
        'UniProt_IDs_raw':joined(sorted({r['UniProt_ID_raw'] for r in rows})),
        'Max_Probability':max(r['Probability'] for r in rows),
        'Shared_gene_annotation_record_count':sum(';' in r['Gene_annotation_raw'] for r in rows)})

summary={'source_directory':str(ROOT),'input_files':len(manifest),'input_record_count':len(relations),
    'unique_compound_CIDs':len({r['Compound_CID'] for r in relations}),
    'deduplicated_target_entries':len(targets),'existing_gene_symbols':len(genes),
    'targets_without_gene_annotation':sum(not r['Gene_annotation_raw'] for r in targets),
    'records_without_gene_annotation':sum(not r['Gene_annotation_raw'] for r in relations),
    'single_accession_targets':sum(r['UniProt_accession_count']==1 for r in targets),
    'multi_accession_targets':sum(r['UniProt_accession_count']>1 for r in targets),
    'unique_component_UniProt_accessions':len({a for r in targets for a in r['UniProt_ID_raw'].split('&')}),
    'probability_zero_records':sum(r['Probability']==0 for r in relations),
    'min_probability':min(r['Probability'] for r in relations),'max_probability':max(r['Probability'] for r in relations),
    'within_compound_duplicate_occurrences':len(relations)-len({(r['Compound_CID'],r['ChEMBL_ID']) for r in relations}),
    'duplicate_target_occurrences_collapsed':len(relations)-len(targets),
    'records_per_file_distribution':dict(Counter(r['Original_record_count'] for r in file_rows)),
    'target_annotation_variant_count':sum(r['Annotation_variants']>1 for r in targets),
    'deduplication_key':'ChEMBL target ID; preserve protein complexes/multi-accession entries intact',
    'additional_filter':'none; retain all downloaded records and all returned probabilities',
    'organism_policy':'CSV files provide no organism column; no organism was inferred or filtered',
    'mapping_source':{'file':str(mapping_file),'sha256':hashlib.sha256(mapping_file.read_bytes()).hexdigest()},
    'workbook':'STP代谢物靶点_汇总去重.xlsx'}

def csv_out(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csv_out('STP_去重靶点.csv',targets);csv_out('STP_全部代谢物靶点记录.csv',relations)
csv_out('STP_文件汇总.csv',file_rows);csv_out('STP_原文件已有基因注释_去重.csv',genes)
(OUT/'STP_原文件已有基因符号_1195个.txt').write_text('\n'.join(r['Gene_symbol_from_STP'] for r in genes)+'\n',encoding='utf-8-sig')
(OUT/'STP_去重ChEMBL靶点编号_1277个.txt').write_text('\n'.join(r['ChEMBL_ID'] for r in targets)+'\n',encoding='utf-8-sig')
payload={'summary':summary}
for key,rows in [('targets',targets),('relations',relations),('files',file_rows)]:
    payload[key]={'fields':list(rows[0]),'rows':[list(r.values()) for r in rows]}
(AUDIT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(AUDIT/'input_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'汇总去重说明.txt').write_text(f'''SwissTargetPrediction（STP）下载结果汇总与去重

范围：{ROOT} 顶层现有168个CSV文件。原文件不作改动。
共16,720条代谢物—靶点记录，168个CID；167个文件各100条，1117.csv为20条。
代谢物名称来自同项目0.化合物SMILES数据表.xlsx，按文件名CID精确匹配，168个文件全部匹配。

去重：按ChEMBL靶点编号跨代谢物合并，共1,277个靶点条目。
同一靶点保留原始UniProt组合、基因注释、靶点名称、类别；汇总关联代谢物数、来源记录数、最大Probability及其来源CID。
“最大Probability”是各分子独立预测概率的最大值，不是新的疾病相关性评分。
各分子的原始Probability文本、源文件及原始CSV记录号保留在明细表，Known actives原始字段也保留。
Known actives的3D与2D计数另列为整数，末尾HTML占位文字不影响数值。

全部返回记录均保留，无Probability阈值、物种筛选、疾病交集或靶点类别筛选。
CSV没有物种列，本次没有推断查询物种。
UniProt字段含“&”的多蛋白条目完整保留；不把同一条预测评分当作各组分蛋白的独立预测。
共{summary['multi_accession_targets']}个多UniProt条目、{summary['single_accession_targets']}个单UniProt条目。
82个靶点条目（947条明细记录）无Common name注释，仍保留于总表。

基因清单只整理原文件已有Common name注释，按分号拆分，去重为1,195个符号。
LGALS7; LGALS7B为共享靶点注释，两基因共享原条目评分，不代表基因特异性已被区分。
未对无基因名称条目进行在线补充映射，亦未声称已有基因注释覆盖全部多蛋白组分。

交付：
STP代谢物靶点_汇总去重.xlsx：去重靶点、全部代谢物—靶点明细、168个输入文件汇总。
同目录CSV、ChEMBL编号TXT及已有基因符号TXT供后续分析。
处理记录/：来源哈希、计数、脚本、核对结果和工作簿预览。
''',encoding='utf-8-sig')
print(json.dumps(summary,ensure_ascii=True,indent=2))
