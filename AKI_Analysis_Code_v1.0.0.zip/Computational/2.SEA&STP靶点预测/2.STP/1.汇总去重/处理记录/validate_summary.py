from pathlib import Path
from collections import Counter,defaultdict
import csv,io,json,hashlib,math,re
import openpyxl
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'汇总去重';AUDIT=OUT/'处理记录'
summary=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
manifest=json.loads((AUDIT/'input_manifest.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'))
checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:print('FAILED',name,detail)
def read_csv(name):
    with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
original=[]
for m in manifest:
    p=ROOT/m['file'];b=p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==m['sha256'],p
    rows=list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'),newline='')))
    assert len(rows)==m['records'],p
    original.extend({'Source_file':p.name,'Source_CSV_record':i,**r} for i,r in enumerate(rows,2))
check('168个原始文件哈希及记录数不变',len(manifest)==168 and len(original)==16720)
check('输入文件清单覆盖完整文件夹',{m['file'] for m in manifest}=={p.name for p in ROOT.glob('*.csv')})
mp=summary['mapping_source'];check('名称映射文件哈希不变',hashlib.sha256(Path(mp['file']).read_bytes()).hexdigest()==mp['sha256'])
targets=read_csv('STP_去重靶点.csv');relations=read_csv('STP_全部代谢物靶点记录.csv');files=read_csv('STP_文件汇总.csv');genes=read_csv('STP_原文件已有基因注释_去重.csv')
raw_by_source={(r['Source_file'],r['Source_CSV_record']):r for r in original}
merged_by_source={(r['Source_file'],int(r['Source_CSV_record'])):r for r in relations}
check('全部16720条来源记录一对一保留',len(relations)==len(merged_by_source)==len(raw_by_source) and set(merged_by_source)==set(raw_by_source))
check('源靶点编号名称类别基因及原始评分完整保留',all(
    r['ChEMBL_ID']==raw_by_source[k]['ChEMBL ID'] and r['Target']==raw_by_source[k]['Target']
    and r['UniProt_ID_raw']==raw_by_source[k]['Uniprot ID'] and r['Gene_annotation_raw']==raw_by_source[k]['Common name']
    and r['Target_class']==raw_by_source[k]['Target Class'] and r['Probability_raw']==raw_by_source[k]['Probability*']
    and r['Known_actives_raw']==raw_by_source[k]['Known actives (3D/2D)'] for k,r in merged_by_source.items()))
check('所有评分合法且数值保持不变',all(math.isfinite(float(r['Probability'])) and 0<=float(r['Probability'])<=1 and float(r['Probability'])==float(r['Probability_raw']) for r in relations))
by_target=defaultdict(list);by_file=defaultdict(list)
for r in relations:by_target[r['ChEMBL_ID']].append(r);by_file[r['Source_file']].append(r)
check('去重靶点仅按ChEMBL编号且无遗漏',len(targets)==len({r['ChEMBL_ID'] for r in targets})==1277 and {r['ChEMBL_ID'] for r in targets}==set(by_target))
check('靶点汇总计数与最大评分准确',all(
    int(t['Source_record_count'])==len(by_target[t['ChEMBL_ID']])
    and int(t['Metabolite_count'])==len({r['Compound_CID'] for r in by_target[t['ChEMBL_ID']]})
    and float(t['Max_Probability'])==max(float(r['Probability']) for r in by_target[t['ChEMBL_ID']])
    and set(t['All_source_CIDs'].split(' | '))=={r['Compound_CID'] for r in by_target[t['ChEMBL_ID']]}
    for t in targets))
check('多UniProt组合保持原样且组分数准确',all(t['UniProt_ID_raw'] in {r['UniProt_ID_raw'] for r in by_target[t['ChEMBL_ID']]} and int(t['UniProt_accession_count'])==len(t['UniProt_ID_raw'].split('&')) for t in targets))
check('82个空基因注释条目全部保留',sum(not t['Gene_annotation_raw'] for t in targets)==82 and sum(not r['Gene_annotation_raw'] for r in relations)==947)
check('82个多蛋白条目完整保留',sum(int(t['UniProt_accession_count'])>1 for t in targets)==82)
check('全部源文件均进入汇总',len(files)==168 and {r['Source_file'] for r in files}==set(by_file))
check('每个文件记录数与去重计数准确',all(int(f['Original_record_count'])==len(by_file[f['Source_file']]) and int(f['Unique_ChEMBL_targets'])==len({r['ChEMBL_ID'] for r in by_file[f['Source_file']]}) for f in files))
check('167个100条文件与1个20条文件准确',Counter(int(f['Original_record_count']) for f in files)==Counter({100:167,20:1}) and next(f for f in files if f['Source_file']=='1117.csv')['Original_record_count']=='20')
mw=openpyxl.load_workbook(Path(mp['file']),read_only=True,data_only=True).active
names={str(r[0]):r[1] for r in mw.iter_rows(min_row=2,values_only=True) if r[0]}
check('所有代谢物按文件名CID精确关联名称',all(r['Compound_CID']==Path(r['Source_file']).stem and r['Metabolite']==names[r['Compound_CID']] for r in relations))
expected_genes={s.strip() for r in original for s in r['Common name'].split(';') if s.strip()}
check('已有基因符号清单正确去重且不猜测补充',len(genes)==len({g['Gene_symbol_from_STP'] for g in genes})==1195 and {g['Gene_symbol_from_STP'] for g in genes}==expected_genes)
check('TXT基因与靶点编号均覆盖正确集合',set((OUT/'STP_原文件已有基因符号_1195个.txt').read_text(encoding='utf-8-sig').splitlines())==expected_genes and set((OUT/'STP_去重ChEMBL靶点编号_1277个.txt').read_text(encoding='utf-8-sig').splitlines())==set(by_target))

book=OUT/summary['workbook'];wb=openpyxl.load_workbook(book,data_only=False);cache=openpyxl.load_workbook(book,data_only=True)
specs=[('去重靶点','targets',['ChEMBL_ID','Gene_annotation_raw','Target','Max_Probability','Metabolite_count','UniProt_ID_raw','Target_class','UniProt_accession_count','Gene_annotation_note','Source_record_count','Best_score_CIDs']),
 ('代谢物靶点明细','relations',['Compound_CID','Metabolite','Gene_annotation_raw','ChEMBL_ID','Probability','Target','UniProt_ID_raw','Target_class','Probability_raw','Known_actives_3D','Known_actives_2D','Known_actives_raw','UniProt_accession_count','Gene_annotation_note','Source_file','Source_CSV_record']),
 ('文件汇总','files',['Compound_CID','Metabolite','Source_file','Original_record_count','Unique_ChEMBL_targets','Nonempty_gene_annotation_records','Blank_gene_annotation_records','Min_Probability','Max_Probability','Probability_zero_records','Input_SHA256'])]
check('工作表结构正确',wb.sheetnames==[s[0] for s in specs])
for name,key,fields in specs:
    ws=wb[name];data=payload[key];index={f:i for i,f in enumerate(data['fields'])}
    expected=[[r[index[f]] for f in fields] for r in data['rows']]
    actual=list(ws.iter_rows(min_row=8,max_row=len(expected)+7,max_col=len(fields),values_only=True))
    def same(a,b):
        if b is None or b=='':return a is None or a==''
        if isinstance(b,float):return isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-14,abs_tol=1e-16)
        return a==b
    check(name+'：全部Excel值与汇总数据一致',all(all(same(a,b) for a,b in zip(ra,re)) for ra,re in zip(actual,expected)) and len(actual)==len(expected))
    check(name+'：原生筛选表覆盖全部数据',len(ws.tables)==1 and next(iter(ws.tables.values())).ref==f'A7:{openpyxl.utils.get_column_letter(len(fields))}{len(expected)+7}')
    check(name+'：计数公式和缓存正确',ws['B6'].data_type=='f' and cache[name]['B6'].value==len(expected))
    check(name+'：冻结表头及标识列',str(ws.freeze_panes)==('B8' if key=='targets' else 'C8'))
    check(name+'：标识列保留为文本',all(ws.cell(i,1).data_type=='s' for i in range(8,len(expected)+8)))
    check(name+'：无Excel错误值',not any(c.data_type=='e' for row in ws for c in row))
    check(name+'：预览图已生成',(AUDIT/f'preview_{key}.png').stat().st_size>10000)
check('明细保留原始Probability文本精度',all(wb['代谢物靶点明细'].cell(i+8,9).value==r[8] for i,r in enumerate(payload['relations']['rows'])))
report={'all_passed':all(c['passed'] for c in checks),'n_checks':len(checks),'checks':checks,'summary':summary,'visual_review':'All three worksheet previews reviewed for readable headers, values, counts and source identifiers.'}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_passed':report['all_passed'],'n_checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=True,indent=2))
assert report['all_passed']
