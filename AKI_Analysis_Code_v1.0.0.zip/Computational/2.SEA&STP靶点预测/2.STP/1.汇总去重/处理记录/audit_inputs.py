from pathlib import Path
from collections import Counter,defaultdict
import csv,io,json
import openpyxl
ROOT=Path(__file__).resolve().parents[2]
files=sorted(ROOT.glob('*.csv'))
rows=[];headers=Counter();counts={};samples=[];encoding_counts=Counter()
for p in files:
    b=p.read_bytes()
    for enc in ['utf-8-sig','gb18030']:
        try:text=b.decode(enc);break
        except UnicodeDecodeError:continue
    else:raise ValueError(p)
    encoding_counts[enc]+=1
    reader=csv.DictReader(io.StringIO(text,newline=''))
    headers[tuple(reader.fieldnames)]+=1
    records=list(reader);counts[p.name]=len(records)
    for i,r in enumerate(records,2):rows.append({'file':p.name,'row':i,**r})
    if len(samples)<3 or len(records)!=100:samples.append({'file':p.name,'count':len(records),'first':records[:2]})
irregular={}
if rows:
    for k in headers.most_common(1)[0][0]:
        if any(term in k.lower() for term in ['common','uniprot','probability','chembl']):
            irregular[k]={'blank':sum(not (r.get(k) or '').strip() for r in rows),
                          'multi_values':list(Counter(r.get(k) for r in rows if r.get(k) and any(x in r[k] for x in [';',',','/','|'])).items())[:40],
                          'unique':len({r.get(k) for r in rows})}
mapping_previews=[]
for p in ROOT.parent.glob('*.xlsx'):
    if 'SMILES' not in p.name:continue
    w=openpyxl.load_workbook(p,read_only=True,data_only=True)
    mapping_previews.append({'file':str(p),'sheets':[{'sheet':s.title,'rows':s.max_row,'cols':s.max_column,'first':list(s.iter_rows(min_row=1,max_row=min(8,s.max_row),values_only=True))} for s in w]})
report={'files':len(files),'rows':len(rows),'headers':[{'header':list(k),'count':v} for k,v in headers.items()],
        'encodings':dict(encoding_counts),'row_count_distribution':dict(Counter(counts.values())),
        'samples':samples[:15],'irregular':irregular,'mapping_previews':mapping_previews}
(ROOT/'汇总去重/处理记录/input_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,default=str))
