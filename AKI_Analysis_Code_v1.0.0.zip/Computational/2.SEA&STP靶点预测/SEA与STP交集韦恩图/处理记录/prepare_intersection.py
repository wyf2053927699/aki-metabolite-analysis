from pathlib import Path
from collections import defaultdict
import csv,json,hashlib,re,sys
import openpyxl

ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录';BASE=ROOT.parent
sea_file=BASE/'1.SEA数据库-2563个靶点/SEA_ChEMBL27_228代谢物靶点.xlsx'
stp_file=BASE/'2.STP/2.STP靶点-1195个.xlsx'
sea_wb=openpyxl.load_workbook(sea_file,read_only=True,data_only=True)
stp_wb=openpyxl.load_workbook(stp_file,read_only=True,data_only=True)

def records(ws,ncols):
    header=next(ws.iter_rows(min_row=7,max_row=7,max_col=ncols,values_only=True))
    return [(i,dict(zip(header,row))) for i,row in enumerate(ws.iter_rows(min_row=8,max_col=ncols,values_only=True),8) if row and row[0] is not None]
def symbols(value):
    if value is None:return []
    result=[s.strip() for s in str(value).split(';') if s.strip()]
    assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in result),value
    return result
def joined(values):return ' | '.join(dict.fromkeys(str(v) for v in values if v is not None and str(v)!=''))

sea_gene_rows=records(sea_wb['去重人类基因'],11)
sea_detail=records(sea_wb['人类靶点明细'],17)
stp_targets=records(stp_wb['去重靶点'],11)
stp_detail=records(stp_wb['代谢物靶点明细'],16)
sea={};sea_rows={}
for rownum,r in sea_gene_rows:
    symbol=str(r['SEA基因符号']).strip();assert symbol not in sea
    sea[symbol]=r;sea_rows[symbol]=rownum
assert set(sea)=={s for i,r in sea_detail for s in symbols(r['SEA原始基因注释'])}
stp=defaultdict(list);stp_compounds=defaultdict(set);stp_scores=defaultdict(list)
for rownum,r in stp_targets:
    for symbol in symbols(r['原始基因注释']):stp[symbol].append((rownum,r))
for rownum,r in stp_detail:
    for symbol in symbols(r['原始基因注释']):
        stp_compounds[symbol].add(str(r['代谢物CID']))
        stp_scores[symbol].append(float(r['Probability']))
assert set(stp)==set(stp_compounds)
A=set(sea);B=set(stp);common=A&B;only_sea=A-B;only_stp=B-A
all_rows=[]
for symbol in sorted(A|B):
    a=sea.get(symbol);b=stp.get(symbol,[])
    notes=[]
    if a and int(a['共享注释记录数'])>0:notes.append('SEA含多基因共享注释')
    if any(';' in (r['原始基因注释'] or '') for i,r in b):notes.append('STP含多基因共享注释')
    row={'Gene_symbol':symbol,'Membership':'SEA∩STP' if symbol in common else 'SEA only' if symbol in A else 'STP only',
        'SEA_UniProt_entry':a['UniProt Entry'] if a else '',
        'STP_UniProt_IDs':joined(r['原始UniProt编号或组合'] for i,r in b),
        'STP_ChEMBL_IDs':joined(r['ChEMBL靶点编号'] for i,r in b),
        'SEA_metabolite_count':a['关联代谢物数'] if a else None,
        'STP_metabolite_count':len(stp_compounds[symbol]) if b else None,
        'SEA_min_P':a['最小SEA P值'] if a else None,
        'SEA_min_P_raw':a['最小P值原始文本'] if a else '',
        'SEA_max_MaxTC':a['最大MaxTC'] if a else None,
        'STP_max_Probability':max(stp_scores[symbol]) if b else None,
        'SEA_target_description':a['靶点描述'] if a else '',
        'STP_target_description':joined(r['靶点名称'] for i,r in b),
        'Shared_annotation_note':joined(notes),
        'SEA_source_gene_sheet_row':sea_rows.get(symbol),
        'STP_source_target_sheet_rows':joined(i for i,r in b)}
    all_rows.append(row)
intersection=[r for r in all_rows if r['Gene_symbol'] in common]
summary={'input_files':[{'database':db,'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for db,p in [('SEA',sea_file),('STP',stp_file)]],
    'comparison_key':'Exact existing gene symbol after trimming outer whitespace; split semicolon-delimited shared annotations',
    'SEA_genes':len(A),'STP_genes':len(B),'intersection':len(common),'SEA_only':len(only_sea),'STP_only':len(only_stp),'union':len(A|B),
    'SEA_human_target_entries':len({r['UniProt Entry'] for i,r in sea_detail}),
    'SEA_gene_source_rows':len(sea_gene_rows),'STP_target_source_rows':len(stp_targets),
    'STP_targets_without_gene_annotation':sum(not symbols(r['原始基因注释']) for i,r in stp_targets),
    'SEA_detail_records':len(sea_detail),'STP_detail_records':len(stp_detail),
    'score_filter':'none','alias_mapping':'none','gene_symbol_case_conversion':'none',
    'figure_geometry':'Reference-matched equal circles; numbers are exact set counts and areas are not proportional',
    'workbook':'SEA_STP_交集靶点.xlsx','figure':'SEA_STP_靶点韦恩图'}
def csvout(name,rows):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvout('SEA_STP_交集靶点.csv',intersection);csvout('SEA_STP_集合与来源.csv',all_rows)
with (AUDIT/'gene_membership.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Gene_symbol','SEA','STP'])
    for gene in sorted(A|B):w.writerow([gene,gene in A,gene in B])
for name,genes in [('交集基因',common),('SEA独有基因',only_sea),('STP独有基因',only_stp)]:
    (ROOT/f'{name}_{len(genes)}个.txt').write_text('\n'.join(sorted(genes))+'\n',encoding='utf-8-sig')
payload={'summary':summary,
         'intersection':{'fields':list(intersection[0]),'rows':[list(r.values()) for r in intersection]},
         'membership':{'fields':list(all_rows[0]),'rows':[list(r.values()) for r in all_rows]}}
(AUDIT/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(AUDIT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
from profile_data import profile_data,render_report
profile=profile_data(str(AUDIT/'gene_membership.csv'),group_cols=[])
(AUDIT/'data_profile.txt').write_text(render_report(profile),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='input_files'},ensure_ascii=True,indent=2))
