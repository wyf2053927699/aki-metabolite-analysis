from pathlib import Path
from collections import Counter
import sys,json,argparse
ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录'
# Reuse the plotting dependencies already installed for this research workspace.
sys.path.insert(0,r'.\local_workspace\CC_gutMGene_followup\.runtime')
sys.path.insert(0,r'./local_user\.codex\skills\scipilot-figure-skill\scripts')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,FancyArrowPatch
from matplotlib import font_manager
from PIL import Image
from setup_style import setup_style
from visual_qa import audit_layout,render_preview
from export_figure import export_figure

parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');args=parser.parse_args()
counts=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
reference=Image.open(AUDIT/'参考图.png').convert('RGB')
dominant=[rgb for rgb,n in Counter(reference.getdata()).most_common(10) if len(set(rgb))>1]
palette={'SEA':'#F6B7AE','STP':'#B8E4ED','intersection':'#EDE1E1','ring':'#477FA2'}
setup_style(journal='general',lang='en',use_sciplots=False,constrained_layout=False)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
font_manager.findfont('Arial',fallback_to_default=False)
font_manager.findfont('Times New Roman',fallback_to_default=False)
size=(3.5,3.5*305/345)
fig=plt.figure(figsize=size,dpi=150,facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,345),ylim=(305,0));ax.set_aspect('equal');ax.axis('off')
left=Circle((133,122),98,facecolor=palette['SEA'],edgecolor='none',zorder=1)
right=Circle((212,122),98,facecolor=palette['STP'],edgecolor='none',zorder=1)
ax.add_patch(left);ax.add_patch(right)
# Explicitly color the lens to reproduce the reference's pale gray overlap.
lens=Circle((212,122),98,facecolor=palette['intersection'],edgecolor='none',zorder=2)
lens.set_clip_path(left);ax.add_patch(lens)
texts=[]
for x,label in [(75,counts['SEA_only']),(172.5,counts['intersection']),(270,counts['STP_only'])]:
    texts.append(ax.text(x,121,str(label),ha='center',va='center',fontsize=11.5,fontfamily='Arial',color='black',zorder=4))
ax.add_patch(Circle((172.5,118),18,fill=False,edgecolor=palette['ring'],linewidth=1.2,zorder=5))
ax.add_patch(FancyArrowPatch((172.5,137),(170.5,245),arrowstyle='-|>',mutation_scale=13,linewidth=1.3,color='black',shrinkA=0,shrinkB=0,zorder=4))
texts.append(ax.text(112,239,'SEA',ha='center',va='center',fontsize=13,fontfamily='Arial',color='black'))
texts.append(ax.text(232,239,'STP',ha='center',va='center',fontsize=13,fontfamily='Arial',color='black'))
texts.append(ax.text(172.5,269,'Targets of metabolites',ha='center',va='center',fontsize=14,fontfamily='Times New Roman',color='black'))
fig.canvas.draw();issues=audit_layout(fig)
assert not any(severity=='FAIL' for severity,message in issues),issues
renderer=fig.canvas.get_renderer();boxes=[t.get_window_extent(renderer) for t in texts]
collisions=[]
for i,a in enumerate(boxes):
    for j,b in enumerate(boxes[i+1:],i+1):
        if a.overlaps(b):collisions.append([i,j])
assert not collisions,collisions
render_preview(fig,str(AUDIT/'venn_preview.png'),dpi=180)
report={'method':'Python matplotlib; reference-matched equal circles with exact set-count labels',
        'comparison_unit':'existing gene symbol','counts':{k:counts[k] for k in ['SEA_genes','STP_genes','intersection','SEA_only','STP_only','union']},
        'size_inches':list(size),'dpi':600,'palette':palette,'dominant_reference_colors':[list(v) for v in dominant[:3]],
        'fonts':['Arial','Times New Roman'],'layout_issues':issues,'text_overlap_pairs':collisions,
        'min_font_size_pt':11.5,'area_proportional':False}
if args.export:
    report['exports']=export_figure(fig,str(ROOT/counts['figure']),formats=['png','pdf','svg'],dpi=600,size_inches=size,grayscale_preview=False,tight=False)
    im=Image.open(ROOT/(counts['figure']+'.png'))
    im.convert('L').save(AUDIT/'venn_grayscale.png',dpi=(600,600))
(AUDIT/'figure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
plt.close(fig)
print(json.dumps({'layout_issues':issues,'text_overlap_pairs':collisions,'exported':args.export,'counts':report['counts']},ensure_ascii=True))
