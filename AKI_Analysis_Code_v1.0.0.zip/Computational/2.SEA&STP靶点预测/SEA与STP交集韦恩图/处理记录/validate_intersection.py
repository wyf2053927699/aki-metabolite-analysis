from pathlib import Path
from collections import defaultdict
import csv,json,hashlib,math,xml.etree.ElementTree as ET
import openpyxl
from PIL import Image
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1];AUDIT=ROOT/'处理记录'
summary=json.loads((AUDIT/'summary.json').read_text(encoding='utf-8'))
payload=json.loads((AUDIT/'workbook_payload.json').read_text(encoding='utf-8'))
checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:print('FAILED',name,detail)
for f in summary['input_files']:
    check(f['database']+'原文件哈希不变',hashlib.sha256(Path(f['file']).read_bytes()).hexdigest()==f['sha256'])
sea=openpyxl.load_workbook(summary['input_files'][0]['file'],read_only=True,data_only=True)
stp=openpyxl.load_workbook(summary['input_files'][1]['file'],read_only=True,data_only=True)
A={str(r[0]).strip() for r in sea['去重人类基因'].iter_rows(min_row=8,max_col=1,values_only=True) if r[0]}
B={s.strip() for r in stp['去重靶点'].iter_rows(min_row=8,max_col=2,values_only=True) if r[0] and r[1] for s in str(r[1]).split(';') if s.strip()}
common=A&B;onlyA=A-B;onlyB=B-A;union=A|B
check('两表原始基因集合计数',len(A)==summary['SEA_genes']==1291 and len(B)==summary['STP_genes']==1195)
check('808个交集准确且无需评分筛选',len(common)==summary['intersection']==808)
check('集合计数恒等式',len(onlyA)==483 and len(onlyB)==387 and len(union)==1678 and len(A)==len(onlyA)+len(common) and len(B)==len(onlyB)+len(common))
inter=list(csv.DictReader((ROOT/'SEA_STP_交集靶点.csv').open(encoding='utf-8-sig',newline='')))
allrows=list(csv.DictReader((ROOT/'SEA_STP_集合与来源.csv').open(encoding='utf-8-sig',newline='')))
check('交集CSV无缺失或重复',len(inter)==len({r['Gene_symbol'] for r in inter})==808 and {r['Gene_symbol'] for r in inter}==common)
check('全集CSV无缺失或重复',len(allrows)==len({r['Gene_symbol'] for r in allrows})==1678 and {r['Gene_symbol'] for r in allrows}==union)
check('全部集合归属正确',all(r['Membership']==('SEA∩STP' if r['Gene_symbol'] in common else 'SEA only' if r['Gene_symbol'] in A else 'STP only') for r in allrows))
check('三个TXT清单与真实集合一致',all(set((ROOT/f'{name}_{len(genes)}个.txt').read_text(encoding='utf-8-sig').splitlines())==genes for name,genes in [('交集基因',common),('SEA独有基因',onlyA),('STP独有基因',onlyB)]))
sea_source={i:r for i,r in enumerate(sea['去重人类基因'].iter_rows(min_row=8,max_col=11,values_only=True),8) if r[0]}
stp_source={i:r for i,r in enumerate(stp['去重靶点'].iter_rows(min_row=8,max_col=11,values_only=True),8) if r[0]}
check('交集SEA来源行符号和原始P值准确',all(sea_source[int(r['SEA_source_gene_sheet_row'])][0]==r['Gene_symbol'] and float(sea_source[int(r['SEA_source_gene_sheet_row'])][4])==float(r['SEA_min_P']) and sea_source[int(r['SEA_source_gene_sheet_row'])][1]==r['SEA_UniProt_entry'] for r in inter))
check('交集STP来源行含对应基因注释',all(all(r['Gene_symbol'] in [s.strip() for s in str(stp_source[int(i)][1]).split(';')] for i in r['STP_source_target_sheet_rows'].split(' | ')) for r in inter))
stp_counts=defaultdict(set);stp_probs=defaultdict(list)
for row in stp['代谢物靶点明细'].iter_rows(min_row=8,max_col=5,values_only=True):
    if row[0] and row[2]:
        for s in str(row[2]).split(';'):
            stp_counts[s.strip()].add(str(row[0]));stp_probs[s.strip()].append(float(row[4]))
check('交集STP代谢物数及最大Probability准确',all(int(r['STP_metabolite_count'])==len(stp_counts[r['Gene_symbol']]) and math.isclose(float(r['STP_max_Probability']),max(stp_probs[r['Gene_symbol']]),rel_tol=1e-14,abs_tol=1e-16) for r in inter))

wb=openpyxl.load_workbook(ROOT/summary['workbook'],data_only=False)
cache=openpyxl.load_workbook(ROOT/summary['workbook'],data_only=True)
specs=[('交集靶点','intersection',['Gene_symbol','SEA_UniProt_entry','STP_UniProt_IDs','STP_ChEMBL_IDs','SEA_metabolite_count','STP_metabolite_count','SEA_min_P','STP_max_Probability','SEA_max_MaxTC','Shared_annotation_note','SEA_source_gene_sheet_row','STP_source_target_sheet_rows','SEA_min_P_raw','SEA_target_description','STP_target_description']),
       ('全部基因集合','membership',['Gene_symbol','Membership','SEA_UniProt_entry','STP_UniProt_IDs','STP_ChEMBL_IDs','SEA_source_gene_sheet_row','STP_source_target_sheet_rows','Shared_annotation_note'])]
check('工作表结构正确',wb.sheetnames==[s[0] for s in specs])
for name,key,fields in specs:
    ws=wb[name];data=payload[key];idx={f:i for i,f in enumerate(data['fields'])}
    expected=[[r[idx[f]] for f in fields] for r in data['rows']]
    actual=list(ws.iter_rows(min_row=8,max_row=len(expected)+7,max_col=len(fields),values_only=True))
    def same(a,b):
        if b is None or b=='':return a is None or a==''
        if isinstance(b,float):return isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-14,abs_tol=1e-260)
        return a==b
    check(name+'：所有Excel值正确',len(actual)==len(expected) and all(all(same(a,b) for a,b in zip(ra,rb)) for ra,rb in zip(actual,expected)))
    check(name+'：原生筛选表完整',len(ws.tables)==1 and next(iter(ws.tables.values())).ref==f'A7:{openpyxl.utils.get_column_letter(len(fields))}{len(expected)+7}')
    check(name+'：计数公式与缓存正确',ws['B6'].data_type=='f' and cache[name]['B6'].value==len(expected))
    check(name+'：基因标识保持文本且表头冻结',str(ws.freeze_panes)=='B8' and all(ws.cell(i,1).data_type=='s' for i in range(8,len(expected)+8)))
    check(name+'：无Excel错误值',not any(c.data_type=='e' for row in ws for c in row))
    check(name+'：工作簿预览存在',(AUDIT/f'preview_{key}.png').stat().st_size>10000)

figaudit=json.loads((AUDIT/'figure_audit.json').read_text(encoding='utf-8'))
check('绘图数字与真实集合完全一致',figaudit['counts']=={k:summary[k] for k in ['SEA_genes','STP_genes','intersection','SEA_only','STP_only','union']})
check('绘图文字没有缺字裁切或重叠',not figaudit['layout_issues'] and not figaudit['text_overlap_pairs'])
im=Image.open(ROOT/(summary['figure']+'.png'))
check('PNG为600dpi且尺寸正确',im.size==(2100,1856) and min(im.info['dpi'])>599)
svg=ET.parse(ROOT/(summary['figure']+'.svg'))
svg_text={''.join(e.itertext()).strip() for e in svg.iter() if e.tag.endswith('}text')}
check('SVG含正确集合数值和参考图标签',{'483','808','387','SEA','STP','Targets of metabolites'}<=svg_text)
check('SVG为纯矢量图',not any(e.tag.endswith('}image') for e in svg.iter()))
reader=PdfReader(ROOT/(summary['figure']+'.pdf'))
font_report=[]
for name,reference in reader.pages[0]['/Resources']['/Font'].get_object().items():
    font=reference.get_object()
    descendants=font.get('/DescendantFonts')
    leafs=[x.get_object() for x in descendants] if descendants else [font]
    embeds=[]
    for leaf in leafs:
        fd=leaf.get('/FontDescriptor');fd=fd.get_object() if fd else {}
        embeds.append(any(key in fd for key in ['/FontFile','/FontFile2','/FontFile3']))
    font_report.append({'font':str(font.get('/BaseFont')),'subtype':str(font.get('/Subtype')),'descendant_font_program_embedded':all(embeds)})
check('PDF字体实际嵌入',bool(font_report) and all(f['descendant_font_program_embedded'] for f in font_report),font_report)
(AUDIT/'pdf_font_audit.json').write_text(json.dumps(font_report,ensure_ascii=False,indent=2),encoding='utf-8')
check('PDF画布尺寸正确',abs(float(reader.pages[0].mediabox.width)/72-3.5)<0.001 and abs(float(reader.pages[0].mediabox.height)/72-3.5*305/345)<0.001)
report={'all_passed':all(c['passed'] for c in checks),'n_checks':len(checks),'checks':checks,'counts':figaudit['counts'],
        'visual_review':'Reference layout and palette reproduced; numbers, labels and arrow inspected. Both workbook sheet previews inspected.',
        'pdf_font_warning_resolution':'The generic checker warns for Type0 parent fonts. FontFile2 programs in descendant font descriptors were inspected and are embedded.'}
(AUDIT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_passed':report['all_passed'],'n_checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=True,indent=2))
assert report['all_passed']
