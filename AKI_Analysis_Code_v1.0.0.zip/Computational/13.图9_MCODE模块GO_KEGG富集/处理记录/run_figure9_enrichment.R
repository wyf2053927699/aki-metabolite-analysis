options(stringsAsFactors=FALSE,timeout=60)
invisible(Sys.setlocale('LC_CTYPE','.UTF-8'))
suppressPackageStartupMessages({library(clusterProfiler);library(org.Hs.eg.db);library(GO.db);library(AnnotationDbi);library(jsonlite)})
arg<-grep('^--file=',commandArgs(),value=TRUE);sd<-if(length(arg))dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))else''
root<-if(basename(sd)=='处理记录')dirname(sd)else'./Computational/13.图9_MCODE模块GO_KEGG富集'
raw<-file.path(root,'原始数据');audit<-file.path(root,'处理记录');tables<-file.path(root,'各子图数据表');objdir<-file.path(audit,'R对象')
for(p in c(raw,audit,tables,objdir,file.path(root,'图片'),file.path(audit,'图片预览')))dir.create(p,recursive=TRUE,showWarnings=FALSE)
write_csv<-function(x,p){con<-file(p,'wb');writeBin(charToRaw('\xef\xbb\xbf'),con);writeBin(charToRaw(enc2utf8(paste(capture.output(write.csv(x,row.names=FALSE,na='')),collapse='\n'))),con);close(con)}
copy_once<-function(s,d){if(!file.exists(d))stopifnot(file.copy(s,d))}
fig8<-'./Computational/12.图8_PPI与MCODE功能模块'
fig6<-'./Computational/10.图6_扩展基因富集与比较'
copy_once(file.path(fig8,'各子图数据表','MCODE_全部模块成员.csv'),file.path(raw,'输入_四个MCODE模块成员.csv'))
copy_once(file.path(fig8,'各子图数据表','MCODE_全部模块汇总.csv'),file.path(raw,'输入_MCODE模块汇总.csv'))
for(n in c('KEGG_hsa_ncbi_geneid_GSON.rds','KEGG_GSON_provenance.json','KEGG_gsid2gene.tsv','KEGG_gsid2name.tsv','KEGG_br08901_通路分类表.csv'))copy_once(file.path(fig6,'原始数据',n),file.path(raw,n))
copy_once(file.path(fig6,'处理记录','R软件版本.csv'),file.path(raw,'图6_R软件版本.csv'))
v6<-read.csv(file.path(raw,'图6_R软件版本.csv'),fileEncoding='UTF-8-BOM')
for(p in c('clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi'))stopifnot(as.character(packageVersion(p))==v6$Version[match(p,v6$Package)])
input<-read.csv(file.path(raw,'输入_四个MCODE模块成员.csv'),fileEncoding='UTF-8-BOM',colClasses='character',check.names=FALSE)
stopifnot(nrow(input)==50,length(unique(input$Gene_symbol))==50)
checkmap<-unique(AnnotationDbi::select(org.Hs.eg.db,keys=unique(input$Entrez_ID),keytype='ENTREZID',columns='SYMBOL'))
stopifnot(!anyDuplicated(checkmap$ENTREZID),all(input$Gene_symbol==checkmap$SYMBOL[match(input$Entrez_ID,checkmap$ENTREZID)]))
kg<-readRDS(file.path(raw,'KEGG_hsa_ncbi_geneid_GSON.rds'))
results<-list();selected<-list();summaries<-list();members<-list();validations<-list();backgrounds<-list()
for(rank in 1:4){
  query<-input$Entrez_ID[input$Cluster_rank==rank];sym<-setNames(input$Gene_symbol[input$Cluster_rank==rank],query)
  stopifnot(length(query)==c(30,5,3,12)[rank])
  for(domain in c('BP','CC','MF','KEGG')){
    message('Cluster ',rank,' ',domain,' n=',length(query))
    if(domain=='KEGG')obj<-enrichKEGG(query,organism=kg,keyType='ncbi-geneid',pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,use_internal_data=FALSE)
    else obj<-enrichGO(query,OrgDb=org.Hs.eg.db,keyType='ENTREZID',ont=domain,pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH',minGSSize=10,maxGSSize=500,readable=FALSE)
    stopifnot(inherits(obj,'enrichResult'))
    if(rank==1){backgrounds[[domain]]<-obj@universe;write_csv(data.frame(EntrezID=obj@universe),file.path(raw,paste0(domain,'_完整有效背景.csv')))}
    stopifnot(setequal(backgrounds[[domain]],obj@universe))
    saveRDS(obj,file.path(objdir,paste0('Cluster',rank,'_',domain,'_enrichResult.rds')))
    d<-obj@result;d$Domain<-domain;d$Cluster_rank<-rank
    d$Gene_symbols<-vapply(strsplit(d$geneID,'/',fixed=TRUE),function(g)paste(sort(unique(na.omit(sym[g]))),collapse='/'),'')
    d$BH_significant<-!is.na(d$p.adjust)&d$p.adjust<.05&d$FoldEnrichment>1
    d$Minus_log10_FDR<--log10(pmax(d$p.adjust,.Machine$double.xmin));d$Minus_log10_P<--log10(pmax(d$pvalue,.Machine$double.xmin))
    z<-d[d$BH_significant,];z<-z[order(z$p.adjust,z$pvalue,z$ID),];z<-head(z,if(domain=='KEGG')20 else 10);z$Selected_rank<-seq_len(nrow(z))
    key<-paste(rank,domain,sep='_');results[[key]]<-d;selected[[key]]<-z
    for(pair in list(list(d,'全部富集检验'),list(d[d$BH_significant,],'BH显著结果'),list(z,'绘图数据')))
      write_csv(pair[[1]],file.path(tables,paste0('Cluster',rank,'_',domain,'_',pair[[2]],'.csv')))
    summ<-data.frame(Cluster_rank=rank,Domain=domain,Input_count=length(query),Effective_foreground=length(intersect(query,obj@universe)),Background_count=length(obj@universe),Tested_terms=nrow(d),Significant_terms=sum(d$BH_significant),Displayed_terms=nrow(z),Minimum_FDR=min(d$p.adjust))
    summaries[[key]]<-summ
    gr<-do.call(rbind,strsplit(d$GeneRatio,'/'));bg<-do.call(rbind,strsplit(d$BgRatio,'/'))
    pv<-phyper(d$Count-1,as.numeric(bg[,1]),as.numeric(bg[,2])-as.numeric(bg[,1]),as.numeric(gr[,2]),lower.tail=FALSE)
    validations[[key]]<-data.frame(Cluster_rank=rank,Domain=domain,Max_P_difference=max(abs(pv-d$pvalue)),Max_BH_difference=max(abs(p.adjust(d$pvalue,'BH')-d$p.adjust)))
    stopifnot(max(abs(pv-d$pvalue))<1e-12,max(abs(p.adjust(d$pvalue,'BH')-d$p.adjust))<1e-12)
    members[[key]]<-do.call(rbind,lapply(names(obj@geneSets),function(id){g<-intersect(query,obj@geneSets[[id]]);if(!length(g))return(NULL);data.frame(Cluster_rank=rank,Domain=domain,Term_ID=id,EntrezID=g,Gene_symbol=unname(sym[g]))}))
  }
}
write_csv(do.call(rbind,summaries),file.path(tables,'四模块_全部富集汇总.csv'))
write_csv(do.call(rbind,validations),file.path(audit,'R_P与BH独立核对.csv'))
write_csv(do.call(rbind,members),file.path(raw,'模块基因_全部检验术语注释.csv'))
saveRDS(list(input=input,results=results,selected=selected,summary=do.call(rbind,summaries)),file.path(objdir,'图9完整富集对象.rds'))
pkgs<-c('clusterProfiler','enrichit','org.Hs.eg.db','GO.db','AnnotationDbi','gson','ggplot2','patchwork','ragg','svglite')
write_csv(data.frame(Package=pkgs,Version=vapply(pkgs,function(p)as.character(packageVersion(p)),'')),file.path(audit,'R软件版本.csv'))
writeLines(capture.output(sessionInfo()),file.path(audit,'R_sessionInfo.txt'))
write_json(list(Input='Figure8 actual four MCODE modules: 30,5,3,12 genes',Background='Same database-annotated human universe as Figures4/6',Method='clusterProfiler enrichGO/enrichKEGG; hypergeometric; BH separately per module and domain',pvalueCutoff=1,qvalueCutoff=1,minGSSize=10,maxGSSize=500,Significance='BH adjusted P <0.05 and FoldEnrichment>1',Selection='GO up to10 per ontology; KEGG up to20; same selection order BH,P,ID',GO_axis='-log10(BH adjusted P)',KEGG_axis='Count',GO_colors='BP/MF coral, CC turquoise; ontology colors do not denote expression direction',KEGG_classification='Official KEGG br08901; do not exclude classes absent from reference',Reference='10.1186/s40643-026-01083-8 Figure9',Main='Cluster1-3',Supplement='Cluster4'),file.path(audit,'analysis_protocol.json'),pretty=TRUE,auto_unbox=TRUE,digits=NA)
print(do.call(rbind,summaries));message('FIGURE9 ENRICHMENT COMPLETE')
