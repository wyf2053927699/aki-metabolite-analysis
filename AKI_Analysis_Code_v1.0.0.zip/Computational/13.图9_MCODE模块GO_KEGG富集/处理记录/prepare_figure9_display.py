"""Prepare uniform ranked GO/KEGG displays without changing enrichment tests."""
from pathlib import Path
import json
import pandas as pd

W = Path(__file__).parent
B = W.parent.parent if W.name == '处理记录' else Path('./Computational')
F9 = B / '13.图9_MCODE模块GO_KEGG富集'
T = F9 / '各子图数据表'
SETTINGS = F9 / '处理记录/plot_settings.json'

def prepare():
    settings = json.loads(SETTINGS.read_text(encoding='utf-8'))
    stats=[]
    for k in range(1,5):
        for domain in ['BP','CC','MF','KEGG']:
            raw=pd.read_csv(T/f'Cluster{k}_{domain}_全部富集检验.csv',encoding='utf-8-sig',keep_default_na=False)
            eligible=raw.loc[(raw.Count>0)&(raw.FoldEnrichment>1)].sort_values(['p.adjust','pvalue','ID'],kind='stable')
            limit=settings['KEGG_top_n'] if domain=='KEGG' else settings['GO_top_n_per_ontology']
            top=eligible.head(limit).copy()
            top['Selected_rank']=range(1,len(top)+1)
            top['Display_status']=top.BH_significant.map({True:'显著；BH校正P<0.05',False:'探索性；BH校正P≥0.05'})
            top.to_csv(T/f'Cluster{k}_{domain}_统一展示数据.csv',index=False,encoding='utf-8-sig')
            stats.append({'Cluster_rank':k,'Domain':domain,'Display_eligible_terms':len(eligible),
                          'Display_limit':limit,'Displayed_significant_terms':int(top.BH_significant.sum()),
                          'Displayed_exploratory_terms':int((~top.BH_significant).sum()),
                          'Displayed_total_terms':len(top),'Display_shortfall':max(0,limit-len(top))})
            if k==1 and domain=='CC':
                top.to_csv(T/'Cluster1_CC_探索性Top10.csv',index=False,encoding='utf-8-sig')
                ranks=top.set_index('ID').Selected_rank.to_dict()
                statuses=top.set_index('ID').Display_status.to_dict()
                raw['Selected_rank']=raw.ID.map(ranks).fillna('')
                raw['Display_status']=raw.ID.map(statuses).fillna('未选入绘图')
                raw.to_csv(T/'Cluster1_CC_完整检验与展示标记.csv',index=False,encoding='utf-8-sig')
    summary = pd.read_csv(T/'四模块_全部富集汇总.csv', encoding='utf-8-sig', keep_default_na=False)
    summary=summary.rename(columns={'Displayed_terms':'Original_displayed_significant_terms'}).merge(pd.DataFrame(stats),on=['Cluster_rank','Domain'],validate='one_to_one')
    summary.to_csv(T/'四模块_绘图展示汇总.csv', index=False, encoding='utf-8-sig')
    return summary

if __name__ == '__main__':
    summary=prepare()
    print(summary[['Cluster_rank','Domain','Display_eligible_terms','Displayed_significant_terms','Displayed_exploratory_terms','Displayed_total_terms']].to_string(index=False))
