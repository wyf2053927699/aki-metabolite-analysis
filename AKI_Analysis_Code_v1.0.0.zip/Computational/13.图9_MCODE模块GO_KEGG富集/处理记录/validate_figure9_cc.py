"""Compatibility entry point: validate the current uniform Figure9 edition."""
from validate_figure9_uniform import main

if __name__ == '__main__':
    main()