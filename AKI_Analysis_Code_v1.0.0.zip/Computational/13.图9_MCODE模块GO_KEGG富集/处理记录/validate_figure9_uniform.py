"""Audit all displayed Figure9 terms, exported tables, and figure annotations."""
from pathlib import Path
import hashlib,json,math,re
import numpy as np
import pandas as pd
import openpyxl
from scipy.stats import hypergeom,false_discovery_control
from pypdf import PdfReader
from PIL import Image

Image.MAX_IMAGE_PIXELS=None
W=Path(__file__).parent;R=W.parent;T=R/'各子图数据表'
BACKUP=R/'历史版本/全模块统一调整前_20261019_01'
checks=[]
def check(name,condition,detail=''):
    checks.append({'Check':name,'Pass':bool(condition),'Detail':str(detail)})
    assert condition,(name,detail)

def equal_value(a,b):
    if a is None or a=='':return b is None or b==''
    if isinstance(a,(float,int)) and not isinstance(a,bool):
        return isinstance(b,(float,int)) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-290)
    return a==b

def main():
    for item in json.loads((BACKUP/'统计结果修改前SHA256.json').read_text(encoding='utf-8-sig')):
        check('Original statistics unchanged: '+Path(item['Path']).name,
              hashlib.sha256(Path(item['Path']).read_bytes()).hexdigest().upper()==item['Hash'])
    all_display={};counts=[]
    summary=pd.read_csv(T/'四模块_绘图展示汇总.csv')
    for k in range(1,5):
        all_display[k]={}
        for domain in ['BP','CC','MF','KEGG']:
            tag=f'Cluster{k}_{domain}'
            d=pd.read_csv(T/(tag+'_全部富集检验.csv'),keep_default_na=False,dtype={'geneID':str})
            gr=d.GeneRatio.str.split('/',expand=True).astype(int)
            bg=d.BgRatio.str.split('/',expand=True).astype(int)
            check(tag+' independent hypergeometric',np.allclose(hypergeom.sf(d.Count-1,bg[1],bg[0],gr[1]),d.pvalue,rtol=1e-10,atol=1e-280))
            check(tag+' independent BH',np.allclose(false_discovery_control(d.pvalue.to_numpy()),d['p.adjust'],rtol=1e-10,atol=1e-280))
            eligible=d[(d.Count>0)&(d.FoldEnrichment>1)].sort_values(['p.adjust','pvalue','ID'])
            expected=eligible.head(20 if domain=='KEGG' else 10)
            top=pd.read_csv(T/(tag+'_统一展示数据.csv'),keep_default_na=False,dtype={'geneID':str})
            all_display[k][domain]=top
            check(tag+' ranked display IDs',top.ID.tolist()==expected.ID.tolist(),len(top))
            check(tag+' selected ranks',top.Selected_rank.tolist()==list(range(1,len(top)+1)))
            for col in d.columns:
                if pd.api.types.is_numeric_dtype(d[col]) and col!='BH_significant':
                    same=np.allclose(top[col],expected[col],rtol=1e-12,atol=1e-280)
                else:same=top[col].tolist()==expected[col].tolist()
                assert same,(tag,col)
            check(tag+' all displayed values unchanged',True)
            sig=(top['p.adjust']<.05)&(top.FoldEnrichment>1)
            check(tag+' significance flags match statistics',sig.tolist()==top.BH_significant.tolist())
            check(tag+' exploratory labels agree',top.Display_status.str.startswith('探索性').tolist()==(~sig).tolist())
            check(tag+' GO axis values agree with true BH',np.allclose(top.Minus_log10_FDR,-np.log10(top['p.adjust']),rtol=1e-12,atol=1e-12))
            check(tag+' gene counts match gene lists',all(len(r.Gene_symbols.split('/'))==r.Count for _,r in top.iterrows()))
            row=summary[(summary.Cluster_rank==k)&(summary.Domain==domain)].iloc[0]
            check(tag+' display summary matches',row.Display_eligible_terms==len(eligible) and row.Displayed_significant_terms==int(sig.sum()) and row.Displayed_exploratory_terms==int((~sig).sum()) and row.Displayed_total_terms==len(top))
            counts.append({'Cluster_rank':k,'Domain':domain,'Displayed':len(top),'Significant':int(sig.sum()),'Exploratory':int((~sig).sum())})
        go=pd.read_csv(T/f'Cluster{k}_GO_合并绘图数据.csv',keep_default_na=False)
        check(f'Cluster{k} combined GO IDs',go.ID.tolist()==pd.concat([all_display[k][o] for o in ['BP','CC','MF']]).ID.tolist())
        kg=pd.read_csv(T/f'Cluster{k}_KEGG_含分类绘图数据.csv',keep_default_na=False)
        check(f'Cluster{k} KEGG categories present',kg.ID.tolist()==all_display[k]['KEGG'].ID.tolist() and kg.Level1.ne('').all())
    check('Cluster3 CC shows only five available terms',len(all_display[3]['CC'])==5)
    check('Cluster3 KEGG shows only twelve available pathways',len(all_display[3]['KEGG'])==12)
    check('Cluster3 CC FDR=1 keeps zero bar lengths',(all_display[3]['CC']['p.adjust']==1).all() and (all_display[3]['CC'].Minus_log10_FDR==0).all())
    check('Total displayed rows',sum(x['Displayed'] for x in counts)==187)
    check('Displayed significant and exploratory totals',sum(x['Significant'] for x in counts)==88 and sum(x['Exploratory'] for x in counts)==99)
    p=json.loads((W/'workbook_payload.json').read_text(encoding='utf-8'))
    wb=openpyxl.load_workbook(R/p['filename'],read_only=True,data_only=True)
    for s in p['sheets']:
        sh=wb[s['name']]
        check(s['name']+' exported record count',sh['B6'].value==len(s['rows']))
        actual=list(sh.iter_rows(min_row=8,max_row=max(8,7+len(s['rows'])),max_col=len(s['fields']),values_only=True))
        for i,row in enumerate(s['rows']):
            for j,val in enumerate(row):assert equal_value(val,actual[i][j]),(s['name'],i,j,val,actual[i][j])
        check(s['name']+' exported values agree',True)
    wb.close()
    old=openpyxl.load_workbook(BACKUP/'图9_各模块GO_KEGG绘图数据_补充CC版.xlsx',read_only=True,data_only=False)
    new=openpyxl.load_workbook(R/p['filename'],read_only=True,data_only=False)
    check('Input gene worksheet preserved',[(c.value,c.data_type,c.number_format) for row in old['模块输入基因'] for c in row]==[(c.value,c.data_type,c.number_format) for row in new['模块输入基因'] for c in row])
    old.close();new.close()
    pdf=PdfReader(R/'图9_MCODE模块富集_主图与分图_统一调整版.pdf')
    check('PDF has five pages',len(pdf.pages)==5)
    for i,modules in enumerate([[1,2,3],[1],[2],[3],[4]]):
        txt=pdf.pages[i].extract_text();compact=re.sub(r'\s+','',txt)
        for k in modules:
            for o,ds in all_display[k].items():
                check(f'PDF page{i+1} Cluster{k} {o} labels present',all(re.sub(r'\s+','',desc) in compact for desc in ds.Description))
        check(f'PDF page{i+1} exploratory footnote present','exploratory' in txt and '0.05' in txt)
    fonts=[f.get_object() for page in pdf.pages for f in page['/Resources']['/Font'].values()]
    check('PDF fonts embedded',all(all(any(d.get_object()['/FontDescriptor'].get_object().get(key) for key in ['/FontFile','/FontFile2','/FontFile3']) for d in f.get('/DescendantFonts',[])) for f in fonts))
    for stem in ['图9_主图_ABC']+[f'图9_{chr(64+k) if k<4 else "S1"}_Cluster{k}' for k in range(1,5)]:
        im=Image.open(R/'图片'/(stem+'.png'))
        check(stem+' 600dpi PNG',min(im.info.get('dpi',[0]))>=599)
        issues=json.loads((W/'图片预览'/(stem+'_版面检查.json')).read_text(encoding='utf-8'))
        check(stem+' layout audit',not issues,issues)
    pd.DataFrame(counts).to_csv(W/'全模块调整_展示数量核对.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(W/'全模块调整_独立核对.csv',index=False,encoding='utf-8-sig')
    print('UNIFORM FIGURE9 CHECKS PASSED',len(checks))
    print(pd.DataFrame(counts).to_string(index=False))
    return len(checks)

if __name__=='__main__':main()
