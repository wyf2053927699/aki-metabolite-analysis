from pathlib import Path
import sys,json,shutil,subprocess,math
import pandas as pd,numpy as np,openpyxl
from scipy.stats import hypergeom,false_discovery_control
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime');sys.path.insert(0,'./local_user/.codex/skills/scipilot-figure-skill/scripts')
from profile_data import profile_data,render_report
from PIL import Image,ImageOps,ImageDraw
from pypdf import PdfReader
W=Path(__file__).parent;B=Path('./Computational');f9=B/'13.图9_MCODE模块GO_KEGG富集';f10=B/'14.图10_菌群靶点通路代谢物网络';checks=[]
def check(name,condition,detail=''):
    checks.append({'Check':name,'Pass':bool(condition),'Detail':str(detail)});assert condition,(name,detail)
for k in range(1,5):
    for domain in ['BP','CC','MF','KEGG']:
        d=pd.read_csv(f9/'各子图数据表'/f'Cluster{k}_{domain}_全部富集检验.csv');gr=d.GeneRatio.str.split('/',expand=True).astype(int);bg=d.BgRatio.str.split('/',expand=True).astype(int);pv=hypergeom.sf(d.Count-1,bg[1],bg[0],gr[1]);bh=false_discovery_control(d.pvalue.to_numpy())
        check(f'Cluster{k}_{domain} hypergeometric',np.allclose(pv,d.pvalue,rtol=1e-10,atol=1e-280),max(abs(pv-d.pvalue)))
        check(f'Cluster{k}_{domain} BH',np.allclose(bh,d['p.adjust'],rtol=1e-10,atol=1e-280),max(abs(bh-d['p.adjust'])))
        selected=pd.read_csv(f9/'各子图数据表'/f'Cluster{k}_{domain}_绘图数据.csv');sig=d[(d['p.adjust']<.05)&(d.FoldEnrichment>1)].sort_values(['p.adjust','pvalue','ID']).head(20 if domain=='KEGG' else 10)
        check(f'Cluster{k}_{domain} selection',selected.ID.tolist()==sig.ID.tolist(),len(selected))
profile=profile_data(str(f9/'各子图数据表/四模块_全部富集汇总.csv'),group_cols=['Cluster_rank','Domain']);(f9/'处理记录/数据剖析.txt').write_text(render_report(profile),encoding='utf8')
n=pd.read_csv(f10/'各子图数据表/图10_全部节点_含坐标.csv',keep_default_na=False);e=pd.read_csv(f10/'各子图数据表/图10_全部连线.csv',keep_default_na=False);ev=pd.read_csv(f10/'各子图数据表/图10_每条连线原始证据.csv',keep_default_na=False);m=pd.read_csv(f10/'各子图数据表/图11A_代谢物度值与前四名.csv',keep_default_na=False)
check('Network nodes unique',len(n)==len(set(n.Node_ID))==123)
check('Missing TaxIDs never collapsed into blank node',not n.Node_ID.eq('G:').any() and n.Node_ID.str.startswith('G:NAME:').sum()==2)
check('Network edges unique',len(e)==len({tuple(sorted([r.Source,r.Target])) for _,r in e.iterrows()})==184)
check('Every edge references existing nodes',set(e.Source)|set(e.Target)<=set(n.Node_ID))
deg=pd.concat([e.Source,e.Target]).value_counts();check('Degree independently recounted',all(int(r.Degree)==int(deg[r.Node_ID]) for _,r in n.iterrows()))
check('Every edge has evidence',set(e.Edge_ID)==set(ev.Edge_ID));check('Evidence counts agree',all(len(ev[ev.Edge_ID.eq(r.Edge_ID)])==int(r.Evidence_count) for _,r in e.iterrows()))
inputs=pd.read_csv(f10/'原始数据/228个有结构人相关代谢物输入.csv',keep_default_na=False);check('228 input molecules',len(inputs)==228,len(inputs))
check('8 eligible metabolite nodes',len(m)==8 and set(m.CID.astype(str))<=set(inputs.CID.astype(str)))
check('Top4 predeclared by degree/CID',m[m.Selected_for_docking].Label.tolist()==['Butyrate','Acetate','Propionate','Trimethylamine oxide'])
profile=profile_data(n[['Type','Degree']],group_cols=['Type']);(f10/'处理记录/数据剖析.txt').write_text(render_report(profile),encoding='utf8')
for root in [f9,f10]:
    p=json.loads((root/'处理记录/workbook_payload.json').read_text(encoding='utf8'));wb=openpyxl.load_workbook(root/p['filename'],read_only=True,data_only=True)
    for s in p['sheets']:
        sheet=wb[s['name']];check(s['name']+' record count',sheet['B6'].value==len(s['rows']),sheet['B6'].value)
        actual=list(sheet.iter_rows(min_row=8,max_row=max(8,7+len(s['rows'])),max_col=len(s['fields']),values_only=True))
        for i,row in enumerate(s['rows']):
            for j,val in enumerate(row):
                got=actual[i][j]
                if val in [None,'']:ok=got in [None,'']
                elif isinstance(val,(int,float)) and not isinstance(val,bool):ok=isinstance(got,(int,float)) and math.isclose(val,got,rel_tol=1e-12,abs_tol=1e-290)
                else:ok=val==got
                if not ok:raise AssertionError((s['name'],i,j,val,got))
        check(s['name']+' exported values',True,len(s['rows']))
    wb.close()
    for artifact in root.glob('*.pdf'):
        pages=len(PdfReader(artifact).pages);check(artifact.name+' page count',pages==(5 if root==f9 else 1),pages)
        preview=root/'处理记录/PDF渲染';preview.mkdir(exist_ok=True)
        subprocess.run(['./local_user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe','-scale-to','1500','-png',str(artifact),str(preview/'page')],check=True,capture_output=True)
    # Contact sheets are QA only; originals remain at their exported resolution.
    files=list((root/'处理记录').glob('Excel预览_*.png'))
    for idx in range(0,len(files),5):
        canvas=Image.new('RGB',(1700,240*min(5,len(files)-idx)), 'white');dr=ImageDraw.Draw(canvas)
        for j,file in enumerate(files[idx:idx+5]):
            im=Image.open(file);im.thumbnail((1680,215));canvas.paste(im,(10,j*240+22));dr.text((10,j*240+3),file.stem,fill='black')
        canvas.save(root/'处理记录'/f'Excel总览_{idx//5+1}.png')
    for file in root.glob('*.inspect.ndjson'):shutil.move(str(file),root/'处理记录'/file.name)
pd.DataFrame(checks).to_csv(W/'图9图10_独立核对.csv',index=False,encoding='utf-8-sig')
for root in [f9,f10]:
    source=W/'图9图10_独立核对.csv';target=root/'处理记录/图9图10_独立核对.csv'
    if source.resolve()!=target.resolve():shutil.copy2(source,target)
print('INDEPENDENT CHECKS PASSED',len(checks))
