from pathlib import Path
import pandas as pd,json,sys
B=Path(__file__).parent.parent.parent if Path(__file__).parent.name=='处理记录' else Path('./Computational')
def spec(name,file,title,notes,fields=None):
    d=pd.read_csv(file,keep_default_na=False,encoding='utf-8-sig')
    if fields:d=d[fields]
    for f in d.columns:
        if f in ['EntrezID','Entrez_ID','CID','Gene_ID','TaxID','PMID','Entity_ID','Source_record']:d[f]=d[f].astype(str)
    widths=[min(65,max(17, len(f)+3, 45 if any(x in f for x in ['Description','SMILES','Label','Search_scope','Source_file','Symbols','Gene_symbols']) else 20)) for f in d]
    return {'name':name,'title':title,'fields':list(d),'rows':json.loads(d.to_json(orient='values',force_ascii=False,double_precision=15)),'widths':widths,'notes':notes}
def run9():
    from prepare_figure9_display import prepare
    prepare()
    r=B/'13.图9_MCODE模块GO_KEGG富集';t=r/'各子图数据表';notes=['来源：图8 MCODE实测模块；人类GO/KEGG背景与图4、图6一致。','方法：clusterProfiler；超几何检验；每个模块及本体分别进行BH校正。','显著标准：BH校正P<0.05、FoldEnrichment>1；完整检验结果见CSV。']
    displaynotes=notes[:2]+['统一展示：GO每类最多10项、KEGG最多20项；BH校正P≥0.05标为探索性；不足时展示实际数量。']
    ss=[spec('模块富集汇总',t/'四模块_绘图展示汇总.csv','四个MCODE模块的富集统计与展示数量',displaynotes)]
    fields=['Domain','ID','Description','Count','GeneRatio','BgRatio','FoldEnrichment','pvalue','p.adjust','Gene_symbols','Selected_rank','BH_significant','Display_status']
    for k in range(1,5):
        parts=[]
        for o in ['BP','CC','MF']:
            d=pd.read_csv(t/f'Cluster{k}_{o}_统一展示数据.csv',keep_default_na=False)
            parts.append(d)
        pd.concat(parts).to_csv(t/f'Cluster{k}_GO_合并绘图数据.csv',index=False,encoding='utf-8-sig')
        ss.append(spec(f'Cluster{k}_GO',t/f'Cluster{k}_GO_合并绘图数据.csv',f'Cluster {k} GO绘图数据',displaynotes,fields))
        ss.append(spec(f'Cluster{k}_KEGG',t/f'Cluster{k}_KEGG_含分类绘图数据.csv',f'Cluster {k} KEGG绘图数据',displaynotes,fields+['Level1']))
    ss.append(spec('Cluster1_CC完整检验',t/'Cluster1_CC_完整检验与展示标记.csv','30基因模块：CC完整检验与探索性展示标记',displaynotes,fields))
    ss.append(spec('模块输入基因',r/'原始数据/输入_四个MCODE模块成员.csv','模块成员与原始基因标识',notes))
    (r/'处理记录/workbook_payload.json').write_text(json.dumps({'filename':'图9_各模块GO_KEGG绘图数据_统一调整版.xlsx','sheets':ss},ensure_ascii=False),encoding='utf8')
def run10():
    r=B/'14.图10_菌群靶点通路代谢物网络';t=r/'各子图数据表';notes=['来源：人类gutMGene原始关联记录；KEGG两通路成员关系沿用图7。','节点按原始NCBI TaxID、PubChem CID、基因和通路ID标识；重复证据合并为单条关系。','筛选：代谢物必须属于前期228个有SMILES的人相关输入；保留逐条PMID及原始记录号。']
    ss=[spec('网络节点',t/'图10_全部节点_含坐标.csv','图10节点属性与可复现坐标',notes),spec('网络连线',t/'图10_全部连线.csv','图10去重关系',notes),spec('逐条原始证据',t/'图10_每条连线原始证据.csv','每条网络关系的来源证据',notes),spec('代谢物度值',t/'图11A_代谢物度值与前四名.csv','网络度值与预先选择的对接代谢物',notes),spec('候选及剔除核对',t/'代谢物宿主基因_候选关系与输入核对.csv','宿主基因候选关系与228输入核对',notes)]
    (r/'处理记录/workbook_payload.json').write_text(json.dumps({'filename':'图10_网络节点连线及来源证据.xlsx','sheets':ss},ensure_ascii=False),encoding='utf8')
if __name__=='__main__':
    if '--figure10-only' not in sys.argv:run9()
    if '--figure9-only' not in sys.argv:run10()
