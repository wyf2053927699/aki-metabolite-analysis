from pathlib import Path
import sys,json,textwrap,shutil,math
W=Path(__file__).parent
sys.path.insert(0,'./local_workspace/CC_gutMGene_followup/.runtime')
sys.path.insert(0,'./local_workspace/.codex-work/figure3/python_deps')
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch,FancyBboxPatch
from matplotlib.lines import Line2D
import networkx as nx
plt.rcParams.update({'font.family':'Arial','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'savefig.facecolor':'white'})
B=W.parent.parent if W.name=='处理记录' else Path('./Computational')
F9=B/'13.图9_MCODE模块GO_KEGG富集';F10=B/'14.图10_菌群靶点通路代谢物网络'
def csv(p):return pd.read_csv(p,encoding='utf-8-sig',keep_default_na=False)
def wrap(s,n=39):return '\n'.join(textwrap.wrap(s,n,break_long_words=False))
def emit(fig,root,stem,pdf):
    preview=root/'处理记录/图片预览';preview.mkdir(exist_ok=True,parents=True)
    if root==F9:
        sys.path.insert(0,'./local_user/.codex/skills/scipilot-figure-skill/scripts')
        from visual_qa import audit_layout
        issues=audit_layout(fig)
        (preview/(stem+'_版面检查.json')).write_text(json.dumps(issues,ensure_ascii=False),encoding='utf-8')
        if any(level=='FAIL' for level,_ in issues):raise RuntimeError(issues)
    fig.savefig(preview/(stem+'.png'),dpi=110)
    fig.savefig(root/'图片'/(stem+'.png'),dpi=600)
    fig.savefig(root/'图片'/(stem+'.svg'));pdf.savefig(fig);plt.close(fig)
cat=csv(F9/'原始数据/KEGG_br08901_通路分类表.csv').set_index('ID')
colors={'Environmental Information Processing':'#00A087','Organismal Systems':'#FC8D62','Human Diseases':'#8D96B8','Metabolism':'#66C2A5','Genetic Information Processing':'#E6AB02','Cellular Processes':'#A6D854'}
def cleanclass(s):return ' '.join(str(s).split()[1:]) if str(s).split()[0].isdigit() else s
def load9(k):
    ds={o:csv(F9/'各子图数据表'/f'Cluster{k}_{o}_统一展示数据.csv') for o in ['BP','CC','MF','KEGG']}
    d=ds['KEGG'];d['Level1']=d.ID.map(cat.Level1).map(cleanclass);d.to_csv(F9/'各子图数据表'/f'Cluster{k}_KEGG_含分类绘图数据.csv',index=False,encoding='utf-8-sig');return ds
data={}
if '--figure10-only' not in sys.argv:
    from prepare_figure9_display import prepare
    prepare()
    data={k:load9(k) for k in range(1,5)}
def panels(gs,k,letter,fig):
    a=fig.add_subplot(gs[0]);b=fig.add_subplot(gs[1]);ds=data[k]
    go=[];ys=[];ont=[];labels=[];y=0;centers=[]
    for o in ['BP','CC','MF']:
        d=ds[o];start=y
        if len(d):
            for _,r in d.iterrows():
                label=wrap(r.Description,60);weight=1+.72*label.count('\n');go.append(r);ys.append(y+weight/2);ont.append(o);labels.append(label);y+=weight
        else:labels.append('No eligible '+o+' terms');ys.append(y+.5);go.append(None);ont.append(o);y+=1
        centers.append((o,(start+y-1)/2,start,y-.5));y+=1.3
    maxv=max([float(r.Minus_log10_FDR) for r in go if r is not None]+[1])
    for j,(r,v,o) in enumerate(zip(go,ys,ont)):
        if r is not None:
            exploratory=not bool(r.BH_significant)
            a.barh(v,float(r.Minus_log10_FDR),height=.68,color='#F28E86' if o!='CC' else '#86C6CC',edgecolor='#5B666B' if exploratory else 'none',linewidth=.35 if exploratory else 0,hatch='///' if exploratory else None)
            a.plot(float(r.Minus_log10_FDR),v,marker='D' if exploratory else 'o',ms=3.4 if exploratory else 3,mfc='white' if exploratory else 'black',mec='#35565C' if exploratory else 'black',mew=.7)
            label=f'{int(r.Count)}; FDR={float(r["p.adjust"]):.3f}' if exploratory else str(int(r.Count))
            a.text(float(r.Minus_log10_FDR)+maxv*.025,v,label,va='center',fontsize=7)
    has_exploratory=any(r is not None and not bool(r.BH_significant) for r in go)
    a.set(yticks=ys,yticklabels=labels,xlim=(-maxv*.035,maxv*(1.5 if has_exploratory else 1.18)),ylim=(y-.9,-.8),xlabel=r'$-\log_{10}$(BH adjusted $P$)')
    a.tick_params(axis='y',length=0,labelsize=7.6);a.xaxis.grid(True,color='#EAECEF',lw=.5);a.set_axisbelow(True)
    for o,cy,st,en in centers:
        label=o+('†' if len(ds[o]) and not ds[o].BH_significant.all() else '')
        a.text(1.015,cy,label,transform=a.get_yaxis_transform(),va='center',fontsize=8,fontweight='bold');a.axhline(en+.45,color='#DADDE1',lw=.5)
    a.set_title(f'{letter}   Cluster {k} · GO ({[30,5,3,12][k-1]} genes)',loc='left',fontweight='bold',pad=14)
    a.text(1,.995,'Numbers: gene count; FDR shown for exploratory terms',transform=a.transAxes,ha='right',va='top',fontsize=7,color='#555555')
    if has_exploratory:
        note='† Hatching/open diamonds: exploratory; BH adjusted P ≥ 0.05.'
        if k==3:note+='\nCC: only 5 eligible terms; FDR=1 gives a zero-length bar.'
        a.text(0,-.095,note,transform=a.transAxes,ha='left',va='top',fontsize=7.5,color='#3D636A')
    d=ds['KEGG']
    if len(d):
        ypos=np.arange(len(d))
        for yy,(_,r) in zip(ypos,d.iterrows()):
            exploratory=not bool(r.BH_significant)
            b.barh(yy,float(r.Count),color=colors.get(r.Level1,'#BBBBBB'),height=.72,edgecolor='#5B666B' if exploratory else 'none',linewidth=.35 if exploratory else 0,hatch='///' if exploratory else None)
            label=f'{int(r.Count)}; FDR={float(r["p.adjust"]):.3f}' if exploratory else str(int(r.Count))
            b.text(float(r.Count)+.13,yy,label,va='center',fontsize=7)
        has_exp_kegg=not d.BH_significant.all()
        b.set(yticks=ypos,yticklabels=[wrap(x,55) for x in d.Description],ylim=(len(d)-.35,-.75),xlim=(0,max(pd.to_numeric(d.Count))*(1.6 if has_exp_kegg else 1.18)),xlabel='Gene count')
        b.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True));b.tick_params(axis='y',length=0,labelsize=7.6);b.xaxis.grid(True,color='#EAECEF',lw=.5);b.set_axisbelow(True)
        cats=list(dict.fromkeys(d.Level1));b.legend(handles=[Patch(facecolor=colors.get(x,'#BBBBBB'),label=x) for x in cats],loc='upper left',bbox_to_anchor=(0,-.16),frameon=False,ncol=2,fontsize=6.9,handlelength=1)
        if has_exp_kegg:
            note='† Hatched pathways: exploratory; BH adjusted P ≥ 0.05.'
            if k==3:note+='\nOnly 12 eligible pathways; none passes BH adjusted P < 0.05.'
            b.text(0,-.095,note,transform=b.transAxes,ha='left',va='top',fontsize=7.5,color='#3D636A')
    else:
        b.text(.5,.5,'No significant KEGG pathways\nBH adjusted P ≥ 0.05',ha='center',va='center',transform=b.transAxes,color='#777777',fontsize=10);b.set_axis_off()
    b.set_title(f'Cluster {k} · KEGG'+('†' if len(d) and not d.BH_significant.all() else ''),loc='left',fontweight='bold',pad=14)
if '--figure10-only' not in sys.argv:
    with PdfPages(F9/'图9_MCODE模块富集_主图与分图_统一调整版.pdf') as pdf:
        fig=plt.figure(figsize=(17.7,28));outer=fig.add_gridspec(3,2,left=.235,right=.98,top=.95,bottom=.055,width_ratios=[1,1],height_ratios=[1.1,1.1,1],wspace=.95,hspace=.48)
        for i,k in enumerate([1,2,3]):panels([outer[i,0],outer[i,1]],k,chr(65+i),fig)
        fig.suptitle('Functional enrichment of MCODE modules',x=.235,y=.985,ha='left',fontsize=15,fontweight='bold')
        emit(fig,F9,'图9_主图_ABC',pdf)
        for k in range(1,5):
            h=11.3;fig=plt.figure(figsize=(17.7,h));g=fig.add_gridspec(1,2,left=.235,right=.98,top=.90,bottom=.20,wspace=.95);panels([g[0],g[1]],k,chr(64+k) if k<4 else 'S1',fig);emit(fig,F9,f'图9_{chr(64+k) if k<4 else "S1"}_Cluster{k}',pdf)
if '--figure9-only' in sys.argv:
    print('FIGURE9 PLOTS DONE: uniform GO top10 / KEGG top20 displays for all four modules')
    sys.exit(0)
# Figure10 uses its canonical script for the readable layout.
import runpy
runpy.run_path(str(F10/'处理记录/plot_figure10_readable.py'),run_name='__main__')