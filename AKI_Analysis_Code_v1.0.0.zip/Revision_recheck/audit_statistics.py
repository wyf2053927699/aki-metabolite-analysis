from pathlib import Path
import json,csv,io,inspect
import numpy as np
import scipy
from scipy import stats
from scipy.integrate import quad

ROOT=Path(__file__).resolve().parent;Q=ROOT/'qa'
inputs=json.loads((Q/'Prism_input_data.json').read_text(encoding='utf-8'))
evidence=json.loads((Q/'computational_evidence.json').read_text(encoding='utf-8'))
archived={a['input'][0]['title']:a for a in evidence['prism_analyses']}
out=[];long=[]
def recurse(x):
 if isinstance(x,dict):
  if 'pValueAdjusted' in x and 'sample1' in x and 'sample2' in x:yield x
  for v in x.values():yield from recurse(v)
 elif isinstance(x,list):
  for v in x:yield from recurse(v)
def welch(groups):
 n=np.array([len(x) for x in groups],float);m=np.array([np.mean(x) for x in groups]);v=np.array([np.var(x,ddof=1) for x in groups]);k=len(n)
 w=n/v;wm=np.sum(w*m)/sum(w);tmp=np.sum((1-w/sum(w))**2/(n-1))
 f=np.sum(w*(m-wm)**2)/(k-1)/(1+2*(k-2)*tmp/(k*k-1));df2=(k*k-1)/(3*tmp)
 raw=np.array([stats.ttest_ind(groups[0],groups[1],equal_var=False).pvalue,stats.ttest_ind(groups[2],groups[1],equal_var=False).pvalue]);order=np.argsort(raw);adj=np.empty(2);adj[order]=np.minimum(1,np.maximum.accumulate(raw[order]*np.array([2,1])))
 return {'F':float(f),'df1':k-1,'df2':float(df2),'p':float(stats.f.sf(f,k-1,df2)),'Welch_t_Holm_p_NC_vs_LPS':float(adj[0]),'Welch_t_Holm_p_NaB_vs_LPS':float(adj[1])}
def dunnett_two(t,df,rho):
 # Stable bivariate-t tail integration for exactly two two-sided comparisons.
 # P(max(|T1|,|T2|)>t) = P(|T1|>t) + integral over |T1|<=t of the conditional T2 tail.
 def fun(x):
  scale=np.sqrt((df+x*x)/(df+1)*(1-rho*rho))
  tail=stats.t.cdf((-t-rho*x)/scale,df+1)+stats.t.sf((t-rho*x)/scale,df+1)
  return stats.t.pdf(x,df)*tail
 val,err=quad(fun,-t,t,epsabs=1e-14,epsrel=1e-9,limit=300)
 return min(1.,float(2*stats.t.sf(t,df)+val))
for item in inputs:
 rows=list(csv.reader(io.StringIO(item['data'])));groups=[np.array([float(r[c]) for r in rows if len(r)>c and r[c]!='']) for c in range(3)]
 for c,g in enumerate(groups):
  for i,v in enumerate(g):long.append({'Endpoint':item['title'],'Group':['NC','LPS','LPS+NaB'][c],'Independent_sample':i+1,'Value':v})
 an=stats.f_oneway(*groups);bf=stats.levene(*groups,center='median')
 kw={'rng':np.random.default_rng(20261027)} if 'rng' in inspect.signature(stats.dunnett).parameters else {'random_state':20261027}
 dn=stats.dunnett(groups[0],groups[2],control=groups[1],alternative='two-sided',**kw)
 df=sum(map(len,groups))-3;n0,nc,n2=map(len,groups)
 rho=(1/nc)/np.sqrt((1/nc+1/n0)*(1/nc+1/n2))
 exact=[dunnett_two(abs(float(t)),df,rho) for t in dn.statistic]
 rec={'Endpoint':item['title'],'n':[len(g) for g in groups],'means':[float(np.mean(g)) for g in groups],'sample_SD':[float(np.std(g,ddof=1)) for g in groups],
      'ANOVA_F':float(an.statistic),'ANOVA_df1':2,'ANOVA_df2':sum(map(len,groups))-3,'ANOVA_p':float(an.pvalue),'Brown_Forsythe_p':float(bf.pvalue),
      'Dunnett_p_NC_vs_LPS_recheck':exact[0],'Dunnett_p_NaB_vs_LPS_recheck':exact[1],'Dunnett_software':'SciPy '+scipy.__version__+'; deterministic bivariate-t tail quadrature','archive_comparisons':[]}
 a=archived.get(item['title'])
 if a:
  for c in recurse(a['results']):
   other=c['sample2']['id']['col']['title'];check_p=exact[0 if other=='NC' else 1]
   rec['archive_comparisons'].append({'group1':c['sample1']['id']['col']['title'],'group2':other,'p_adjusted':c['pValueAdjusted']['value'],'absolute_recheck_difference':abs(c['pValueAdjusted']['value']-check_p)})
  model=a['results'].get('ordinaryAnovaModel',{}).get('anovaTable',{}).get('colFactor',{}).get('fTest',{})
  if model:rec['ANOVA_F_agrees_with_Prism']=bool(abs(model['f']-an.statistic)<1e-6)
 if bf.pvalue<.05:rec['heterogeneity_sensitivity']=welch(groups)
 out.append(rec)
(Q/'statistics_recheck.json').write_text(json.dumps({'independence':'Author confirmed all n are independent on 2026-10-27. Technical repeats are not independent n.','primary':'Ordinary one-way ANOVA and two-sided Dunnett comparisons, LPS control; archived Prism 10.1.2 plus independent recheck.','qPCR_scale':'Relative expression values in Prism, not raw Ct or DeltaCt.','Dunnett_precision':'Two-sided Dunnett adjusted P for two LPS-referenced comparisons calculated by deterministic bivariate-t conditional tail integration. Original Prism results independently cross-checked.','endpoints':out},ensure_ascii=False,indent=2),encoding='utf-8')
with (Q/'cellular_values_from_Prism.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=long[0]);w.writeheader();w.writerows(long)
print('SCIPY',scipy.__version__)
for r in out:print(r['Endpoint'],r['n'],'Dunnett',r['Dunnett_p_NC_vs_LPS_recheck'],r['Dunnett_p_NaB_vs_LPS_recheck'],'BF',r['Brown_Forsythe_p'],'Sensitivity',r.get('heterogeneity_sensitivity'))
