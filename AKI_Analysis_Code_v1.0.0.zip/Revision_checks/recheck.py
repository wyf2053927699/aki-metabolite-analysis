from pathlib import Path
import csv, json, gzip, re, itertools, argparse
from collections import defaultdict
from statistics import median
import openpyxl
from collections import Counter

parser = argparse.ArgumentParser(description='Run the revision sensitivity checks against the archived project inputs.')
parser.add_argument('--input-root', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
args = parser.parse_args()
base = args.input_root.resolve()
out = args.output_dir.resolve()
out.mkdir(parents=True, exist_ok=True)
def file(name):
    return next(p for p in base.rglob(name) if not p.is_relative_to(out))
def rows(name):
    with file(name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
def save(name, data):
    with (out / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, data[0].keys())
        w.writeheader()
        w.writerows(data)
def sheet(path, name):
    return list(openpyxl.load_workbook(file(path), read_only=True, data_only=True)[name].values)
def split(value):
    return {s.strip() for s in str(value or '').split(';') if s.strip()}
def cell_number(value):
    try:
        return float(value)
    except (ValueError, TypeError):
        return None

sea, sea_filtered, stp, stp_filtered = (defaultdict(set) for _ in range(4))
for r in sheet('SEA_ChEMBL27_228*.xlsx', '人类靶点明细')[6:]:
    if r[7] and str(r[7]).isdigit():
        cid, genes = str(r[7]), split(r[2])
        sea[cid].update(genes)
        if r[4] is not None and r[4] < .05:
            sea_filtered[cid].update(genes)
stp_files = set()
for r in rows('STP_全部代谢物靶点记录.csv'):
    cid, genes = r['Compound_CID'], split(r['Gene_annotation_raw'])
    stp_files.add(cid)
    stp[cid].update(genes)
    if (cell_number(r['Probability']) or 0) > 0:
        stp_filtered[cid].update(genes)
assert len(set.union(*sea.values())) == 1291 and len(set.union(*stp.values())) == 1195
disease = [r for r in rows('疾病靶点_OMIM_GeneCards_合并去重.csv') if r['Entry_type']=='基因']
omim = {r['Gene_or_locus'] for r in disease if int(r['OMIM_record_count'])}
scores = {r['Gene_or_locus']: cell_number(r['GeneCards_relevance_score']) for r in disease if int(r['GeneCards_record_count'])}
scores = {g:s for g,s in scores.items() if s is not None}
threshold = median(scores.values())
ds = {r['Gene_or_locus'] for r in disease}
assert len(omim) == 89 and len(ds) == 3647
h = {r['Gene_symbol'] for r in rows('gutMGene_v2_人类宿主基因_238个.csv')}
cids = sorted({str(r[0]) for r in sheet('0.化合物SMILES数据表.xlsx', 'Sheet1')[1:] if r[0]},key=int)
assert len(cids)==228 and set(sea)|set(stp) <= set(cids)
pooled = set.union(*sea.values()) & set.union(*stp.values())
within = {cid: sea[cid] & stp[cid] for cid in cids}
matched = set.union(*within.values())
strict = set.union(*(sea_filtered[cid]&stp_filtered[cid] for cid in cids))
core = {'AKT1','CASP3','IL1B','IL6','JUN','NFKB1'}
stats={}
for name, target in [('pooled',pooled),('matched',matched),('matched_score',strict)]:
    for mode,d in [('all',ds),('median_plus_omim',omim|{g for g,s in scores.items() if s>=threshold})]:
        candidate=target & d & h
        stats[name+'_'+mode]={'target_count':len(target),'disease_count':len(d),'overlap_count':len(target&d),'candidates':sorted(candidate),'core_retained':sorted(candidate&core)}
assert len(stats['pooled_all']['candidates'])==49
save('CID_coverage.csv',[dict(CID=c, SEA_genes=len(sea[c]), STP_rows_archived=c in stp_files, STP_genes=len(stp[c]), Matched_genes=len(within[c]), Genes=';'.join(sorted(within[c]))) for c in cids])
save('CID_gene_consensus.csv',[dict(CID=c,Gene=g,Pass_score_sensitivity=g in sea_filtered[c]&stp_filtered[c],AKI=g in ds,Human_gutMGene=g in h) for c in cids for g in sorted(within[c])])

nodes={r['Node_ID']:r for r in rows('图10_全部节点.csv')}
edges=rows('图10_全部连线.csv')
degree=[]
for key,node in nodes.items():
    if node['Type']!='Metabolite':
        continue
    links=[(e,e['Source'] if e['Target']==key else e['Target']) for e in edges if key in (e['Source'],e['Target'])]
    genes={nodes[n]['Gene_symbol'] for e,n in links if nodes[n]['Type']=='Target'}
    degree.append(dict(Metabolite=node['Label'],CID=node['CID'],Total=len({n for e,n in links}),Targets=len(genes),Target_genes=';'.join(sorted(genes)),Others=len({n for e,n in links if nodes[n]['Type']!='Target'}),PMID_tagged_neighbors=len({n for e,n in links if e['PMIDs'].strip()}),Matched_predictions=len(within[node['CID']])))
degree.sort(key=lambda r:(-r['Targets'],int(r['CID'])))
save('Metabolite_rank_sensitivity.csv',degree)

ppi=rows('A_PPI连线.csv')
ranking=rows('B_六算法全部排名.csv')
rank={a:[r['Gene_symbol'] for r in ranking if r['Algorithm']==a] for a in sorted({r['Algorithm'] for r in ranking})}
top={k:sorted(set.intersection(*(set(r[:k]) for r in rank.values()))) for k in [5,10,15]}
j=[dict(A=a,B=b,Jaccard_top10=len(set(rank[a][:10])&set(rank[b][:10]))/len(set(rank[a][:10])|set(rank[b][:10]))) for a,b in itertools.combinations(rank,2)]
save('Centrality_agreement.csv',j)
net=[]
for cohort, genes in [('baseline',pooled & ds & h),('CID',matched & ds & h)]:
    for cutoff in [.4,.7]:
        pairs=[(r['Source'],r['Target']) for r in ppi if float(r['Combined_score'])>=cutoff and {r['Source'],r['Target']}<=genes]
        G=Counter(g for pair in pairs for g in pair)
        degrees=sorted(G.items(),key=lambda pair:(-pair[1],pair[0]))
        net.append(dict(Cohort=cohort,Threshold=cutoff,Connected_nodes=len(G),Edges=len(pairs),Top10_degree=';'.join(g for g,d in degrees[:10]),Original_cores_connected=';'.join(sorted(set(G)&core))))
save('STRING_edge_sensitivity.csv',net)

with gzip.open(file('9606.protein.info.v12.0.txt.gz'),'rt',encoding='utf-8') as f:
    mapping=[r for r in csv.DictReader(f,delimiter='\t') if any(re.search(r'\b'+sym+r'\b',r['annotation'],re.I) or r['preferred_name']==sym for sym in ('VDR','VEGFA','ST6GAL1'))]
save('STRING_dictionary_matches.csv',mapping)
result=dict(SEA_with_gene_hits=sum(bool(sea[c]) for c in cids),STP_archived=len(stp_files),STP_with_gene_hits=sum(bool(stp[c]) for c in cids),dual_with_gene_hits=sum(bool(sea[c] and stp[c]) for c in cids),CID_any_consensus=sum(bool(x) for x in within.values()),matched_pairs=sum(map(len,within.values())),GeneCards_median=threshold,stats=stats,top=top,net=net,degree=degree,rank_jaccard_range=[min(r['Jaccard_top10'] for r in j),max(r['Jaccard_top10'] for r in j)])
(out/'audit_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))


# KEGG over-representation under a common snapshot and two eligible universes.
from math import comb
kegg_file = base/'8.图4_GO_KEGG与功能网络'/'原始数据'/'KEGG_gsid2gene.tsv'
terms=defaultdict(set)
with kegg_file.open(encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f,delimiter='\t'):
        terms[r['gsid']].add(r['gene'])
full=set.union(*terms.values())
host_ids=set.union(*(split(r['gutMGene_Gene_IDs']) for r in rows('gutMGene_v2_人类宿主基因_238个.csv')))
conversion={r['SYMBOL']:r['ENTREZID'] for r in rows('输入49基因_Entrez映射.csv') if r['ENTREZID']}
ora=[]
for cohort in ['pooled_all','matched_all']:
    ids={conversion[g] for g in stats[cohort]['candidates'] if g in conversion}
    for label,universe in [('KEGG_annotated',full),('gutMGene_host_eligible',full&host_ids)]:
        foreground=ids&universe
        part=[]
        M,n=len(universe),len(foreground)
        for term,term_ids in terms.items():
            K=len(term_ids&universe)
            hit=sorted(term_ids&foreground)
            if not (10<=K<=500):
                continue
            p=sum(comb(K,j)*comb(M-K,n-j) for j in range(max(len(hit),n-(M-K)),min(K,n)+1))/comb(M,n)
            part.append(dict(Cohort=cohort,Background=label,Pathway=term,Hits=len(hit),Foreground=n,Background_hits=K,Background_size=M,FE=(len(hit)/n)/(K/M),P=p,BH=1,Entrez_hits=';'.join(hit)))
        part.sort(key=lambda r:r['P'])
        adjusted=1
        for i in range(len(part)-1,-1,-1):
            adjusted=min(adjusted,part[i]['P']*len(part)/(i+1))
            part[i]['BH']=adjusted
        ora.extend(part)
save('KEGG_background_sensitivity.csv',ora)
for r in ora:
    if r['Pathway'] in ['hsa04620','hsa04668','hsa05417','hsa04933']:
        print(r)


modules=defaultdict(set)
for row in rows('MCODE_全部模块成员.csv'):
    modules[int(row['Cluster_rank'])].add(row['Gene_symbol'])
expanded_edges=rows('A_PPI全部连线.csv')
module_sensitivity=[]
for k,members in sorted(modules.items()):
    for cutoff in (.4,.7):
        pairs=[(r['Source'],r['Target']) for r in expanded_edges if float(r['score'])>=cutoff and {r['Source'],r['Target']}<=members]
        present={g for pair in pairs for g in pair}
        module_sensitivity.append(dict(Module=k,STRING_score=cutoff,Original_members=len(members),Connected_members=len(present),Within_module_edges=len(pairs),Density=len(pairs)/comb(len(members),2),Original_cores_connected=';'.join(sorted(present&core))))
save('Fixed_module_edge_sensitivity.csv',module_sensitivity)
print(module_sensitivity)



original_genes=pooled&ds&h
expansion=[]
for domain in ('BP','CC','MF','KEGG'):
    original_terms={r['ID'] for r in rows(f'{domain}_全部富集检验.csv') if r['BH_significant']=='TRUE'}
    for r in rows(f'扩展105_{domain}_全部富集检验.csv'):
        if r['BH_significant']!='TRUE':
            continue
        hits=set(r['Gene_symbols'].split('/'))
        expansion.append(dict(Domain=domain,Term=r['ID'],Label=r['Description'],BH=r['p.adjust'],Original_significant=r['ID'] in original_terms,Original_hits=';'.join(sorted(hits&original_genes)),Added_hits=';'.join(sorted(hits-original_genes)),Only_added_genes=not (hits&original_genes)))
save('GeneMANIA_expansion_term_support.csv',expansion)
print('Expanded significant terms solely supported by added genes:',Counter(r['Domain'] for r in expansion if r['Only_added_genes']))
mode_rows=rows('图10_每条连线原始证据.csv')
edge_types=[]
for edge in edges:
    related=[r for r in mode_rows if r['Edge_ID']==edge['Edge_ID']]
    modes=Counter(r['Mode'].strip() or 'not recorded' for r in related)
    edge_types.append(dict(Edge_ID=edge['Edge_ID'],Source=edge['Source'],Target=edge['Target'],Relation=edge['Relation'],PMIDs=edge['PMIDs'],Source_mode_counts='; '.join(f'{k}={v}' for k,v in sorted(modes.items())),Curated_causal_label=any(mode.lower()=='causally' for mode in modes)))
save('Network_edge_evidence_modes.csv',edge_types)
print(Counter((r['Relation'],r['Curated_causal_label']) for r in edge_types))

